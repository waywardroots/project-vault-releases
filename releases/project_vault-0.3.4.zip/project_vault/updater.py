"""Updates without downloading a new version by hand.

How it works:
  1. Each release puts two files on GitHub Releases: project_vault-X.Y.Z.zip and latest.json.
  2. latest.json says which version is newest, where its zip is, and the zip's SHA-256.
     It is signed with the publisher's private key (tools/release.py, kept on the publisher's PC).
  3. The app checks latest.json (at most once a day, and on `update`). It only trusts it if the
     signature matches PUBLIC_KEY below, so nobody else can push code to users.
  4. `update` downloads the zip, checks its SHA-256, test-imports it in a side folder, then swaps it
     in. The old version is kept in project_vault_backups\\ and `update --rollback` puts it back.

Nothing about the user is sent: the check is a plain download of latest.json.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

from . import __version__
from .signing import verify

PACKAGE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = PACKAGE_DIR / "update_config.json"  # written by tools/release.py setup, shipped in releases


def _config() -> dict:
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


# Where latest.json lives and the public key it must be signed with.
UPDATE_URL = _config().get("update_url", "")
PUBLIC_KEY = _config().get("public_key", "")
BACKUP_DIR_NAME = "project_vault_backups"
KEEP_BACKUPS = 3
CHECK_EVERY = 24 * 3600
STATE_FILE = "update_check.json"


class UpdateError(Exception):
    pass


@dataclass
class Release:
    version: str
    url: str
    sha256: str
    size: int
    notes: str
    published: str


def parse_version(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.strip().lstrip("v").split("."))
    except ValueError:
        return (0,)


def manifest_bytes(manifest: dict) -> bytes:
    """The exact bytes that are signed: same on every computer."""
    return json.dumps(manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def _download(url: str, timeout: float) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": f"ProjectVault/{__version__}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except Exception as e:
        raise UpdateError(f"couldn't download {url}: {e}") from e


def fetch_release(url: str = "", public_key: str = "", timeout: float = 15) -> Release:
    url, public_key = url or UPDATE_URL, public_key or PUBLIC_KEY
    if not url or not public_key:
        raise UpdateError("updates aren't set up in this version yet")
    try:
        doc = json.loads(_download(url, timeout).decode("utf-8"))
        manifest, sig = doc["manifest"], bytes.fromhex(doc["signature"])
    except UpdateError:
        raise
    except Exception as e:
        raise UpdateError(f"the update information is damaged ({e})") from e
    if not verify(bytes.fromhex(public_key), manifest_bytes(manifest), sig):
        raise UpdateError("the update information isn't signed by us, so it was ignored")
    if manifest.get("app") != "project_vault":
        raise UpdateError("the update information is for a different app")
    return Release(version=str(manifest["version"]), url=manifest["url"], sha256=manifest["sha256"].lower(),
                   size=int(manifest.get("size", 0)), notes=manifest.get("notes", ""),
                   published=manifest.get("published", ""))


def is_newer(release: Release, current: str = __version__) -> bool:
    return parse_version(release.version) > parse_version(current)


def _check_zip(data: bytes, release: Release) -> zipfile.ZipFile:
    if hashlib.sha256(data).hexdigest() != release.sha256:
        raise UpdateError("the download doesn't match the signed update (it may be incomplete); nothing changed")
    z = zipfile.ZipFile(io.BytesIO(data))
    for name in z.namelist():
        parts = name.replace("\\", "/").split("/")
        if parts[0] != "project_vault" or ".." in parts or name.startswith("/") or ":" in name:
            raise UpdateError(f"the update contains an unexpected file ({name}); nothing changed")
    try:
        init = z.read("project_vault/__init__.py").decode("utf-8")
    except KeyError:
        raise UpdateError("the update is missing project_vault/__init__.py; nothing changed")
    if f'__version__ = "{release.version}"' not in init:
        raise UpdateError("the update's version doesn't match its signed version; nothing changed")
    return z


def _self_test(folder: Path, version: str) -> None:
    """Import every module of the new version in its own Python, away from the running one."""
    # the folder goes first on the path explicitly: the installed app's Python (python.org's embeddable
    # one) never looks in the current folder, so cwd alone would test the OLD version instead
    code = (f"import sys; sys.path.insert(0, {str(folder)!r})\n"
            "import importlib, pkgutil, project_vault as p\n"
            "[importlib.import_module('project_vault.' + m.name) for m in pkgutil.iter_modules(p.__path__) if m.name != '__main__']\n"
            "print(p.__version__)")
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    r = subprocess.run([sys.executable, "-c", code], cwd=folder, capture_output=True, text=True,
                       timeout=120, env=env)
    if r.returncode != 0 or r.stdout.strip() != version:
        why = (r.stderr.strip().splitlines() or [""])[-1] or (
            f"it started as version {r.stdout.strip() or '(nothing)'} instead of {version}")
        raise UpdateError("the new version failed its self-test, so it wasn't installed:\n" + why)


def _move(src: Path, dst: Path, tries: int = 6) -> None:
    for i in range(tries):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if i == tries - 1:
                raise
            time.sleep(0.5 * (i + 1))


def install(release: Release, data: bytes | None = None, package_dir: Path = PACKAGE_DIR,
            current: str = __version__) -> Path:
    """Install a verified release. Returns the backup folder of the old version."""
    data = data if data is not None else _download(release.url, timeout=120)
    z = _check_zip(data, release)
    root = package_dir.parent
    staging = root / ".project_vault_update"
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir()
    try:
        z.extractall(staging)
        _self_test(staging, release.version)
        backups = root / BACKUP_DIR_NAME
        backups.mkdir(exist_ok=True)
        backup = backups / f"project_vault-{current}"
        n = 2
        while backup.exists():
            backup = backups / f"project_vault-{current} ({n})"
            n += 1
        try:
            _move(package_dir, backup)
        except PermissionError:
            raise UpdateError("Windows wouldn't let the old version be moved (is a file in "
                              f"{package_dir} open in another program?). Nothing changed.")
        try:
            _move(staging / "project_vault", package_dir)
        except OSError:
            _move(backup, package_dir)  # put the old version back
            raise UpdateError("the new version couldn't be put in place; the old version was kept.")
        _prune(backups)
        return backup
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def _prune(backups: Path) -> None:
    olds = sorted((p for p in backups.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime)
    for p in olds[:-KEEP_BACKUPS]:
        shutil.rmtree(p, ignore_errors=True)


def backups(package_dir: Path = PACKAGE_DIR) -> list[Path]:
    d = package_dir.parent / BACKUP_DIR_NAME
    if not d.is_dir():
        return []
    return sorted((p for p in d.iterdir() if (p / "__init__.py").exists()), key=lambda p: p.stat().st_mtime)


def rollback(package_dir: Path = PACKAGE_DIR, current: str = __version__) -> Path:
    """Put the most recent backup back; the current version becomes a backup."""
    olds = backups(package_dir)
    if not olds:
        raise UpdateError("there's no earlier version to go back to")
    previous = olds[-1]
    parked = previous.parent / f"project_vault-{current} (rolled back)"
    shutil.rmtree(parked, ignore_errors=True)
    _move(package_dir, parked)
    try:
        _move(previous, package_dir)
    except OSError:
        _move(parked, package_dir)
        raise UpdateError("the earlier version couldn't be put back; nothing changed")
    return previous


# ------------------------------------------------------------ daily check

def _state(folder: Path) -> dict:
    try:
        return json.loads((folder / STATE_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def daily_notice(folder: Path, now: float | None = None, url: str = "", public_key: str = "") -> str | None:
    """A one-line notice if a newer version is out. Checks the internet at most once a day,
    gives up after 3 seconds, and never gets in the way of the command that just ran."""
    if os.environ.get("PROJECT_VAULT_NO_UPDATE_CHECK") or not (url or UPDATE_URL):
        return None
    now = now if now is not None else time.time()
    st = _state(folder)
    if "checked" not in st or now - st["checked"] >= CHECK_EVERY:
        try:
            st["latest"] = fetch_release(url, public_key, timeout=3).version
        except Exception:
            pass
        st["checked"] = now
        try:
            (folder / STATE_FILE).write_text(json.dumps(st), encoding="utf-8")
        except OSError:
            pass
    latest = st.get("latest")
    if latest and parse_version(latest) > parse_version(__version__):
        return (f"Project Vault {latest} is available (you have {__version__}). "
                "To install it: python -m project_vault update")
    return None
