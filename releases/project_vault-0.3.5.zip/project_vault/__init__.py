"""Project Vault: index and search your Ableton Live projects."""
__version__ = "0.3.5"
