"use strict";
// Project Vault's window. Talks only to the local server that served it (see gui.py).

// ---------------------------------------------------------------- basics
const KEY = (() => {
  const m = location.hash.match(/key=([\w-]+)/);
  if (m) { sessionStorage.setItem("pv-key", m[1]); history.replaceState(null, "", "#/home"); }
  return sessionStorage.getItem("pv-key") || "";
})();

const $ = (sel, el = document) => el.querySelector(sel);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const num = (n) => Number(n || 0).toLocaleString();
const plural = (n, one, many) => `${num(n)} ${n === 1 ? one : (many || one + "s")}`;

const ICON = {
  songs: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  fix: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
  sounds: '<path d="M4 6h16M4 12h10M4 18h7"/><circle cx="18" cy="16" r="3"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  plug: '<path d="M9 2v6M15 2v6"/><path d="M6 8h12v4a6 6 0 0 1-12 0z"/><path d="M12 18v4"/>',
  live: '<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 21h8"/>',
  dupe: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
  tag: '<path d="M20 12l-8 8-9-9V3h8z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
  restore: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
  download: '<path d="M12 4v12M6 11l6 6 6-6"/><path d="M4 20h16"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  file: '<path d="M14 3H6v18h12V7z"/><path d="M14 3v4h4"/>',
  warn: '<path d="M12 3l9 16H3z"/><path d="M12 10v4M12 17h.01"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  compare: '<path d="M7 4v16M17 4v16M3 8h8M13 16h8"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  cloud: '<path d="M7 18a4 4 0 0 1-.6-8A6 6 0 0 1 18 9.5a4.5 4.5 0 0 1-.5 8.5z"/>',
  drive: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 14h.01M11 14h6"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.9-3.5L3 10"/><path d="M3 4v6h6"/><path d="M4 13a8 8 0 0 0 14.9 3.5L21 14"/><path d="M21 20v-6h-6"/>',
};
const icon = (name) => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICON[name] || ""}</svg>`;
const btn = (label, { kind = "secondary", ic = "", act = "", data = {}, small = false, disabled = false, title = "" } = {}) =>
  `<button type="button" class="btn ${kind}${small ? " small" : ""}" ${act ? `data-act="${act}"` : ""} ${
    Object.entries(data).map(([k, v]) => `data-${k}="${esc(v)}"`).join(" ")}${disabled ? " disabled" : ""}${
    title ? ` title="${esc(title)}"` : ""}>${ic ? icon(ic) : ""}<span>${esc(label)}</span></button>`;

const PAGE = Math.random().toString(36).slice(2, 12);
async function api(path, body) {
  const opt = { headers: { "X-Vault-Key": KEY, "X-Vault-Page": PAGE } };
  if (body !== undefined) {
    opt.method = "POST";
    opt.headers["Content-Type"] = "application/json";
    opt.body = JSON.stringify(body);
  }
  let r;
  try { r = await fetch("/api/" + path, opt); } catch (e) { throw new Error("Project Vault isn't running any more. Close this window and open it again."); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `request failed (${r.status})`);
  return data;
}
const q = (obj) => new URLSearchParams(obj).toString();

function toast(text, { bad = false, action = null, ms = 6000 } = {}) {
  const el = document.createElement("div");
  el.className = "toast" + (bad ? " bad" : "");
  el.innerHTML = `<span>${esc(text)}</span>`;
  if (action) {
    const b = document.createElement("button");
    b.type = "button"; b.className = "btn small"; b.textContent = action.label;
    b.onclick = () => { action.run(); el.remove(); };
    el.appendChild(b);
  }
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), ms);
}
const fail = (e) => toast(e.message || String(e), { bad: true, ms: 9000 });

function ask(title, text, okLabel = "OK") {
  const d = $("#dialog");
  $("#dialog-title").textContent = title;
  $("#dialog-text").textContent = text;
  $("#dialog-ok").textContent = okLabel;
  d.returnValue = "";
  d.showModal();
  return new Promise((res) => d.addEventListener("close", () => res(d.returnValue === "ok"), { once: true }));
}

const openPath = (path, reveal = false) => api("open", { path, reveal }).catch(fail);

// ---------------------------------------------------------------- jobs (long commands, shown in a dock)
const Job = {
  since: 0, timer: null, onDone: null,
  async start(kind, args = [], onDone = null) {
    try {
      const j = await api("job", { kind, args });
      this.since = 0; this.onDone = onDone;
      $("#job-log").textContent = "";
      this.show(j);
      this.poll();
    } catch (e) { fail(e); }
  },
  show(j) {
    $("#job").hidden = false;
    $("#job-title").textContent = j.title + (j.state === "done" ? ": done" : j.state === "failed" ? ": stopped" : "");
    const spin = $("#job-spin");
    spin.className = "spinner" + (j.state === "done" ? " stop" : j.state === "failed" ? " fail" : "");
    $("#job-stop").hidden = j.state !== "running";
    $("#job-close").hidden = j.state === "running";
    const secs = Math.round(((j.ended || Date.now() / 1000) - j.started));
    $("#job-time").textContent = secs >= 60 ? `${Math.floor(secs / 60)}m ${secs % 60}s` : `${secs}s`;
    if (j.lines && j.lines.length) {
      const log = $("#job-log");
      const atEnd = log.scrollTop + log.clientHeight >= log.scrollHeight - 30;
      log.textContent += (log.textContent ? "\n" : "") + j.lines.join("\n");
      if (log.textContent.length > 200000) log.textContent = log.textContent.slice(-150000);
      if (atEnd) log.scrollTop = log.scrollHeight;
    }
  },
  async poll() {
    clearTimeout(this.timer);
    try {
      const j = await api("job?" + q({ since: this.since }));
      if (j.state === "none") return;
      this.since = j.next;
      this.show(j);
      if (j.state === "running") { this.timer = setTimeout(() => this.poll(), 700); return; }
      if (this.onDone) { const f = this.onDone; this.onDone = null; f(j); }
      refreshSide();
      if (current.refresh) current.refresh();
    } catch (e) { this.timer = setTimeout(() => this.poll(), 2000); }
  },
};
$("#job-stop").onclick = async () => { if (await ask("Stop this job?", "What it already wrote is kept; you can run it again later.", "Stop")) api("job/stop", {}).catch(fail); };
$("#job-close").onclick = () => { $("#job").hidden = true; };

// ---------------------------------------------------------------- sidebar status
let overviewCache = null;
async function refreshSide() {
  try {
    const o = await api("overview");
    overviewCache = o;
    $("#side-version").textContent = "Project Vault " + o.version;
    pollNow();
    drawStorageSide();
    return o;
  } catch (e) { $("#now-body").innerHTML = `<p class="side-note">Not connected.</p>`; return null; }
}

// The left panel follows the song open in Live: its latest versions, updated as you save.
let nowState = { key: "", total: 0 };
async function pollNow() {
  let n;
  try { n = await api("now"); } catch (e) { return; }
  const o = overviewCache || { history: {} };
  const on = o.history.running && !o.history.paused;
  $("#side-dot").className = "dot" + (on ? " on" : "");
  $("#side-dot").title = on ? "Version history is on" : "Version history is off";
  const body = $("#now-body");
  const key = JSON.stringify(n) + on + !!o.history.paused;
  if (key === nowState.key) return;
  const grew = n.path && n.path === nowState.path && n.total > nowState.total;
  nowState = { key, total: n.total || 0, path: n.path || "" };
  const off = on ? "" : o.history.paused ? `<p class="side-note">Version history is paused. <a href="#/settings">Turn it back on</a>.</p>`
    : `<p class="side-note">Version history isn't running. <a href="#/settings">Turn it on</a> to keep every save.</p>`;
  if (!n.live) { body.innerHTML = `<p class="side-note">Open a song in Live and its versions show up here.</p>${off}`; return; }
  if (n.unsaved) { body.innerHTML = `<div class="side-song">${esc(n.live)}</div><p class="side-note">Not saved yet. Save it in Live to start its history.</p>`; return; }
  if (!n.path) { body.innerHTML = `<div class="side-song">${esc(n.live)}</div><p class="side-note">Project Vault hasn't found this set's file yet. It shows up after the next save.</p>${off}`; return; }
  body.innerHTML = `<a class="side-song" href="${esc(songLink(n.path))}">${esc(n.live)}</a>
    <div class="side-sub">${n.total ? `${plural(n.total, "version")} kept` : "No versions yet"}${on ? " · keeping every save" : ""}</div>
    ${n.versions.length ? `<div class="now-list">${n.versions.map((v, i) => `
      <a class="now-item${i === 0 ? " newest" : ""}${i === 0 && grew ? " fresh" : ""}" href="${esc(songLink(n.path) + "&v=" + v.n)}" title="${esc(v.what)}">
        <span class="now-num">${v.n}</span><span class="now-text">
        <span class="now-when">${esc(v.when)}${v.label ? `<span class="now-label">${esc(v.label)}</span>` : ""}</span>
        <span class="now-what" style="display:block">${esc(v.what || (v.source === "Live backup" ? "from Live's Backup folder" : ""))}</span></span></a>`).join("")}</div>
      ${n.total > n.versions.length ? `<a class="side-link" href="${esc(songLink(n.path))}">All ${num(n.total)} versions</a>` : ""}`
      : `<button type="button" class="btn small" data-act="snapshot" data-path="${esc(n.path)}">${icon("clock")}<span>Keep a version now</span></button>`}
    ${off}`;
  if (grew) toast(`Version ${n.total} of ${n.live} kept.`);
}

async function drawStorageSide() {
  const box = $("#store-body");
  if (!box) return;
  try {
    const s = await api("storage");
    box.innerHTML = s.destinations.length ? s.destinations.map((d) => {
      const last = d.last || {};
      const bad = !d.reachable || last.error;
      const status = !d.reachable ? "Can't reach this folder" : last.error ? last.error : last.at ? `Backed up ${shortWhen(last.at)}` : "Not backed up yet";
      return `<a class="store-item" href="#/storage"><span class="store-icon">${icon(d.kind === "folder" ? "drive" : "cloud")}</span>
        <span style="min-width:0"><span class="store-name" style="display:block">${esc(d.name)}</span>
        <span class="store-status${bad ? " bad" : ""}" style="display:block">${esc(status)}</span></span></a>`;
    }).join("") : `<p class="side-note">Back up your songs to OneDrive, Google Drive, Dropbox or any drive.</p>`;
  } catch (e) { /* shown on the Storage page */ }
}
const shortWhen = (at) => at.slice(0, 10) === today() ? at.slice(11) : at.slice(5, 10).replace("-", "/") + " " + at.slice(11);

// ---------------------------------------------------------------- routing
let current = {};
const routes = {};
function route() {
  const [path, query] = (location.hash.slice(1) || "/home").split("?");
  const name = path.replace(/^\//, "") || "home";
  const params = Object.fromEntries(new URLSearchParams(query || ""));
  document.querySelectorAll("#nav a").forEach((a) => a.classList.toggle("on",
    a.dataset.route === name || (name === "song" && a.dataset.route === "songs")));
  const page = routes[name] || routes.home;
  current = { name, params, refresh: null };
  const main = $("#main");
  main.innerHTML = `<div class="loading"><span class="spinner"></span>Loading…</div>`;
  page(main, params).catch((e) => { main.innerHTML = `<div class="card"><h2>Something went wrong</h2><p class="lead">${esc(e.message)}</p></div>`; });
  main.focus({ preventScroll: true });
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);
const go = (hash) => { location.hash = hash; };
const songLink = (path) => "#/song?" + q({ path });

// One click handler for every button with data-act on any page.
const actions = {};
document.addEventListener("click", (ev) => {
  const el = ev.target.closest("[data-act]");
  if (!el || el.disabled || el.tagName === "INPUT") return;
  const f = actions[el.dataset.act];
  if (f) { ev.preventDefault(); f(el.dataset, el); }
});
document.addEventListener("click", (ev) => {
  const tr = ev.target.closest("tr[data-href]");
  if (tr && !ev.target.closest("button,a")) go(tr.dataset.href);
});

actions.open = (d) => openPath(d.path);
actions.reveal = (d) => openPath(d.path, true);
actions.go = (d) => go(d.href);

// ---------------------------------------------------------------- Home
routes.home = async (main) => {
  const o = await refreshSide() || {};
  if (o.needs_setup && !sessionStorage.getItem("pv-setup-skipped")) { go("#/welcome"); return; }
  const h = o.history || {};
  main.innerHTML = `
    <header class="head">
      <h1>Your music</h1>
      <form class="search" id="home-search" role="search">${icon("search")}
        <label class="sr" for="home-q">Search songs</label>
        <input id="home-q" type="search" placeholder="Search your songs" autocomplete="off"></form>
    </header>
    <div class="stats">
      ${stat("songs", "Songs", num(o.songs), o.project_folder ? `in ${o.project_folder}` : "Scan a folder to start")}
      ${stat("sounds", "Plugin sounds", num(o.sounds), o.sounds ? `${num(o.unique_sounds)} different, ${num(o.sound_plugins)} plugins` : "Collect them in Plugin sounds")}
      ${stat("dupe", "Duplicate copies set aside", num(o.duplicates_ignored), "kept on disk, left out of everything")}
      ${stat("clock", "Version history", h.paused ? "Paused" : h.running ? "On" : "Off",
        h.paused ? "turn it back on in Settings" : h.running ? "keeping every save, in the background" : "turn it on in Settings")}
    </div>
    <div class="row">
      <div class="col wide"><section class="card tight"><div class="card-head"><h2>Needs attention</h2>
        ${btn("Check again", { small: true, kind: "ghost", ic: "refresh", act: "attention-refresh" })}</div>
        <div id="attention"><div class="loading"><span class="spinner"></span>Checking every sample and plugin…</div></div></section></div>
      <div class="col narrow"><section class="card tight"><h2>Recently saved</h2><div style="margin-top:8px">
        ${(o.recent || []).length ? o.recent.map((r) => `
          <a class="list-row" style="text-decoration:none;color:inherit;display:block" href="${r.path ? songLink(r.path) : "#/songs"}">
            <div style="display:flex;justify-content:space-between;gap:12px"><span class="row-title" style="font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(r.song)}</span>
            <span class="mono muted" style="font-size:12px;flex:none">${esc(r.date === today() ? r.time : r.date)}</span></div>
            <div class="row-sub">${plural(r.versions, "version")} kept</div></a>`).join("")
          : `<p class="empty">Songs you save in Live show up here once version history is on.</p>`}
      </div></section></div>
    </div>`;
  $("#home-search").onsubmit = (e) => { e.preventDefault(); go("#/songs?" + q({ q: $("#home-q").value })); };
  loadAttention(false);
  current.refresh = () => loadAttention(false);
};
function stat(ic, label, value, sub) {
  return `<section class="card" style="padding:20px"><div class="stat-label">${icon(ic)}<span>${esc(label)}</span></div>
    <div class="stat-num">${esc(value)}</div><div class="stat-sub">${esc(sub)}</div></section>`;
}
const today = () => new Date().toISOString().slice(0, 10);

async function loadAttention(refresh) {
  const box = $("#attention");
  if (!box) return;
  try {
    const a = await api("attention" + (refresh ? "?refresh=1" : ""));
    if (a.state === "working" || a.state === "idle") {
      box.innerHTML = `<div class="loading"><span class="spinner"></span>Checking every sample and plugin… this takes about a minute.</div>`;
      setTimeout(() => current.name === "home" && loadAttention(false), 2500);
      return;
    }
    if (a.state === "error") { box.innerHTML = `<p class="empty">Couldn't check: ${esc(a.error)}</p>`; return; }
    const rows = [];
    if (a.missing.samples) rows.push(["fix", "Songs with missing samples",
      `${plural(a.missing.songs, "song")}, ${plural(a.missing.samples, "sample")} not found where the project expects them`, "Find them"]);
    if (a.plugins.count) rows.push(["plug", "Plugins you don't have",
      `${plural(a.plugins.count, "plugin")} not installed, used in ${plural(a.plugins.projects, "song")}`, "See swaps"]);
    if (a.old_sets) rows.push(["live", "Old Live 8 or 9 sets",
      `${plural(a.old_sets, "set")} saved in Live 8 or 9 use plugins you don't have; each needs one save in Live 12 first`, "See them"]);
    box.innerHTML = rows.length ? rows.map(([ic, t, d, b]) => `<div class="list-row"><div class="tile">${icon(ic)}</div>
      <div class="row-text"><div class="row-title">${esc(t)}</div><div class="row-sub">${esc(d)}</div></div>
      ${btn(b, { act: "go", data: { href: "#/fix" } })}</div>`).join("")
      : `<div class="list-row"><div class="tile">${icon("check")}</div><div class="row-text"><div class="row-title">All clear</div>
         <div class="row-sub">Every sample is where its project expects it and every plugin is installed. Checked ${esc(a.at)}.</div></div></div>`;
  } catch (e) { box.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
}
actions["attention-refresh"] = () => { loadAttention(true); };
actions.snapshot = async (d) => {
  try {
    const r = await api("snapshot", { path: d.path });
    toast(r.kept ? "Version kept." : "Nothing new to keep: this exact version is already kept.");
    if (current.refresh) current.refresh(); else route();
  } catch (e) { fail(e); }
};

// ---------------------------------------------------------------- Songs
routes.songs = async (main, params) => {
  main.innerHTML = `
    <header class="head"><div class="grow"><h1>Songs</h1><p class="lead">Every song, once. Where Project Vault made a fixed copy, the copy is the one shown. Songs with version history come first.</p></div>
      <form class="search" id="song-search" role="search">${icon("search")}<label class="sr" for="song-q">Search songs</label>
        <input id="song-q" type="search" placeholder="Search by name" autocomplete="off" value="${esc(params.q || "")}"></form></header>
    <section class="card" id="song-list"><div class="loading"><span class="spinner"></span>Loading songs…</div></section>`;
  let t = null;
  const load = async () => {
    const qv = $("#song-q").value;
    const r = await api("songs?" + q({ q: qv }));
    const box = $("#song-list");
    if (!box) return;
    box.innerHTML = r.songs.length ? `
      <div class="table-wrap"><table class="table"><thead><tr><th>Song</th><th class="num">Versions</th><th>Last saved</th><th>Live</th></tr></thead><tbody>
      ${r.songs.map((s) => `<tr class="click" data-href="${esc(songLink(s.path))}">
        <td class="name"><a href="${esc(songLink(s.path))}" style="color:inherit;text-decoration:none">${esc(s.name)}</a>
          ${s.copy ? `<span class="chip" style="margin-left:8px">${s.copy === "swapped" ? "swapped copy" : "relinked copy"}</span>` : ""}</td>
        <td class="num">${s.versions ? num(s.versions) : '<span class="muted">–</span>'}</td>
        <td class="muted when">${esc(s.last || (s.modified ? new Date(s.modified * 1000).toISOString().slice(0, 16).replace("T", " ") : ""))}</td>
        <td class="muted">${esc((s.live || "").replace(/^Ableton Live /, ""))}</td></tr>`).join("")}
      </tbody></table></div>${r.total > r.songs.length ? `<p class="empty">Showing ${num(r.songs.length)} of ${num(r.total)}. Search to narrow it down.</p>` : ""}`
      : `<p class="empty">${qv ? "No songs match." : "No songs yet. Go to Fix projects and read your projects folder."}</p>`;
  };
  $("#song-search").onsubmit = (e) => e.preventDefault();
  $("#song-q").oninput = () => { clearTimeout(t); t = setTimeout(() => load().catch(fail), 200); };
  await load();
  current.refresh = load;
};

// ---------------------------------------------------------------- one song
routes.song = async (main, params) => {
  const path = params.path;
  const s = await api("song?" + q({ path }));
  const total = s.versions.length;
  main.innerHTML = `
    <div><a class="crumb" href="#/songs">Songs</a></div>
    <header class="head"><div class="grow"><h1>${esc(s.name)}</h1><div class="path">${esc(s.path)}</div>
      <div class="chips">
        ${s.live ? `<span class="chip">${esc(s.live.replace(/^Ableton /, ""))}</span>` : ""}
        ${s.tempo ? `<span class="chip">${esc(Math.round(s.tempo * 100) / 100)} BPM</span>` : ""}
        <span class="chip">${plural(total, "version")} kept</span>
        ${s.tracks != null ? `<span class="chip">${plural(s.tracks, "track")}</span>` : ""}
        ${s.sounds ? `<span class="chip">${plural(s.sounds, "plugin sound")}</span>` : ""}
        ${s.renamed_from.length ? `<span class="chip">was ${esc(s.renamed_from.join(", "))}</span>` : ""}
        ${s.branched_from ? `<span class="chip">copy of ${esc(s.branched_from)}</span>` : ""}
        ${s.exists ? "" : `<span class="chip amber">${icon("warn")} file not found</span>`}
      </div></div>
      <div class="btns">
        ${s.exists ? btn("Show in folder", { ic: "folder", act: "reveal", data: { path } }) : ""}
        ${s.exists ? btn("Keep a version now", { ic: "clock", act: "snapshot", data: { path } }) : ""}
        ${s.sounds ? btn("Save its sounds", { ic: "download", act: "export-song", data: { song: s.name, id: s.song_id } }) : ""}
        ${s.exists ? btn("Open in Live", { kind: "primary", ic: "live", act: "open", data: { path } }) : ""}
      </div></header>
    <div class="row">
      <div class="col wide"><section class="card tight"><h2>Every version, newest first</h2><div style="margin-top:10px">
        ${total ? s.versions.map((v) => versionRow(v, total, path)).join("")
          : `<p class="empty">No versions kept yet. Turn on version history in Settings, or click “Keep a version now”.</p>`}
      </div></section></div>
      ${s.plugins ? `<div class="col narrow"><section class="card"><h2>Plugins in this song</h2>
        <div class="chips">${s.plugins.length ? s.plugins.map((p) => `<span class="chip">${esc(p)}</span>`).join("") : '<span class="muted">None</span>'}</div>
        <p class="lead" style="margin-top:14px">${plural(s.samples || 0, "sample")} used.</p></section></div>` : ""}
    </div>`;
  current.refresh = () => route();
  if (params.v) {
    const el = $("#v" + params.v);
    if (el) { el.classList.add("highlight"); el.scrollIntoView({ block: "center" }); }
  }
};
function versionRow(v, total, path) {
  const cur = v.n === total;
  return `<div class="version" id="v${v.n}">
    <div class="vnum${cur ? " current" : ""}">${v.n}</div>
    <div class="vbody">
      <div class="vtop"><span class="vwhen">${esc(v.when)}</span>
        ${cur ? '<span class="chip solid">Newest</span>' : ""}
        ${v.source === "Live backup" ? '<span class="chip">from Live’s Backup folder</span>' : ""}
        ${v.label ? `<span class="chip amber">${icon("tag")}${esc(v.label)}</span>` : ""}</div>
      <div class="vwhat">${esc(v.what)}</div>
      <div class="diff" id="diff${v.n}" hidden></div>
      <form class="label-edit" id="label${v.n}" hidden><label class="sr" for="lt${v.n}">Name for version ${v.n}</label>
        <input class="text-input" id="lt${v.n}" maxlength="120" placeholder="e.g. sent to label" value="${esc(v.label)}">
        <button class="btn primary small" type="submit">Save</button></form>
      <div class="btns">
        ${v.n > 1 ? btn("What changed", { small: true, ic: "compare", act: "diff", data: { path, n: v.n } }) : ""}
        ${btn(v.label ? "Rename" : "Name it", { small: true, ic: "tag", act: "label", data: { path, n: v.n } })}
        ${cur ? "" : btn("Get this version back", { small: true, ic: "restore", act: "restore", data: { path, n: v.n, when: v.when } })}
      </div></div></div>`;
}
actions.diff = async (d) => {
  const box = $("#diff" + d.n);
  if (!box.hidden) { box.hidden = true; return; }
  box.hidden = false; box.textContent = "Comparing…";
  try {
    const r = await api("diff?" + q({ path: d.path, a: d.n - 1, b: d.n }));
    box.innerHTML = `<div class="label-caps" style="margin-bottom:6px">Compared with version ${d.n - 1}</div>`
      + (r.lines.length ? r.lines.map((l) => `<div>${esc(l)}</div>`).join("") : "<div>No changes Project Vault can see (mixer, automation or device settings).</div>");
  } catch (e) { box.textContent = e.message; }
};
actions.label = (d) => {
  const f = $("#label" + d.n);
  f.hidden = !f.hidden;
  if (f.hidden) return;
  const input = $("#lt" + d.n);
  input.focus(); input.select();
  f.onsubmit = async (e) => {
    e.preventDefault();
    try { await api("label", { path: d.path, n: Number(d.n), text: input.value }); toast(input.value ? "Version named." : "Name removed."); route(); }
    catch (err) { fail(err); }
  };
};
actions.restore = async (d) => {
  if (!await ask(`Get version ${d.n} back?`,
    `Version ${d.n} (${d.when}) is saved as a new file next to your song, named “(restored …)”. Your song itself isn't changed.`, "Get it back")) return;
  try {
    const r = await api("restore", { path: d.path, n: Number(d.n) });
    toast("Saved as " + r.file.split(/[\\/]/).pop(), { action: { label: "Open in Live", run: () => openPath(r.file) }, ms: 12000 });
  } catch (e) { fail(e); }
};
actions["export-song"] = async (d) => {
  try {
    const r = await api("sounds/export", { song: d.song, song_id: d.id });
    toast(`Saved ${plural(r.count, "preset file")}.`, { action: { label: "Open folder", run: () => openPath(r.folder) }, ms: 12000 });
  } catch (e) { fail(e); }
};


// ---------------------------------------------------------------- first run
const Setup = { project: "", samples: [], startup: "windows", history: true, sugg: null, custom: [] };
routes.welcome = async (main) => {
  if (!Setup.sugg) {
    main.innerHTML = `<div class="loading"><span class="spinner"></span>Looking for your Live projects…</div>`;
    Setup.sugg = await api("setup");
    const top = Setup.sugg.projects[0];
    if (top && !Setup.project) Setup.project = top.path;
    if (Setup.sugg.startup && Setup.sugg.startup !== "off") Setup.startup = Setup.sugg.startup;
  }
  drawWelcome(main);
};
function drawWelcome(main = $("#main")) {
  const g = Setup.sugg;
  const projects = [...g.projects, ...Setup.custom.filter((c) => !g.projects.some((x) => x.path === c.path))];
  const samples = [...g.samples, ...Setup.samples.filter((p) => !g.samples.some((x) => x.path === p)).map((p) => ({ label: "Your folder", path: p }))];
  main.innerHTML = `
    <header class="head welcome-head"><img src="logo.png" alt="" width="56" height="56">
      <div class="grow"><h1>Welcome to Project Vault</h1>
      <p class="lead">Three quick choices, then it reads your projects. Nothing in your projects is changed: fixes are always written as copies.</p></div></header>

    <section class="card"><div class="step"><div class="step-num${Setup.project ? " done" : ""}">1</div><div class="step-body">
      <div><h2>Where are your Live projects?</h2><p class="lead">${g.projects.length ? "These folders have Live Sets in them. Pick the one that holds your songs; Project Vault looks in every folder inside it." : "Choose the folder that holds your Live projects. Project Vault looks in every folder inside it."}</p></div>
      ${projects.length ? `<div class="what-grid" role="radiogroup" aria-label="Projects folder">${projects.map((f) => `
        <label class="what"><input type="radio" name="proj" data-act="setup-project" value="${esc(f.path)}"${Setup.project === f.path ? " checked" : ""}>
        <span><strong class="mono-path">${esc(f.path)}</strong><span>${f.sets != null ? plural(f.sets, "Live Set") : "Chosen by you"}</span></span></label>`).join("")}</div>` : ""}
      <div class="btns">${btn(projects.length ? "Choose another folder" : "Choose your projects folder", { kind: projects.length ? "secondary" : "primary", ic: "folder", act: "setup-pick-project" })}</div>
    </div></div></section>

    <section class="card"><div class="step"><div class="step-num${Setup.samples.length ? " done" : ""}">2</div><div class="step-body">
      <div><h2>Where do your samples live? <span class="muted" style="font-weight:400">Optional</span></h2>
        <p class="lead">When a project can't find a sample, Project Vault searches here for the exact same recording. Sample packs, Splice, old drives. You can add more later.</p></div>
      ${samples.length ? `<div class="what-grid">${samples.map((f) => `
        <label class="what"><input type="checkbox" data-act="setup-sample" value="${esc(f.path)}"${Setup.samples.includes(f.path) ? " checked" : ""}>
        <span><strong>${esc(f.label)}</strong><span class="mono-path">${esc(f.path)}</span></span></label>`).join("")}</div>` : ""}
      <div class="btns">${btn("Add a folder", { ic: "plus", act: "setup-pick-sample" })}</div>
    </div></div></section>

    <section class="card"><div class="step"><div class="step-num done">3</div><div class="step-body">
      <div><h2>When should Project Vault run?</h2><p class="lead">It lives in your taskbar's hidden icons (the ^ by the clock) and keeps a copy of every save, so you can go back to any version of a song.</p></div>
      <div class="what-grid" role="radiogroup" aria-label="Start Project Vault">
        ${[["windows", "When Windows starts", "Always ready, and every save is kept. Recommended."],
           ["live", "When I open Ableton Live", "Waits quietly and shows up when Live opens."],
           ["off", "Only when I open it", "Nothing runs until you open Project Vault yourself."]].map(([m, t, sub]) => `
          <label class="what"><input type="radio" name="setup-startup" data-act="setup-startup" value="${m}"${Setup.startup === m ? " checked" : ""}>
          <span><strong>${esc(t)}</strong><span>${esc(sub)}</span></span></label>`).join("")}
      </div>
      <div class="setting" style="padding:0;border:0"><div class="setting-text"><h3>Keep a version of every save</h3>
        <p class="lead">Each time you save in Live, a copy goes into your version history.</p></div>
        <button type="button" class="switch" role="switch" aria-checked="${Setup.history}" aria-label="Keep a version of every save" data-act="setup-history"></button></div>
    </div></div></section>

    <div class="btns welcome-go">${btn("Start", { kind: "primary", ic: "check", act: "setup-finish", disabled: !Setup.project })}
      ${btn("Skip for now", { kind: "ghost", act: "setup-skip" })}
      <span class="muted">${Setup.project ? `Reads every Live Set in <span class="mono">${esc(Setup.project)}</span>. Bigger libraries take a few minutes.` : "Choose your projects folder first."}</span></div>`;
}
document.addEventListener("change", (ev) => {
  const el = ev.target;
  if (!el.dataset || !el.dataset.act || current.name !== "welcome") return;
  if (el.dataset.act === "setup-project") Setup.project = el.value;
  else if (el.dataset.act === "setup-startup") Setup.startup = el.value;
  else if (el.dataset.act === "setup-sample") {
    Setup.samples = el.checked ? [...new Set([...Setup.samples, el.value])] : Setup.samples.filter((p) => p !== el.value);
  } else return;
  drawWelcome();
});
actions["setup-history"] = () => { Setup.history = !Setup.history; drawWelcome(); };
actions["setup-pick-project"] = async () => {
  toast("Choose the folder that holds your Live projects…", { ms: 4000 });
  const r = await api("pick-folder", { title: "Choose your projects folder" }).catch(fail);
  if (!r || !r.folder) return;
  if (!Setup.custom.some((c) => c.path === r.folder)) Setup.custom.push({ path: r.folder, sets: null });
  Setup.project = r.folder;
  drawWelcome();
};
actions["setup-pick-sample"] = async () => {
  toast("Choose a folder or drive where samples live…", { ms: 4000 });
  const r = await api("pick-folder", { title: "Choose a folder to search for samples" }).catch(fail);
  if (!r || !r.folder) return;
  Setup.samples = [...new Set([...Setup.samples, r.folder])];
  drawWelcome();
};
actions["setup-skip"] = () => { sessionStorage.setItem("pv-setup-skipped", "1"); go("#/home"); };
actions["setup-finish"] = async (d, el) => {
  el.disabled = true;
  try {
    await api("setup", { project_folders: [Setup.project], sample_folders: Setup.samples, startup: Setup.startup, history: Setup.history });
    toast("All set. Reading your projects now; you can use Project Vault while it works.", { ms: 9000 });
    Job.since = 0; $("#job-log").textContent = ""; Job.poll();
    go("#/home");
  } catch (e) { el.disabled = false; fail(e); }
};


// ---------------------------------------------------------------- plugin shopping list
const Shop = { filter: "all", ticked: new Set() };
try { Shop.ticked = new Set(JSON.parse(localStorage.getItem("pv-shop-ticked") || "[]")); } catch (e) { /* private window */ }
const shopKey = (i) => `${i.name}|${i.format}`;
routes.shopping = async (main) => {
  const r = await api("shopping");
  if (r.state !== "done") {
    main.innerHTML = `<header class="head"><div class="grow"><h1>Plugin shopping list</h1></div></header>
      ${r.state === "error" ? `<div class="card"><p class="bad-text">Couldn't check your plugins: ${esc(r.error)}</p></div>`
        : `<div class="loading"><span class="spinner"></span>Checking which plugins your songs need… this runs in the background and takes a minute.</div>`}`;
    if (r.state !== "error") setTimeout(() => { if (current.name === "shopping") route(); }, 3000);
    return;
  }
  Shop.data = r;
  drawShop(main);
};
function drawShop(main = $("#main")) {
  const r = Shop.data, all = r.items;
  const items = all.filter((i) => Shop.filter === "all" || i.kind === Shop.filter);
  const groups = new Map();
  for (const i of items) {
    const k = i.vendor || "";
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(i);
  }
  const order = [...groups.keys()].sort((a, b) => (a === "") - (b === "") ||
    groups.get(b).reduce((n, i) => n + i.projects, 0) - groups.get(a).reduce((n, i) => n + i.projects, 0));
  const have = all.filter((i) => i.kind === "have").length;
  const wins = all.filter((i) => i.only_thing).slice(0, 8);
  const link = (url, text, cls = "") => `<button type="button" class="linkish ${cls}" data-act="open-url" data-url="${esc(url)}">${text}</button>`;
  const row = (i) => {
    const done = Shop.ticked.has(shopKey(i));
    return `<li class="shop-item${done ? " done" : ""}">
      <label class="shop-tick"><input type="checkbox" data-act="shop-tick" value="${esc(shopKey(i))}"${done ? " checked" : ""}>
        <span><strong>${esc(i.name)}</strong> <span class="fmt">${esc(i.format)}</span></span></label>
      <div class="shop-meta"><span class="chip${i.kind === "have" ? " amber" : ""}">${esc(i.label)}</span>
        <span>${plural(i.projects, "song")}</span>
        ${i.only_thing ? `<strong>Only thing missing in ${plural(i.only_thing, "song")}</strong>` : ""}
        ${link(i.search, `${icon("search")}Find it`)}</div>
      <div class="row-sub">${esc(i.advice)}${i.folder_hint ? ` It was installed in a folder named “${esc(i.folder_hint)}”.` : ""}</div>
      ${i.examples.length ? `<div class="row-sub muted">Used in ${i.examples.map(esc).join(", ")}${i.projects > i.examples.length ? ` and ${num(i.projects - i.examples.length)} more` : ""}</div>` : ""}
    </li>`;
  };
  main.innerHTML = `
    <header class="head"><div class="grow"><h1>Plugin shopping list</h1>
      <p class="lead">Plugins your songs use that aren't ready on this computer, by company, with where to get them. The ones at the top unlock the most songs. Checked at ${esc(r.at)}.</p></div>
      <div class="btns">${btn("Print or save", { ic: "file", act: "shop-print" })}${btn("Check again", { ic: "refresh", act: "shop-recheck" })}</div></header>
    <div class="stats">
      <div class="stat"><b>${num(r.songs.ready || 0)} of ${num(r.songs.total || 0)}</b><span>songs have every plugin</span></div>
      <div class="stat"><b>${num(have)}</b><span>you already own in some form (other format, older version)</span></div>
      <div class="stat"><b>${num(all.length - have)}</b><span>not installed: reinstall if you own them, or buy</span></div>
    </div>
    ${wins.length ? `<section class="card"><h2>Biggest wins</h2><p class="lead">Each of these is the only plugin missing from some songs: get it and those songs open complete.</p>
      <ol class="wins">${wins.map((i) => `<li><strong>${esc(i.name)}</strong> <span class="muted">${esc(i.vendor || "")}</span> completes ${plural(i.only_thing, "song")}</li>`).join("")}</ol></section>` : ""}
    <div class="seg" role="radiogroup" aria-label="Show">
      ${[["all", `All (${all.length})`], ["have", `You own these (${have})`], ["missing", `Not installed (${all.length - have})`]].map(([k, t]) =>
        `<button type="button" role="radio" aria-checked="${Shop.filter === k}" data-act="shop-filter" data-f="${k}">${esc(t)}</button>`).join("")}
    </div>
    ${order.length ? order.map((v) => {
      const list = groups.get(v), site = (list.find((i) => i.site) || {}).site;
      return `<section class="card shop-co"><div class="shop-co-head"><div class="grow"><h2>${esc(v || "Company not known")}</h2>
          <span class="muted">${plural(list.length, "plugin")} · used in ${plural(list.reduce((n, i) => n + i.projects, 0), "song")}</span></div>
          ${site ? btn(`Visit ${site.replace(/^https?:\/\/(www\.)?/, "")}`, { ic: "download", act: "open-url", data: { url: site } }) : ""}</div>
        <ul class="shop-list">${list.map(row).join("")}</ul></section>`;
    }).join("") : `<div class="card"><p class="muted">Nothing here.</p></div>`}`;
}
actions["shop-filter"] = (d) => { Shop.filter = d.f; drawShop(); };
actions["shop-print"] = async () => {
  const r = await api("shopping/print", {}).catch(fail);
  if (r) toast("Opened in your browser. Print it or save it from there.");
};
actions["shop-recheck"] = async () => { await api("attention?refresh=1").catch(() => null); route(); };
document.addEventListener("change", (ev) => {
  const el = ev.target;
  if (!el.dataset || el.dataset.act !== "shop-tick") return;
  if (el.checked) Shop.ticked.add(el.value); else Shop.ticked.delete(el.value);
  try { localStorage.setItem("pv-shop-ticked", JSON.stringify([...Shop.ticked])); } catch (e) { /* fine */ }
  el.closest(".shop-item").classList.toggle("done", el.checked);
});

// ---------------------------------------------------------------- Fix projects
routes.fix = async (main) => {
  const [settings, att] = await Promise.all([api("settings"), api("attention")]);
  const folder = settings.project_folders[0] || "";
  const samplesDone = att.state === "done";
  const a = samplesDone ? att : null;
  main.innerHTML = `
    <header class="head"><div class="grow"><h1>Fix projects</h1>
      <p class="lead">Four steps, top to bottom. Your original projects are never changed: fixed copies are written next to them, in Relinked\\ and Swapped\\ folders.</p></div></header>

    <section class="card"><div class="step"><div class="step-num${folder ? " done" : ""}">1</div><div class="step-body">
      <div><h2>Read your projects</h2><p class="lead">Project Vault reads every Live Set in your projects folder. Run it again after adding or moving songs.</p></div>
      <div class="folder-list">${folder ? `<div class="folder">${icon("folder")}<span>${esc(folder)}</span></div>` : `<p class="muted">No projects folder chosen yet.</p>`}</div>
      <div class="btns">${btn(folder ? "Change folder" : "Choose your projects folder", { ic: "folder", act: "pick-projects" })}
        ${folder ? btn("Read projects", { kind: "primary", ic: "refresh", act: "job", data: { kind: "scan", args: JSON.stringify([folder]) } }) : ""}
        ${folder ? btn("Find duplicate copies", { ic: "dupe", act: "job", data: { kind: "duplicates", args: JSON.stringify([folder, "--ignore"]) },
          title: "Identical copies are kept on disk but left out of everything else" }) : ""}</div>
    </div></div></section>

    <section class="card"><div class="step"><div class="step-num${a && !a.missing.samples ? " done" : ""}">2</div><div class="step-body">
      <div><h2>Find missing samples</h2><p class="lead">${a ? (a.missing.samples
        ? `${plural(a.missing.samples, "sample")} in ${plural(a.missing.songs, "song")} aren't where their projects expect them.`
        : "Every sample is where its project expects it.") : "Checking…"} Project Vault searches the folders below and only accepts a file that's the same recording (Live's own size and fingerprint).</p></div>
      <div class="folder-list">${settings.sample_folders.map((f, i) => `<div class="folder">${icon("folder")}<span>${esc(f)}</span>
        <button type="button" class="btn ghost small" data-act="remove-sample-folder" data-i="${i}" aria-label="Remove ${esc(f)}">${icon("x")}</button></div>`).join("")
        || `<p class="muted">Add the drives or folders where your samples live (sample packs, Splice, old drives).</p>`}</div>
      <div class="btns">${btn("Add a folder to search", { ic: "plus", act: "add-sample-folder" })}
        ${btn("Search these folders", { kind: "primary", ic: "search", act: "job", disabled: !settings.sample_folders.length,
          data: { kind: "relink", args: JSON.stringify(settings.sample_folders) } })}
        ${btn("Write fixed copies", { ic: "check", act: "job", data: { kind: "fix", args: "[]" }, title: "Uses the last search's results" })}</div>
      ${a && a.missing.list.length ? `<details><summary class="muted" style="cursor:pointer">Songs with missing samples (${num(a.missing.songs)})</summary>
        <table class="table" style="margin-top:8px"><tbody>${a.missing.list.map((p) => `<tr class="click" data-href="${esc(songLink(p.path))}">
          <td class="name">${esc(p.name)}</td><td class="num muted">${plural(p.count, "sample")}</td></tr>`).join("")}</tbody></table></details>` : ""}
    </div></div></section>

    <section class="card"><div class="step"><div class="step-num${a && !a.plugins.count ? " done" : ""}">3</div><div class="step-body">
      <div><h2>Swap plugins you don't have</h2><p class="lead">${a ? (a.plugins.count
        ? `${plural(a.plugins.count, "plugin")} your songs use aren't installed; ${num(a.plugins.swappable)} of them have another version on this computer that a swap can use. Settings come across only for swaps tested in Live, and the old settings are always saved beside the copy.`
        : "Every plugin your projects use is installed.") : "Checking…"}</p></div>
      ${a && a.plugins.list.length ? `<div class="table-wrap"><table class="table plug-table"><thead><tr><th>Plugin you don't have</th><th>What happens</th><th class="num">Songs</th></tr></thead><tbody>
        ${a.plugins.list.slice(0, 80).map((p) => `<tr><td><strong>${esc(p.name)}</strong> <span class="muted">${esc(p.fmt)}</span>
          ${p.free ? `<div class="row-sub">${esc(p.free)}</div>` : ""}</td>
          <td>${p.swap_to ? `<span class="chip amber">Swaps to ${esc(p.swap_to)}</span>` : '<span class="muted">Not installed: nothing to swap to</span>'}</td>
          <td class="num">${num(p.projects)}</td></tr>`).join("")}</tbody></table></div>
        ${a.plugins.list.length > 80 ? `<p class="muted">… and ${num(a.plugins.list.length - 80)} more you don't have. The shopping list has them all, by company, with links.</p>` : ""}` : ""}
      <div class="btns">${btn("Show the planned swaps", { ic: "compare", act: "job", data: { kind: "swap", args: JSON.stringify(["--list"]) } })}
        ${btn("Write swapped copies", { kind: "primary", ic: "check", act: "job", data: { kind: "swap", args: "[]" }, disabled: !(a && a.plugins.count) })}
        ${btn("Shopping list", { ic: "plug", act: "go", data: { href: "#/shopping" }, title: "Which plugins to get, by company, with links" })}</div>
    </div></div></section>

    <section class="card" id="resave-card"><div class="step"><div class="step-num" id="resave-num">4</div><div class="step-body">
      <div><h2>Old Live 8 and 9 sets</h2><p class="lead">${a ? (a.old_sets
        ? `${plural(a.old_sets, "song")} last saved in Live 8 or 9 use plugins you don't have. Most swaps work on those as they are; only a swap that puts in a VST3 plugin needs the set saved once in Live 12 first. Project Vault works out which ones, opens them in Live one at a time, and moves on as soon as you've saved each.`
        : "None of your songs were last saved in Live 8 or 9 with plugins you don't have.") : "Checking…"}</p></div>
      <div id="resave-box"></div>
    </div></div></section>`;
  Resave.draw(await api("resave").catch(() => null), a);
  current.refresh = () => route();
};
// Step 4: the guided resave. The server opens each set in Live and watches the file; this only shows it.
const Resave = {
  last: "",
  att: null,
  draw(r, att) {
    if (att !== undefined) this.att = att;
    const box = $("#resave-box");
    if (!box || !r) return;
    const key = JSON.stringify(r);
    if (key === this.last && box.childElementCount) return;
    this.last = key;
    const done = r.total && !r.left;
    $("#resave-num").classList.toggle("done", !!(done && !r.skipped) || (this.att && !this.att.old_sets && !r.total));
    const kbd = (k) => `<kbd>${esc(k)}</kbd>`;
    const how = `<ol class="how">
      <li>Save the song you're working on in Live (Project Vault won't open anything over unsaved changes).</li>
      <li>Click <strong>Start</strong>. The first set opens in Live.</li>
      <li>In Live: <strong>File › Save Live Set As…</strong>, click <strong>Save</strong>, then <strong>Yes</strong> if it asks to replace it.</li>
      <li>The next set opens by itself. Stop any time; next time you carry on where you left off.</li></ol>`;
    const bar = (n, of) => `<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="${of}" aria-valuenow="${n}"><span style="width:${of ? Math.round(100 * n / of) : 0}%"></span></div>`;
    const rows = r.sets.map((x, i) => `<tr${i === r.current && x.state === "open" ? ' class="now"' : ""}>
      <td class="name">${esc(x.name)}<div class="row-sub">${esc(x.folder)}</div></td>
      <td class="num">${{ saved: `<span class="chip amber">${icon("check")}Saved</span>`, open: '<span class="chip solid">Open in Live</span>',
        skipped: '<span class="chip">Skipped</span>', todo: '<span class="muted">To do</span>' }[x.state] || ""}</td>
      <td class="num"><button type="button" class="btn ghost small" data-act="reveal" data-path="${esc(x.path)}" title="Show in Explorer" aria-label="Show ${esc(x.name)} in Explorer">${icon("folder")}</button></td></tr>`).join("");
    const list = r.total ? `<details${r.state === "ready" ? " open" : ""}><summary class="muted" style="cursor:pointer">The ${plural(r.total, "set")} (${num(r.saved)} saved${r.skipped ? `, ${num(r.skipped)} skipped` : ""})</summary>
      <div class="table-wrap"><table class="table" style="margin-top:8px"><tbody>${rows}</tbody></table></div></details>` : "";
    const f = r.find || {};
    const fin = r.finish || {};
    let html = "";
    if (!r.windows) html += `<p class="muted">Opening sets in Live works on Windows. Here you can still see the list.</p>`;
    if (f.state === "finding") {
      html += `<div class="resave-now"><div class="row-sub"><span class="spinner"></span> Checking which sets need a save… ${f.of ? `${num(f.n)} of ${num(f.of)}` : ""}</div>${bar(f.n, f.of)}
        <p class="row-sub">Where a set has no fixed copy yet, Project Vault makes one in Relinked\\ first, so your originals are never opened.</p></div>`;
    } else if (f.state === "error") {
      html += `<p class="bad-text">Couldn't work out the list: ${esc(f.error)}</p>`;
    }
    if (f.state !== "finding") {
      if (!r.total) {
        html += `${f.state === "done" ? `<p class="muted">Checked at ${esc(f.at)}: none of your sets need a save in Live 12. Their swaps work as they are, or there's nothing installed to swap to yet.</p>` : how}
          <div class="btns">${btn(f.state === "done" ? "Check again" : "Find the sets that need a save", { kind: f.state === "done" ? "secondary" : "primary", ic: "search", act: "resave-find" })}</div>`;
      } else if (r.state === "running" || r.state === "waiting") {
        const cur = r.sets[r.current] || {};
        const pos = r.saved + r.skipped + 1;
        html += `<div class="resave-now${r.state === "waiting" ? " waiting" : ""}">
          <div class="label-caps">Set ${num(Math.min(pos, r.total))} of ${num(r.total)}</div>
          ${r.state === "waiting" ? `<div class="now-name">${icon("warn")} Waiting for you</div><p>${esc(r.note)}</p>`
            : `<div class="now-name">${esc(cur.name || "")}</div>
              <p>In Live: <strong>File › Save Live Set As…</strong>, <strong>Save</strong>, then <strong>Yes</strong> if it asks to replace it. The next set opens as soon as it's saved.</p>
              <p class="row-sub">Shortcut: ${kbd("Ctrl")}+${kbd("Shift")}+${kbd("S")}, unless something else on your PC uses it (graphics card replay tools often do).</p>
              ${r.note ? `<p class="bad-text">${esc(r.note)}</p>` : ""}`}
          ${bar(r.saved + r.skipped, r.total)}
          <div class="btns">${r.state === "running" ? btn("Open it again", { ic: "live", act: "resave", data: { what: "reopen" }, title: "If you closed it in Live" }) : ""}
            ${btn("Skip this one", { act: "resave", data: { what: "skip" } })}
            ${btn("Stop", { ic: "x", act: "resave", data: { what: "stop" } })}</div></div>`;
      } else if (!done) {
        html += `<p>${r.left === r.total ? `${plural(r.total, "set")} need one save in Live 12.` : `${num(r.left)} of ${plural(r.total, "set")} still need a save.`}
          ${r.made && f.state === "done" ? ` (Made ${plural(r.made, "copy", "copies")} in Relinked\\ first, so no original is opened.)` : ""}</p>
          ${r.live.unsaved ? `<p class="bad-text">${icon("warn")} \u201c${esc(r.live.name)}\u201d has unsaved changes in Live. Save it first.</p>` : ""}
          ${how}
          <div class="btns">${btn(r.saved > r.before || r.skipped ? "Carry on" : "Start", { kind: "primary", ic: "live", act: "resave", data: { what: "start" }, disabled: !r.windows })}
            ${btn("Check the list again", { ic: "refresh", act: "resave-find" })}</div>`;
      } else {
        html += `<p><strong>${r.skipped ? `${num(r.saved)} of ${plural(r.total, "set")} are saved in Live 12; ${num(r.skipped)} skipped.` : `All ${plural(r.total, "set")} are saved in Live 12.`}</strong>
          Now Project Vault can write their swapped copies: it reads your projects again, writes a swapped copy of each of these sets, then reads again so every list is up to date. A swapped copy you've already saved in Live is kept as it is.</p>`;
        if (fin.state === "working") {
          html += `<div class="resave-now"><div class="row-sub"><span class="spinner"></span> ${["", "Reading your projects", "Writing swapped copies", "Reading your projects again"][fin.step] || "Working"} (step ${fin.step} of 3)</div>${bar(fin.step - 1, 3)}</div>`;
        } else if (fin.state === "done") {
          html += `<div class="resave-now"><div class="now-name">${icon("check")} ${fin.written.length ? `Wrote ${plural(fin.written.length, "swapped copy", "swapped copies")}` : "No new swapped copies were needed"}</div>
            ${fin.written.length ? `<p class="row-sub">${fin.written.slice(0, 12).map(esc).join(" · ")}${fin.written.length > 12 ? " …" : ""}</p>` : ""}
            ${fin.notes.map((n) => `<p class="row-sub">${esc(n)}</p>`).join("")}
            <p class="row-sub">Open one in Live to check it before relying on it. Originals weren't changed.</p></div>`;
        } else if (fin.state === "error") {
          html += `<p class="bad-text">${esc(fin.error)}</p>`;
        }
        html += `<div class="btns">${fin.state === "working" ? "" : btn(fin.state === "done" ? "Write them again" : "Write swapped copies of these sets", { kind: fin.state === "done" ? "secondary" : "primary", ic: "check", act: "resave-finish", disabled: !r.saved })}
          ${r.skipped ? btn("Go through the skipped ones", { ic: "live", act: "resave", data: { what: "start" } }) : ""}
          ${btn("Check the list again", { ic: "refresh", act: "resave-find" })}</div>`;
      }
    }
    box.innerHTML = html + list;
  },
  busy(r) {
    return r && (r.state === "running" || r.state === "waiting" || (r.find || {}).state === "finding" || (r.finish || {}).state === "working");
  },
  async poll() {
    if (current.name !== "fix" || !$("#resave-box")) return;
    const r = await api("resave").catch(() => null);
    this.draw(r);
  },
};
actions["resave-find"] = async () => { Resave.draw(await api("resave/find", {}).catch(fail)); };
actions["resave-finish"] = async () => { Resave.draw(await api("resave/finish", {}).catch(fail)); };
actions.resave = async (d) => {
  const r = await api("resave/" + d.what, {}).catch(fail);
  Resave.draw(r);
  if (d.what === "stop" && r) toast("Stopped. Your place is kept: Carry on picks up from the next set.");
};
setInterval(() => { if (!document.hidden) Resave.poll(); }, 2000);

actions.job = (d) => {
  const args = JSON.parse(d.args || "[]");
  Job.start(d.kind, args, (j) => {
    if (j.state === "done") toast(`${j.title}: done.`);
  });
};
actions["pick-projects"] = async () => {
  toast("Choose the folder that holds your Live projects…", { ms: 4000 });
  const r = await api("pick-folder", { title: "Choose your projects folder" }).catch(fail);
  if (!r || !r.folder) return;
  const s = await api("settings");
  await api("settings", { project_folders: [r.folder, ...s.project_folders.filter((f) => f !== r.folder)].slice(0, 1) }).catch(fail);
  route();
};
actions["add-sample-folder"] = async () => {
  toast("Choose a folder or drive where samples live…", { ms: 4000 });
  const r = await api("pick-folder", { title: "Choose a folder to search for samples" }).catch(fail);
  if (!r || !r.folder) return;
  const s = await api("settings");
  if (!s.sample_folders.includes(r.folder)) await api("settings", { sample_folders: [...s.sample_folders, r.folder] }).catch(fail);
  route();
};
actions["remove-sample-folder"] = async (d) => {
  const s = await api("settings");
  s.sample_folders.splice(Number(d.i), 1);
  await api("settings", { sample_folders: s.sample_folders }).catch(fail);
  route();
};

// ---------------------------------------------------------------- Plugin sounds
const soundState = { plugin: "", q: "", filter: "" };
routes.sounds = async (main) => {
  main.innerHTML = `
    <header class="head"><div class="grow"><h1>Plugin sounds</h1>
      <p class="lead">Every sound you've dialled in, from every song, kept as a preset file the plugin loads itself.</p></div>
      <form class="search" id="snd-search" role="search">${icon("search")}<label class="sr" for="snd-q">Search sounds</label>
        <input id="snd-q" type="search" placeholder="Search sounds, songs, tracks" autocomplete="off" value="${esc(soundState.q)}"></form></header>
    <div class="sounds">
      <section class="card plug-list"><div class="label-caps" style="padding:0 12px" id="plug-count">Plugins</div>
        <label class="sr" for="plug-filter">Filter plugins</label>
        <input class="text-input" id="plug-filter" placeholder="Filter plugins" value="${esc(soundState.filter)}" autocomplete="off">
        <div class="plug-scroll" id="plug-scroll"></div></section>
      <div class="sound-area" id="sound-area"><div class="loading"><span class="spinner"></span>Loading sounds…</div></div>
    </div>`;
  let t = null;
  $("#snd-search").onsubmit = (e) => e.preventDefault();
  $("#snd-q").oninput = () => { soundState.q = $("#snd-q").value; clearTimeout(t); t = setTimeout(() => loadSounds().catch(fail), 200); };
  $("#plug-filter").oninput = () => { soundState.filter = $("#plug-filter").value; drawPlugins(); };
  await loadSounds();
  current.refresh = loadSounds;
};
let soundData = null;
async function loadSounds() {
  soundData = await api("sounds?" + q({ plugin: soundState.plugin, q: soundState.q }));
  drawPlugins();
  const area = $("#sound-area");
  if (!area) return;
  const d = soundData;
  if (!d.total) {
    const o = overviewCache || {};
    area.innerHTML = `<section class="card"><h2>No sounds collected yet</h2>
      <p class="lead">Project Vault reads every plugin's settings out of your songs. It takes a few minutes the first time; after that, version history adds each song's sounds as you save.</p>
      <div class="btns" style="margin-top:14px">${btn("Collect sounds from my projects", { kind: "primary", ic: "download", act: "job",
        data: { kind: "presets", args: JSON.stringify([o.project_folder || ""]) }, disabled: !o.project_folder })}</div></section>`;
    return;
  }
  const title = soundState.plugin || "All plugins";
  area.innerHTML = `
    <div class="card-head"><div style="display:flex;align-items:baseline;gap:12px;flex-wrap:wrap"><h2>${esc(title)}</h2>
      <span class="muted">${plural(d.matching, "sound")} in ${plural(d.songs, "song")}</span></div>
      ${soundState.plugin ? btn(`Save all ${num(d.matching)} as files`, { ic: "download", act: "export-plugin", data: { plugin: soundState.plugin } }) : ""}</div>
    ${d.items.length ? `<div class="grid">${d.items.map(soundCard).join("")}</div>` : `<p class="empty">No sounds match.</p>`}
    ${d.matching > d.items.length ? `<p class="empty">Showing ${num(d.items.length)} of ${num(d.matching)}. Search to narrow it down, or save them all as files.</p>` : ""}
    <p class="muted" style="font-size:13px">To load these in Live: add the folder they're saved in to Live's browser (Places, Add Folder). Each .vstpreset then appears under its plugin; .fxp files load from the plugin's own preset menu.</p>`;
}
function soundCard(e) {
  return `<article class="sound">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
      <span class="chip">${esc(e.plugin)}</span><span class="chip">${esc(e.ext)}</span></div>
    <div class="sound-name">${esc(e.preset || e.track || "Untitled sound")}</div>
    <div class="sound-meta">${esc(e.song)}</div>
    <div class="sound-meta">Track: ${esc(e.track || "–")}${e.uses > 1 ? ` · used ${e.uses} times` : ""}</div>
    <div class="btns">${btn("Save file", { small: true, ic: "download", act: "export-one", data: { hash: e.hash } })}</div></article>`;
}
function drawPlugins() {
  const box = $("#plug-scroll");
  if (!box || !soundData) return;
  const f = soundState.filter.toLowerCase();
  const list = soundData.plugins.filter((p) => !f || p.name.toLowerCase().includes(f));
  $("#plug-count").textContent = plural(soundData.plugins.length, "plugin");
  box.innerHTML = [`<button type="button" class="${soundState.plugin ? "" : "on"}" data-act="pick-plugin" data-plugin="">
      <span>All plugins</span><span class="count">${num(soundData.total)}</span></button>`]
    .concat(list.map((p) => `<button type="button" class="${p.name === soundState.plugin ? "on" : ""}" data-act="pick-plugin" data-plugin="${esc(p.name)}">
      <span>${esc(p.name)}</span><span class="count">${num(p.count)}</span></button>`)).join("");
}
actions["pick-plugin"] = (d) => { soundState.plugin = d.plugin; loadSounds().catch(fail); window.scrollTo(0, 0); };
actions["export-one"] = async (d) => {
  try {
    const r = await api("sounds/export", { hashes: [d.hash] });
    toast("Preset file saved.", { action: { label: "Open folder", run: () => openPath(r.folder) } });
  } catch (e) { fail(e); }
};
actions["export-plugin"] = async (d) => {
  try {
    const r = await api("sounds/export", { plugin: d.plugin });
    toast(`Saved ${plural(r.count, "preset file")}.`, { action: { label: "Open folder", run: () => openPath(r.folder) }, ms: 12000 });
  } catch (e) { fail(e); }
};

// ---------------------------------------------------------------- Storage
const WHAT = [
  ["songs", "Songs", "Every Live Set in your projects folder. Small."],
  ["versions", "Every version", "All the versions Project Vault keeps of each song."],
  ["sounds", "Plugin sounds", "Your plugin sound library, as preset files."],
  ["projects", "Whole projects with samples", "Everything in your projects folder. Can be many GB."],
];
routes.storage = async (main) => {
  const s = await api("storage");
  const free = s.found.filter((f) => !f.linked);
  main.innerHTML = `
    <header class="head"><div class="grow"><h1>Storage</h1>
      <p class="lead">Back up to the cloud storage you already have. Project Vault copies into the folder your OneDrive, Google Drive or Dropbox app keeps in sync, and the app uploads it. Nothing is ever deleted from a backup. New versions are backed up right after each save.</p></div></header>
    ${s.destinations.length ? `<section class="card"><h2>Backing up to</h2>${s.destinations.map(destCard).join("")}</section>` : ""}
    <section class="card"><h2>${s.destinations.length ? "Add another" : "Choose where to back up"}</h2>
      ${free.length ? free.map((f) => `<div class="list-row"><div class="tile">${icon("cloud")}</div>
        <div class="row-text"><div class="row-title">${esc(f.name)}</div><div class="row-sub mono" style="font-size:12px">${esc(f.path)}</div></div>
        ${btn("Back up here", { kind: "primary", ic: "plus", act: "link-store", data: { path: f.path, name: f.name, kind: f.kind } })}</div>`).join("")
        : `<p class="lead">${s.found.length ? "Every cloud folder on this computer is linked." : "No cloud storage apps found on this computer."}</p>`}
      <div class="list-row"><div class="tile">${icon("drive")}</div>
        <div class="row-text"><div class="row-title">Any other folder or drive</div><div class="row-sub">Another cloud app's folder, a NAS or a USB drive.</div></div>
        ${btn("Choose a folder", { ic: "folder", act: "link-other" })}</div>
      ${s.not_installed.length ? `<div class="list-row"><div class="row-text"><div class="row-sub">Don't have one of these yet? Install its app and it shows up here:</div>
        <div class="chips">${s.not_installed.map((n) => `<button type="button" class="chip" style="border:0;cursor:pointer" data-act="open-url" data-url="${esc(n.url)}">${esc(n.name)}</button>`).join("")}</div></div></div>` : ""}
    </section>`;
  current.refresh = () => { drawStorageSide(); route(); };
};
function destCard(d) {
  const last = d.last || {};
  return `<div class="list-row" style="align-items:flex-start;flex-direction:column;gap:14px">
    <div style="display:flex;gap:16px;align-items:center;width:100%;flex-wrap:wrap">
      <div class="tile">${icon(d.kind === "folder" ? "drive" : "cloud")}</div>
      <div class="row-text"><div class="row-title">${esc(d.name)}</div><div class="row-sub mono" style="font-size:12px;overflow-wrap:anywhere">${esc(d.path)}</div>
        <div class="row-sub">${!d.reachable ? "Can't reach this folder. Is the app still installed and signed in?"
          : last.at ? `Last backup ${esc(last.at)}${last.copied != null ? `: ${num(last.copied)} files copied` : ""}${last.error ? ` · ${esc(last.error)}` : ""}` : "Not backed up yet."}</div></div>
      <div class="btns">${btn("Back up now", { kind: "primary", ic: "cloud", act: "job", data: { kind: "backup", args: JSON.stringify(["run", d.id]) }, disabled: !d.reachable })}
        ${d.reachable ? btn("Open folder", { ic: "folder", act: "open", data: { path: d.path } }) : ""}
        ${btn("Stop backing up here", { kind: "ghost", act: "unlink-store", data: { id: d.id, name: d.name } })}</div></div>
    <div class="what-grid" style="width:100%">${WHAT.map(([k, t, sub]) => `<label class="what"><input type="checkbox" data-act="store-what" data-id="${esc(d.id)}" data-k="${k}"${d.what[k] ? " checked" : ""}>
      <span><strong>${esc(t)}</strong><span>${esc(sub)}</span></span></label>`).join("")}</div></div>`;
}
actions["link-store"] = async (d) => {
  try {
    await api("storage/link", { path: d.path, name: d.name, kind: d.kind });
    toast(`Linked ${d.name}. Backing up now…`);
    const s = await api("storage");
    const dest = s.destinations.find((x) => x.path.startsWith(d.path));
    route(); drawStorageSide();
    if (dest) Job.start("backup", ["run", dest.id]);
  } catch (e) { fail(e); }
};
actions["link-other"] = async () => {
  toast("Choose the folder or drive to back up to…", { ms: 4000 });
  const r = await api("pick-folder", { title: "Choose where to back up" }).catch(fail);
  if (!r || !r.folder) return;
  const name = r.folder.split(/[\\/]/).filter(Boolean).pop() || r.folder;
  actions["link-store"]({ path: r.folder, name, kind: "folder" });
};
actions["unlink-store"] = async (d) => {
  if (!await ask(`Stop backing up to ${d.name}?`, "The backup already there is kept. Nothing is deleted.", "Stop backing up")) return;
  await api("storage/unlink", { id: d.id }).catch(fail);
  route(); drawStorageSide();
};
actions["open-url"] = (d) => api("open-url", { url: d.url }).catch(fail);
document.addEventListener("change", async (ev) => {
  const r = ev.target.closest('input[data-act="startup"]');
  if (r) {
    try {
      await api("startup", { mode: r.value });
      toast({ windows: "Project Vault will start with Windows.", live: "Project Vault will start when you open Ableton Live.",
              off: "Project Vault won't start by itself. Open it from the Start menu or the command line." }[r.value]);
    } catch (e) { fail(e); }
    return;
  }
  const el = ev.target.closest('input[data-act="store-what"]');
  if (!el) return;
  if (el.dataset.k === "projects" && el.checked && !await ask("Back up whole projects?",
    "This copies every file in your projects folder, samples included, which can be many GB. Make sure your cloud plan has room.", "Back them up")) {
    el.checked = false; return;
  }
  try { await api("storage/what", { id: el.dataset.id, what: { [el.dataset.k]: el.checked } }); toast("Saved. Click “Back up now” to bring the backup up to date."); }
  catch (e) { fail(e); el.checked = !el.checked; }
});

// ---------------------------------------------------------------- Settings
routes.settings = async (main) => {
  const [s, o] = await Promise.all([api("settings"), refreshSide()]);
  const h = (o && o.history) || {};
  const folder = s.project_folders[0] || "";
  const on = !!(h.running && !h.paused) || (!h.agent && !!h.autostart && !h.paused);
  main.innerHTML = `
    <header class="head"><div class="grow"><h1>Settings</h1></div></header>
    <section class="card">
      <div class="setting"><div class="setting-text"><h3>Your projects folder</h3>
        <p class="lead">Where your Live projects are. Version history watches this folder, and Fix projects reads it.</p>
        <div class="folder" style="margin-top:10px">${icon("folder")}<span>${esc(folder || "Not chosen yet")}</span></div></div>
        ${btn(folder ? "Change" : "Choose", { ic: "folder", act: "pick-projects" })}</div>
      <div class="setting"><div class="setting-text"><h3>Keep a version of every save</h3>
        <p class="lead">${h.paused ? "Paused. Saves aren't being kept until you turn this back on."
          : h.running ? "On. Every save in Live is kept, and backed up if you've linked storage."
          : "Off. Turn it on to keep every version of every song, automatically."}
          ${h.note ? `<br>${esc(h.note)}` : ""}
          ${h.folders && h.folders.length ? `<br>Watching: <span class="mono">${esc(h.folders.join(", "))}</span>` : ""}</p></div>
        <button type="button" class="switch" role="switch" aria-checked="${on}" aria-label="Keep a version of every save" data-act="toggle-history" data-on="${on}" data-folder="${esc(folder)}"></button></div>
      <div class="setting" style="display:block"><div class="setting-text"><h3>Start Project Vault</h3>
        <p class="lead">Project Vault lives in your taskbar's hidden icons (the ^ by the clock). Click it to open this window; right-click for quick actions.</p></div>
        <div class="what-grid" role="radiogroup" aria-label="Start Project Vault" style="margin-top:14px;align-items:start">
          ${[["windows", "When Windows starts", "Always ready, and every save is kept. Recommended."],
             ["live", "When I open Ableton Live", "Waits quietly and shows up when Live opens."],
             ["off", "Only when I open it", "Nothing runs until you open Project Vault yourself."]].map(([m, t, sub]) => `
            <label class="what"><input type="radio" name="startup" data-act="startup" value="${m}"${h.startup === m ? " checked" : ""}>
            <span><strong>${esc(t)}</strong><span>${esc(sub)}</span></span></label>`).join("")}
        </div></div>
      <div class="setting"><div class="setting-text"><h3>Updates</h3><p class="lead" id="upd-text">You have version ${esc(s.version)}.</p></div>
        <div class="btns" id="upd-btns">${btn("Check for updates", { ic: "refresh", act: "check-update" })}</div></div>
      <div class="setting"><div class="setting-text"><h3>Something not working?</h3>
        <p class="lead">Make a support report: a zip you can look through and then send us. No audio or projects, and your Windows user name is taken out.</p></div>
        ${btn("Make a report", { ic: "file", act: "job", data: { kind: "report", args: "[]" } })}</div>
      <div class="setting"><div class="setting-text"><h3>Where Project Vault keeps its data</h3>
        <p class="path">${esc(s.db.replace(/[\\/][^\\/]+$/, ""))}</p></div>
        ${btn("Open folder", { ic: "folder", act: "open", data: { path: s.db.replace(/[\\/][^\\/]+$/, "") } })}</div>
    </section>`;
  current.refresh = null;
};
actions["toggle-history"] = async (d, el) => {
  const turnOn = d.on !== "true";
  if (turnOn && !d.folder) { toast("Choose your projects folder first.", { bad: true }); return; }
  el.disabled = true;
  try {
    await api("history", { on: turnOn, folders: [d.folder] });
    toast(turnOn ? "Version history is on: every save is kept." : "Version history is paused.");
    setTimeout(route, 1500);
  } catch (e) { fail(e); el.disabled = false; }
};
actions["check-update"] = async () => {
  $("#upd-text").textContent = "Checking…";
  try {
    const u = await api("update");
    if (!u.ok) { $("#upd-text").textContent = "Couldn't check: " + u.error; return; }
    if (!u.newer) { $("#upd-text").textContent = `You have the newest version (${u.current}).`; return; }
    $("#upd-text").textContent = `Version ${u.latest} is ready (you have ${u.current}). ${u.notes || ""}`;
    $("#upd-btns").innerHTML = btn(`Install ${u.latest}`, { kind: "primary", ic: "download", act: "install-update" });
  } catch (e) { $("#upd-text").textContent = e.message; }
};
actions["install-update"] = () => {
  Job.start("update", ["--yes"], (j) => {
    if (j.state === "done") ask("Update installed", "Project Vault restarts itself with the new version in a few seconds. Open it again from the icon in your taskbar's hidden icons.", "OK");
  });
};

// ---------------------------------------------------------------- keep the server company
setInterval(() => { if (!document.hidden) api("ping").catch(() => {}); }, 10000);
setInterval(() => { if (!document.hidden) pollNow(); }, 3000);
setInterval(() => { if (!document.hidden) drawStorageSide(); }, 30000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) api("ping").catch(() => {}); });
window.addEventListener("pagehide", () => {
  try { fetch("/api/bye", { method: "POST", keepalive: true, headers: { "X-Vault-Key": KEY, "X-Vault-Page": PAGE, "Content-Type": "application/json" }, body: "{}" }); } catch (e) { /* closing */ }
});

// Pick up a job that was already running (e.g. after a reload).
api("job").then((j) => { if (j.state === "running") { Job.since = 0; $("#job-log").textContent = ""; Job.poll(); } }).catch(() => {});
refreshSide();
route();
