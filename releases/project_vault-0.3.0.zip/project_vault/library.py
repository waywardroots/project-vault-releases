"""Plugin settings library: every plugin sound in your projects, kept as a preset file.

Live keeps each plugin's settings inside the .als. This pulls them out as the standard preset
files plugins load themselves (VST2: .fxp/.fxb, VST3: .vstpreset), so a sound can be reloaded in
another song, kept after the song is gone, or handed to a plugin's newer version.

Kept in <data folder>\\plugin_library\\<plugin>\\<hash>.<ext>, each sound once however many songs
use it, with an index (library.jsonl) of which song and track it came from. Only settings are
kept: samples, wavetables or libraries a sound loads stay where they are.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import re
import struct
import time
from dataclasses import dataclass
from pathlib import Path

_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_NO_NAME = {"default", "default setting", "default settings", "init", "initial", "init preset"}


def library_root(db_path: str | os.PathLike) -> Path:
    return Path(db_path).parent / "plugin_library"


@dataclass
class Sound:
    plugin: str
    fmt: str  # VST2 / VST3
    track: str
    ext: str  # .fxp .fxb .vstpreset
    data: bytes
    preset: str = ""

    @property
    def hash(self) -> str:
        return hashlib.sha1(self.data).hexdigest()[:12]


# ---------------------------------------------------------------- VST3 .vstpreset

def _uid(desc_xml: str) -> str | None:
    """The plugin's class id as a .vstpreset names it: 32 hex digits from Live's four Uid fields."""
    m = re.search(r"<Uid>(.*?)</Uid>", desc_xml, re.S)
    if not m:
        return None
    fields = re.findall(r'<Fields\.(\d) Value="(-?\d+)"', m.group(1))
    if len(fields) != 4:
        return None
    return "".join(f"{int(v) & 0xFFFFFFFF:08X}" for _, v in sorted(fields))


def _hex_block(desc_xml: str, tag: str) -> bytes:
    m = re.search(rf"<{tag}>(.*?)</{tag}>", desc_xml, re.S)
    h = "".join(m.group(1).split()) if m else ""
    try:
        return bytes.fromhex(h)
    except ValueError:
        return b""


def vst3_preset_name(*states: bytes) -> str:
    """The preset name a VST3 plugin saved, where it saves one readably (Serum 2 keeps it in the
    JSON header of its controller state; others write presetName into their own text or XML)."""
    for data in states:
        if data[:9] == b"XferJson\0" and len(data) > 17:
            n = struct.unpack("<Q", data[9:17])[0]
            try:
                name = json.loads(data[17:17 + n]).get("presetName", "")
            except (ValueError, AttributeError):
                name = ""
        else:
            m = re.search(rb'(?:presetName|PresetName|programName)(?:"\s*:\s*|=)"([^"\x00]{1,60})"', data[:65536])
            name = m.group(1).decode("utf-8", "replace") if m else ""
        name = name.strip()
        if name and name.lower() not in _NO_NAME:
            return name
    return ""


def vstpreset(class_id: str, processor: bytes, controller: bytes = b"") -> bytes:
    """Steinberg's preset file: header, the plugin's own state, then the list of chunks."""
    header = 4 + 4 + 32 + 8
    chunks, body, pos = [], b"", header
    for cid, data in ((b"Comp", processor), (b"Cont", controller)):
        if data:
            chunks.append((cid, pos, len(data)))
            body += data
            pos += len(data)
    out = b"VST3" + struct.pack("<i", 1) + class_id.encode("ascii") + struct.pack("<q", pos) + body
    out += b"List" + struct.pack("<i", len(chunks))
    for cid, off, size in chunks:
        out += cid + struct.pack("<qq", off, size)
    return out


def read_vstpreset(data: bytes) -> tuple[str, dict[str, bytes]]:
    """(class id, {chunk id: bytes}) of a .vstpreset; used by the tests and to check files."""
    if data[:4] != b"VST3":
        raise ValueError("not a .vstpreset")
    class_id = data[8:40].decode("ascii")
    list_at = struct.unpack("<q", data[40:48])[0]
    if data[list_at:list_at + 4] != b"List":
        raise ValueError("no chunk list")
    n = struct.unpack("<i", data[list_at + 4:list_at + 8])[0]
    chunks, p = {}, list_at + 8
    for _ in range(n):
        cid = data[p:p + 4].decode("ascii")
        off, size = struct.unpack("<qq", data[p + 4:p + 20])
        chunks[cid] = data[off:off + size]
        p += 20
    return class_id, chunks


# ---------------------------------------------------------------- pulling sounds out of a set

def sounds_in(als: str | os.PathLike) -> list[Sound]:
    """Every plugin in the set that has settings, with the track it's on."""
    from .swap import DESC_RE, DEVICE_RE, _track_names, describe, preset_from_desc, preset_name
    text = gzip.decompress(Path(als).read_bytes()).decode("utf-8", errors="replace")
    tracks = _track_names(text)
    out = []
    for dev in DEVICE_RE.finditer(text):
        desc = DESC_RE.search(dev.group(0))
        info = describe(desc.group(0)) if desc else None
        if not info or not info[0]:
            continue
        name, fmt = info
        track = next((t for pos, t in reversed(tracks) if pos <= dev.start()), "")
        if fmt == "VST2":
            got = preset_from_desc(desc.group(0))
            if got:
                preset = preset_name(desc.group(0), name)
                if preset.lower() in _NO_NAME:
                    preset = ""
                out.append(Sound(name, fmt, track, got[0], got[1], preset))
        else:
            cid, proc = _uid(desc.group(0)), _hex_block(desc.group(0), "ProcessorState")
            if cid and proc:
                cont = _hex_block(desc.group(0), "ControllerState")
                out.append(Sound(name, fmt, track, ".vstpreset", vstpreset(cid, proc, cont),
                                 vst3_preset_name(cont, proc)))
    return out


def file_names(sounds: list[Sound]) -> list[str]:
    """'<track> - <plugin> - <preset>.<ext>', numbered when a track has two of the same."""
    names, used = [], {}
    for s in sounds:
        parts = [p for p in (s.track, s.plugin, s.preset) if p]
        base = _BAD.sub("_", " - ".join(parts)).strip(" .")[:120] or "sound"
        n = used.get(base.lower(), 0) + 1
        used[base.lower()] = n
        names.append(f"{base}{f' {n}' if n > 1 else ''}{s.ext}")
    return names


def export(als: str | os.PathLike, to: str | os.PathLike, track: str = "", plugin: str = "") -> list[Path]:
    """Write the set's plugin sounds as preset files into a folder. Never overwrites a file."""
    sounds = [s for s in sounds_in(als)
              if (not track or track.lower() in s.track.lower())
              and (not plugin or plugin.lower() in s.plugin.lower())]
    to = Path(to)
    to.mkdir(parents=True, exist_ok=True)
    written = []
    for s, name in zip(sounds, file_names(sounds)):
        p, n = to / name, 2
        while p.exists() and p.read_bytes() != s.data:
            p = to / f"{Path(name).stem} ({n}){s.ext}"
            n += 1
        if not p.exists():
            p.write_bytes(s.data)
        written.append(p)
    return written


# ---------------------------------------------------------------- the library

def _index(lib: Path) -> Path:
    return lib / "library.jsonl"


def entries(lib: Path) -> list[dict]:
    out = []
    try:
        with _index(lib).open(encoding="utf-8") as f:
            for line in f:
                try:
                    out.append(json.loads(line))
                except ValueError:
                    continue  # a line cut short by a crash is skipped, never fatal
    except OSError:
        pass
    return out


def collect(lib: Path, als: str | os.PathLike, song_id: str = "", song: str = "",
            when: float | None = None, known: set | None = None) -> int:
    """Add the set's sounds to the library. Returns how many weren't in it for this song yet."""
    try:
        sounds = sounds_in(als)
    except (OSError, EOFError, ValueError, gzip.BadGzipFile):
        return 0
    if known is None:
        known = {(e["hash"], e.get("song_id"), e.get("track")) for e in entries(lib)}
    song = song or Path(als).stem
    stamp = time.strftime("%Y-%m-%d %H:%M", time.localtime(when if when is not None else time.time()))
    new = []
    for s in sounds:
        key = (s.hash, song_id, s.track)
        if key in known:
            continue
        known.add(key)
        folder = lib / (_BAD.sub("_", s.plugin).strip(" .") or "plugin")
        f = folder / f"{s.hash}{s.ext}"
        if not f.exists():
            folder.mkdir(parents=True, exist_ok=True)
            tmp = f.with_suffix(".tmp")
            tmp.write_bytes(s.data)
            os.replace(tmp, f)
        new.append({"hash": s.hash, "plugin": s.plugin, "fmt": s.fmt, "ext": s.ext, "preset": s.preset,
                    "song_id": song_id, "song": song, "track": s.track, "first_seen": stamp,
                    "file": str(f.relative_to(lib))})
    if new:
        lib.mkdir(parents=True, exist_ok=True)
        with _index(lib).open("a", encoding="utf-8") as fh:
            for e in new:
                fh.write(json.dumps(e, ensure_ascii=False) + "\n")
    return len(new)


def search(lib: Path, plugin: str = "", song: str = "", text: str = "") -> list[dict]:
    t = text.lower()
    return [e for e in entries(lib)
            if (not plugin or plugin.lower() in e["plugin"].lower())
            and (not song or song.lower() in e["song"].lower())
            and (not t or t in f"{e['plugin']} {e['song']} {e['track']} {e['preset']}".lower())]


def export_entries(lib: Path, found: list[dict], to: str | os.PathLike) -> list[Path]:
    """Copy library sounds out as preset files named for the song and track they came from."""
    to = Path(to)
    to.mkdir(parents=True, exist_ok=True)
    out = []
    for e in found:
        src = lib / e["file"]
        if not src.exists():
            continue
        data = src.read_bytes()
        parts = [p for p in (e["song"], e["track"], e["plugin"], e["preset"]) if p]
        base = _BAD.sub("_", " - ".join(parts)).strip(" .")[:150]
        p, n = to / f"{base}{e['ext']}", 2
        while p.exists() and p.read_bytes() != data:
            p = to / f"{base} ({n}){e['ext']}"
            n += 1
        if not p.exists():
            p.write_bytes(data)
        out.append(p)
    return out
