"""A small file per song, kept with the project, so Project Vault knows the song wherever it goes.

In a Live Project (a folder with "Ableton Project Info") it lives in
  Ableton Project Info\\Project Vault\\<song>.json
and for a loose set, in a "Project Vault" folder next to it. It holds the song's permanent id (so
its history follows it when the project folder is moved or renamed), version labels and notes.
It's tiny; the versions themselves stay in the central history store.

Renamed songs: the sidecar remembers the content of the last version kept. A song that appears
with exactly that content where the old file has gone is the same song, renamed, and keeps its
history. If the old file is still there, the new one is a copy ("Save As") and starts its own
history, noting which song it came from.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from pathlib import Path

from .database import norm

INFO = "Ableton Project Info"
FOLDER = "Project Vault"
_BAD = re.compile(r'[<>:"/\\|?*]')


def project_root(als: Path) -> Path | None:
    """The Live Project folder (the one with 'Ableton Project Info'), if the set is in one."""
    for folder in [als.parent, *list(als.parent.parents)[:3]]:
        if (folder / INFO).is_dir():
            return folder
    return None


def sidecar_path(als: str | os.PathLike) -> Path:
    als = Path(als)
    root = project_root(als)
    if root is None:  # never make a folder look like a Live Project when it isn't one
        return als.parent / FOLDER / f"{_BAD.sub('_', als.stem)}.json"
    rel = als.relative_to(root).with_suffix("")
    return root / INFO / FOLDER / f"{_BAD.sub('_', '__'.join(rel.parts))}.json"


def path_id(als: str | os.PathLike) -> str:
    """The id a song gets the first time it's seen (the same key older history folders use)."""
    return hashlib.sha1(norm(str(als)).encode("utf-8")).hexdigest()[:16]


def read(als: str | os.PathLike) -> dict | None:
    try:
        data = json.loads(sidecar_path(als).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) and data.get("id") else None
    except (OSError, ValueError):
        return None


def song_id(als: str | os.PathLike) -> str:
    data = read(als)
    return data["id"] if data else path_id(als)


def write(als: str | os.PathLike, data: dict) -> bool:
    """False if the project folder can't be written (read-only drive): everything still works."""
    p = sidecar_path(als)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, p)
        return True
    except OSError:
        return False


def _others(als: Path):
    folder = sidecar_path(als).parent
    if not folder.is_dir():
        return
    for f in sorted(folder.glob("*.json")):
        if f == sidecar_path(als):
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(data, dict) and data.get("id") and data.get("file"):
            yield f, data


def ensure(als: str | os.PathLike, content_hash: str | None = None) -> dict:
    """The song's sidecar: created, or carried over from a rename, if it doesn't have one."""
    als = Path(als)
    data = read(als)
    if data is None:
        data = {}
        for f, other in _others(als) if content_hash else ():
            if other.get("last_hash") != content_hash:
                continue
            old = Path(other["file"])
            if old.name.lower() != als.name.lower() and not old.exists():  # renamed: same song
                data = dict(other, renamed_from=other.get("renamed_from", []) + [old.stem])
                try:
                    f.unlink()
                except OSError:
                    pass
                break
            if old.exists():  # Save As: a new song that started as a copy
                data = {"branched_from": {"id": other["id"], "song": old.stem}}
        data.setdefault("id", path_id(als))
        data.setdefault("created", time.strftime("%Y-%m-%d %H:%M"))
        data.setdefault("labels", {})
        data.setdefault("notes", "")
    if data.get("file") != str(als):  # new, renamed, or the whole project was moved
        data.update(file=str(als), song=als.stem)
        write(als, data)
    return data


def remember_version(als: str | os.PathLike, content_hash: str) -> dict:
    data = ensure(als, content_hash)
    if data.get("last_hash") != content_hash:
        data["last_hash"] = content_hash
        write(als, data)
    return data


def set_label(als: str | os.PathLike, stamp: str, text: str) -> bool:
    data = ensure(als)
    if text:
        data["labels"][stamp] = text
    else:
        data["labels"].pop(stamp, None)
    return write(als, data)


def set_notes(als: str | os.PathLike, text: str) -> bool:
    data = ensure(als)
    data["notes"] = text
    return write(als, data)
