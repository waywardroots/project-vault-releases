"""Local SQLite index of Ableton projects. One file, no server."""
from __future__ import annotations

import os
import sqlite3
import time
from pathlib import Path

from .als_reader import LiveSet

SCHEMA_VERSION = 4

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    live_version TEXT,
    tempo REAL,
    mtime REAL,
    scanned_at REAL
);
CREATE TABLE IF NOT EXISTS tracks (
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    track_id TEXT, kind TEXT, name TEXT, devices TEXT
);
CREATE TABLE IF NOT EXISTS samples (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,     -- as written in the project
    norm_path TEXT NOT NULL,       -- lowercase, forward slashes, for matching
    file_name TEXT NOT NULL,
    size INTEGER,                  -- bytes, if the project recorded it
    crc INTEGER                    -- Live's fingerprint of the first 16 KB, if recorded
);
CREATE TABLE IF NOT EXISTS sample_uses (
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    sample_id INTEGER REFERENCES samples(id),
    track_name TEXT, location TEXT, rel_path TEXT, count INTEGER
);
CREATE TABLE IF NOT EXISTS plugin_uses (
    project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT, format TEXT, track_name TEXT, file TEXT
);
CREATE INDEX IF NOT EXISTS idx_samples_norm ON samples(norm_path);
CREATE INDEX IF NOT EXISTS idx_uses_sample ON sample_uses(sample_id);
CREATE INDEX IF NOT EXISTS idx_plugins_name ON plugin_uses(name);
"""


def norm(path: str) -> str:
    return path.replace("\\", "/").strip().lower()


class VaultDB:
    def __init__(self, db_path: str | os.PathLike):
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.upgraded = False
        version = self.conn.execute("PRAGMA user_version").fetchone()[0]
        has_tables = self.conn.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='projects'").fetchone()[0]
        if has_tables and version < SCHEMA_VERSION:
            # The index is rebuilt from the projects themselves, so it is safe to start over.
            for t in ("sample_uses", "plugin_uses", "tracks", "samples", "projects"):
                self.conn.execute(f"DROP TABLE IF EXISTS {t}")
            self.upgraded = True
        self.conn.executescript(SCHEMA)
        self.conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")

    def close(self) -> None:
        self.conn.close()

    def needs_scan(self, als_path: str, mtime: float) -> bool:
        row = self.conn.execute("SELECT mtime FROM projects WHERE path = ?", (als_path,)).fetchone()
        return row is None or row["mtime"] != mtime

    def _sample_id(self, path: str, file_name: str, size: int | None, crc: int | None = None) -> int:
        row = self.conn.execute("SELECT id, size, crc FROM samples WHERE path = ?", (path,)).fetchone()
        if row:
            if size and not row["size"]:
                self.conn.execute("UPDATE samples SET size = ?, crc = ? WHERE id = ?", (size, crc, row["id"]))
            return row["id"]
        cur = self.conn.execute(
            "INSERT INTO samples (path, norm_path, file_name, size, crc) VALUES (?, ?, ?, ?, ?)",
            (path, norm(path), file_name, size, crc),
        )
        return cur.lastrowid

    def save_project(self, live: LiveSet, mtime: float) -> None:
        c = self.conn
        c.execute("DELETE FROM projects WHERE path = ?", (live.path,))  # cascades to child rows
        cur = c.execute(
            "INSERT INTO projects (path, name, live_version, tempo, mtime, scanned_at) VALUES (?,?,?,?,?,?)",
            (live.path, Path(live.path).stem, live.live_version, live.tempo, mtime, time.time()),
        )
        pid = cur.lastrowid
        c.executemany(
            "INSERT INTO tracks VALUES (?,?,?,?,?)",
            [(pid, t.track_id, t.kind, t.name, ", ".join(t.devices)) for t in live.tracks],
        )
        c.executemany(
            "INSERT INTO sample_uses VALUES (?,?,?,?,?,?)",
            [(pid, self._sample_id(s.path, s.file_name, s.size, s.crc), s.track_name, s.location, s.rel_path, s.count)
             for s in live.samples],
        )
        c.executemany(
            "INSERT INTO plugin_uses VALUES (?,?,?,?,?)",
            [(pid, p.name, p.fmt, p.track_name, p.file) for p in live.plugins],
        )
        c.commit()

    def remove_missing_projects(self, seen: set[str], root: str) -> int:
        """Drop projects under `root` that no longer exist on disk."""
        rows = self.conn.execute("SELECT path FROM projects").fetchall()
        gone = [r["path"] for r in rows if norm(r["path"]).startswith(norm(root)) and r["path"] not in seen]
        for p in gone:
            self.conn.execute("DELETE FROM projects WHERE path = ?", (p,))
        self.conn.commit()
        return len(gone)

    # ---- queries -------------------------------------------------------
    def where_used(self, text: str):
        return self.conn.execute(
            """SELECT s.path, s.file_name, p.name AS project, p.path AS project_path,
                      u.track_name, u.location, u.count
               FROM samples s JOIN sample_uses u ON u.sample_id = s.id
               JOIN projects p ON p.id = u.project_id
               WHERE s.norm_path LIKE ? ORDER BY s.file_name, p.name""",
            (f"%{norm(text)}%",),
        ).fetchall()

    def all_samples(self):
        return self.conn.execute(
            """SELECT s.path, s.norm_path, s.file_name,
                      GROUP_CONCAT(DISTINCT p.name) AS projects
               FROM samples s JOIN sample_uses u ON u.sample_id = s.id
               JOIN projects p ON p.id = u.project_id
               GROUP BY s.id ORDER BY s.file_name"""
        ).fetchall()

    def sample_uses_for_check(self):
        """Every (project, sample) pair with the info needed to check it exists on disk."""
        return self.conn.execute(
            """SELECT DISTINCT p.name AS project, p.path AS project_path, s.path, s.file_name,
                      s.size, s.crc, u.rel_path, u.track_name
               FROM sample_uses u JOIN samples s ON s.id = u.sample_id
               JOIN projects p ON p.id = u.project_id ORDER BY p.name, s.file_name"""
        ).fetchall()

    def used_norm_paths(self) -> set[str]:
        return {r[0] for r in self.conn.execute(
            "SELECT DISTINCT s.norm_path FROM samples s JOIN sample_uses u ON u.sample_id = s.id")}

    def plugin_counts(self):
        return self.conn.execute(
            """SELECT name, format, COUNT(DISTINCT project_id) AS projects
               FROM plugin_uses GROUP BY name, format ORDER BY projects DESC, name"""
        ).fetchall()

    def plugin_usage(self):
        """One row per (plugin, format) with the projects using it and the .dll paths seen."""
        return self.conn.execute(
            """SELECT u.name, u.format, COUNT(DISTINCT u.project_id) AS projects,
                      GROUP_CONCAT(DISTINCT p.name) AS project_names,
                      GROUP_CONCAT(DISTINCT u.file) AS files
               FROM plugin_uses u JOIN projects p ON p.id = u.project_id
               GROUP BY u.name, u.format ORDER BY projects DESC, u.name"""
        ).fetchall()

    def plugins_by_project(self):
        return self.conn.execute(
            "SELECT DISTINCT project_id, name, format FROM plugin_uses").fetchall()

    def projects_using(self, name: str, fmt: str):
        return self.conn.execute(
            """SELECT DISTINCT p.path, p.live_version FROM plugin_uses u JOIN projects p ON p.id = u.project_id
               WHERE u.name = ? AND u.format = ?""", (name, fmt)).fetchall()

    def projects_with_plugin(self, text: str):
        return self.conn.execute(
            """SELECT DISTINCT p.name, p.path, u.track_name, u.name AS plugin
               FROM plugin_uses u JOIN projects p ON p.id = u.project_id
               WHERE LOWER(u.name) LIKE ? ORDER BY p.name""",
            (f"%{text.lower()}%",),
        ).fetchall()

    def find_projects(self, text: str):
        return self.conn.execute(
            "SELECT * FROM projects WHERE LOWER(name) LIKE ? ORDER BY name", (f"%{text.lower()}%",)
        ).fetchall()

    def project_detail(self, pid: int):
        tracks = self.conn.execute("SELECT * FROM tracks WHERE project_id = ?", (pid,)).fetchall()
        samples = self.conn.execute(
            """SELECT s.path, s.file_name, u.track_name, u.location FROM sample_uses u
               JOIN samples s ON s.id = u.sample_id WHERE u.project_id = ? ORDER BY u.track_name""",
            (pid,),
        ).fetchall()
        plugins = self.conn.execute(
            "SELECT DISTINCT name, format, track_name FROM plugin_uses WHERE project_id = ?", (pid,)
        ).fetchall()
        return tracks, samples, plugins

    def stats(self) -> dict:
        q = lambda sql: self.conn.execute(sql).fetchone()[0]
        return {
            "projects": q("SELECT COUNT(*) FROM projects"),
            "tracks": q("SELECT COUNT(*) FROM tracks"),
            "unique samples": q("SELECT COUNT(DISTINCT sample_id) FROM sample_uses"),
            "sample uses": q("SELECT COUNT(*) FROM sample_uses"),
            "unique plugins": q("SELECT COUNT(DISTINCT name) FROM plugin_uses"),
        }
