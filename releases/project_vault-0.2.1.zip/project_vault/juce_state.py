"""Reading and writing JUCE plugin state (the ValueTree binary format many VST3s save).

Such plugins store each knob by name in real units ('Frequency_ID' = 180.0 Hz), which makes
their settings readable and writable without the plugin."""
from __future__ import annotations

import struct


def _cint(d: bytes, i: int) -> tuple[int, int]:
    n = d[i]
    return int.from_bytes(d[i + 1:i + 1 + n], "little"), i + 1 + n


def _wcint(v: int) -> bytes:
    if v == 0:
        return b"\0"  # JUCE writes zero as a lone length byte
    b = v.to_bytes((v.bit_length() + 7) // 8, "little")
    return bytes([len(b)]) + b


def _cstr(d: bytes, i: int) -> tuple[str, int]:
    j = d.index(b"\0", i)
    return d[i:j].decode("utf-8", "replace"), j + 1


class Node:
    def __init__(self, name: str, props: list, kids: list):
        self.name, self.props, self.kids = name, props, kids  # props: [(key, type, raw body)]

    def get(self, key):
        for k, t, body in self.props:
            if k == key:
                return _decode(t, body)
        return None

    def set_double(self, key: str, value: float) -> None:
        for n, (k, t, body) in enumerate(self.props):
            if k == key:
                self.props[n] = (k, 4, struct.pack("<d", float(value)))
                return
        self.props.append((key, 4, struct.pack("<d", float(value))))


def _decode(t: int, body: bytes):
    if t == 4:
        return struct.unpack("<d", body)[0]
    if t == 1:
        return struct.unpack("<i", body)[0]
    if t == 5:
        return body.rstrip(b"\0").decode("utf-8", "replace")
    if t in (2, 3):
        return t == 2
    return body


def _read(d: bytes, i: int) -> tuple[Node, int]:
    name, i = _cstr(d, i)
    n, i = _cint(d, i)
    props = []
    for _ in range(n):
        key, i = _cstr(d, i)
        size, i = _cint(d, i)
        props.append((key, d[i], d[i + 1:i + size]))
        i += size
    count, i = _cint(d, i)
    kids = []
    for _ in range(count):
        kid, i = _read(d, i)
        kids.append(kid)
    return Node(name, props, kids), i


def _write(node: Node) -> bytes:
    out = node.name.encode() + b"\0" + _wcint(len(node.props))
    for k, t, body in node.props:
        out += k.encode() + b"\0" + _wcint(1 + len(body)) + bytes([t]) + body
    out += _wcint(len(node.kids))
    for kid in node.kids:
        out += _write(kid)
    return out


def parse(state: bytes) -> tuple[Node, bytes] | None:
    """(tree, bytes after the tree) or None if this isn't a JUCE ValueTree."""
    try:
        tree, end = _read(state, 0)
    except (ValueError, IndexError, UnicodeDecodeError):
        return None
    if not tree.name or not tree.kids:
        return None
    return tree, state[end:]


def build(tree: Node, tail: bytes) -> bytes:
    return _write(tree) + tail


def params(tree: Node) -> dict[str, float]:
    """{'Frequency_ID': 180.0, ...} for the PARAM children (JUCE AudioProcessorValueTreeState)."""
    return {k.get("id"): k.get("value") for k in tree.kids if k.name == "PARAM" and k.get("id")}


def set_params(tree: Node, values: dict[str, float]) -> None:
    for k in tree.kids:
        if k.name == "PARAM" and k.get("id") in values:
            k.set_double("value", values[k.get("id")])
