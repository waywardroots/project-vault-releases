"""Where Project Vault keeps the copies it makes, and how they stay working there.

    project files\\
      Song.als                            your original, never changed
      Relinked\\Song (relinked).als
      Swapped\\Song (swapped).als
      Swapped\\Plugin settings\\Song\\...    old plugin settings saved by swaps

Because a copy lives one folder below the original, every sample it uses is pinned to its
full location on disk ("anchored"), so references that were relative to the original's folder
keep working.
"""
from __future__ import annotations

import html
import os
import posixpath
import re
import xml.etree.ElementTree as ET
from pathlib import Path

from .als_reader import relative_path, resolve_file_ref

RELINKED_DIR = "Relinked"
SWAPPED_DIR = "Swapped"
SETTINGS_DIR = "Plugin settings"
SUFFIXES = (" (swapped)", " (relinked)")
COPY_DIRS = (RELINKED_DIR, SWAPPED_DIR)

FILEREF_RE = re.compile(r"<FileRef>.*?</FileRef>", re.S)


def base_stem(stem: str) -> str:
    """'Song (relinked) (swapped)' -> 'Song'."""
    changed = True
    while changed:
        changed = False
        for s in SUFFIXES:
            if stem.endswith(s):
                stem, changed = stem[: -len(s)], True
    return stem


def home_dir(als: Path) -> Path:
    """The folder of the original project, for a copy kept in Relinked\\ or Swapped\\."""
    return als.parent.parent if als.parent.name in COPY_DIRS else als.parent


def relinked_path(als: Path) -> Path:
    return home_dir(als) / RELINKED_DIR / f"{base_stem(als.stem)} (relinked).als"


def swapped_path(als: Path) -> Path:
    return home_dir(als) / SWAPPED_DIR / f"{base_stem(als.stem)} (swapped).als"


def settings_dir(als: Path) -> Path:
    return home_dir(als) / SWAPPED_DIR / SETTINGS_DIR / base_stem(als.stem)


def _project_roots(folder: Path) -> list[Path]:
    """The set's folder, plus any parent that is an Ableton project folder."""
    roots, p = [folder], folder
    for _ in range(4):
        if (p / "Ableton Project Info").is_dir() and p not in roots:
            roots.append(p)
        if p.parent == p:
            break
        p = p.parent
    return roots


def _norm(p: str) -> str:
    return posixpath.normpath(p.replace("\\", "/"))


def anchor_refs(text: str, src_dir: Path) -> tuple[str, int]:
    """Pin every sample that exists on disk to its full path, so the set works from any folder.
    Returns (new text, number of references pinned). Samples that can't be found are left as is."""
    from .fix import _rewrite_block, uses_list_ids  # same rewrite relink uses, for every Live version

    pinned = 0
    list_ids = uses_list_ids(text)

    def repl(m: re.Match) -> str:
        nonlocal pinned
        block = m.group(0)
        try:
            el = ET.fromstring(block)
        except ET.ParseError:
            return block
        absolute, _ = resolve_file_ref(el, src_dir)
        rel = relative_path(el)
        candidates = []
        if rel:
            candidates += [_norm(str(root / rel)) for root in _project_roots(src_dir)]
        if absolute:
            candidates.append(_norm(absolute))
        found = next((c for c in candidates if os.path.isfile(c)), None)
        if not found:
            return block
        new = _rewrite_block(block, found, list_ids)
        if new is None:
            return block
        # Live 11/12: also drop the relative path, which would now point the wrong way.
        new = re.sub(r'(<RelativePathType Value=")[^"]*(")', r"\g<1>0\2", new, count=1)
        new = re.sub(r'(<RelativePath Value=")[^"]*(")', r"\1\2", new, count=1)
        if new != block:
            pinned += 1
        return new

    return FILEREF_RE.sub(repl, text), pinned


def check_xml(text: str) -> None:
    """Valid XML, and in Live 9+ sets every sample-path list member has an Id (Live refuses
    to open the set otherwise: "Not all list members have Ids")."""
    ET.fromstring(text.encode("utf-8"))
    from .fix import uses_list_ids
    if uses_list_ids(text) and re.search(r"<RelativePathElement (?!Id=)", text):
        raise ValueError("a list member is missing its Id")


def escape(s: str) -> str:
    return html.escape(s, quote=True)


OLD_SETTINGS_DIR = "Swapped plugin settings"  # where earlier versions saved plugin settings


def tidy(root: Path, dry_run: bool = False, log=print) -> dict:
    """Move copies made by earlier versions (next to the originals) into Relinked\\ and
    Swapped\\, pinning their samples so they keep working. Originals are never touched."""
    import gzip
    import shutil
    from .als_reader import read_als

    stats = {"moved": 0, "skipped": 0, "settings": 0}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if d.lower() not in ("backup", "__macosx") and d not in COPY_DIRS
                       and d != OLD_SETTINGS_DIR]
        here = Path(dirpath)
        for f in sorted(filenames):
            if not f.lower().endswith(".als") or f.startswith("._"):
                continue
            src = here / f
            if src.stem.endswith(" (swapped)"):
                target = swapped_path(src)
            elif src.stem.endswith(" (relinked)"):
                target = relinked_path(src)
            else:
                continue  # an original: never moved
            if target.exists():
                log(f"  skipped {f}: {target.parent.name}\\{target.name} already exists")
                stats["skipped"] += 1
                continue
            if dry_run:
                log(f"  would move {f} -> {target.parent.name}\\")
                stats["moved"] += 1
                continue
            text = gzip.open(src, "rb").read().decode("utf-8")
            new_text, _ = anchor_refs(text, here)
            check_xml(new_text)
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_name(target.name + ".tmp")
            tmp.write_bytes(gzip.compress(new_text.encode("utf-8")))
            before, after = read_als(src), read_als(tmp)
            if (len(before.tracks), len(before.samples), len(before.plugins)) != \
                    (len(after.tracks), len(after.samples), len(after.plugins)):
                tmp.unlink(missing_ok=True)
                log(f"  skipped {f}: check failed, left where it is")
                stats["skipped"] += 1
                continue
            from .safe_io import move_into_place
            err = move_into_place(tmp, target)
            if err:
                log(f"  skipped {f}: {err}")
                stats["skipped"] += 1
                continue
            try:
                src.unlink()
            except PermissionError:
                log(f"  moved {f}, but the old copy is open elsewhere; delete it later")
            stats["moved"] += 1
        old = here / OLD_SETTINGS_DIR
        if old.is_dir():
            dest_root = here / SWAPPED_DIR / SETTINGS_DIR
            for child in sorted(old.iterdir()):
                dest = dest_root / child.name
                if dry_run:
                    stats["settings"] += 1
                    continue
                dest.mkdir(parents=True, exist_ok=True)
                for item in child.iterdir() if child.is_dir() else [child]:
                    if not (dest / item.name).exists():
                        shutil.move(str(item), str(dest / item.name))
                if child.is_dir() and not any(child.iterdir()):
                    child.rmdir()
                stats["settings"] += 1
            if not dry_run and not any(old.iterdir()):
                old.rmdir()
    return stats


def _number_lists(text: str) -> tuple[str, int]:
    """Give every RelativePathElement in each PathHint/RelativePath list an Id (0, 1, 2...)."""
    fixed = 0

    def per_list(m: re.Match) -> str:
        nonlocal fixed
        body = m.group(2)
        if not re.search(r"<RelativePathElement (?!Id=)", body):
            return m.group(0)
        counter = iter(range(10_000))
        body = re.sub(r'<RelativePathElement(?: Id="\d+")?', lambda _: f'<RelativePathElement Id="{next(counter)}"', body)
        fixed += 1
        return m.group(1) + body + m.group(3)

    text = re.sub(r"(<PathHint>)(.*?)(</PathHint>)", per_list, text, flags=re.S)
    text = re.sub(r"(<RelativePath>)(.*?)(</RelativePath>)", per_list, text, flags=re.S)
    return text, fixed


def repair(root: Path, dry_run: bool = False, log=print) -> dict:
    """Fix copies in Relinked\\ and Swapped\\ that Live calls corrupt ("Not all list members
    have Ids"): sample hints written without Ids in Live 9+ sets. Only copies are touched."""
    import gzip
    from .als_reader import read_als
    from .fix import uses_list_ids

    stats = {"checked": 0, "repaired": 0, "failed": 0}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d.lower() not in ("backup", "__macosx")]
        here = Path(dirpath)
        if here.name not in COPY_DIRS:
            continue
        for f in sorted(filenames):
            if not f.lower().endswith(".als") or f.startswith("._"):
                continue
            path = here / f
            stats["checked"] += 1
            text = gzip.open(path, "rb").read().decode("utf-8")
            if not (uses_list_ids(text) and re.search(r"<RelativePathElement (?!Id=)", text)):
                continue
            new_text, _ = _number_lists(text)
            try:
                check_xml(new_text)
            except Exception as e:  # noqa: BLE001
                log(f"  could not repair {f}: {e}")
                stats["failed"] += 1
                continue
            if dry_run:
                stats["repaired"] += 1
                continue
            tmp = path.with_name(path.name + ".tmp")
            tmp.write_bytes(gzip.compress(new_text.encode("utf-8")))
            before, after = read_als(path), read_als(tmp)
            if (len(before.tracks), len(before.samples), len(before.plugins)) != \
                    (len(after.tracks), len(after.samples), len(after.plugins)):
                tmp.unlink(missing_ok=True)
                log(f"  could not repair {f}: check failed")
                stats["failed"] += 1
                continue
            from .safe_io import move_into_place
            err = move_into_place(tmp, path)
            if err:
                log(f"  could not repair {f}: {err}")
                stats["failed"] += 1
                continue
            stats["repaired"] += 1
    return stats
