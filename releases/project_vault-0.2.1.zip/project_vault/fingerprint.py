"""Live's sample fingerprint, and rebuilding files Live cut from a longer sample.

Every sample reference in a Live Set records the file's size and a 16-bit CRC of its
first 16 KB (SearchHint/Crc in Live 8-10, OriginalCrc in Live 11/12). The CRC is
CRC-16 with polynomial 0x8005, starting at 0, no bit reflection. With size and CRC,
a found file can be confirmed to be the very file the project used.

When Live crops a clip it writes a new file (Samples/Processed/Crop/<name>-N.wav)
holding an exact, unchanged stretch of the original's audio behind a plain 44-byte
WAV header. If that file is lost but the original survives, the stretch can be found:
slide a window over the original and look for the spot whose header + audio gives the
recorded CRC. A 16-bit CRC alone leaves about one false hit per 65,536 positions, so
each hit is then checked against the transients Live saved for the clip (its onsets);
only a clear winner is trusted.
"""
from __future__ import annotations

import gzip
import math
import os
import re
import struct
from dataclasses import dataclass, field

CRC_BYTES = 16384
POLY = 0x8005


def _table() -> list[int]:
    t = []
    for i in range(256):
        c = i << 8
        for _ in range(8):
            c = ((c << 1) ^ POLY) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
        t.append(c)
    return t


TAB = _table()


def crc16(data: bytes, crc: int = 0) -> int:
    t = TAB
    for b in data:
        crc = ((crc << 8) & 0xFFFF) ^ t[((crc >> 8) ^ b) & 0xFF]
    return crc


def _zeros(crc: int, n: int) -> int:
    """crc after feeding n zero bytes."""
    t = TAB
    for _ in range(n):
        crc = ((crc << 8) & 0xFFFF) ^ t[(crc >> 8) & 0xFF]
    return crc


def live_crc(path: str) -> int | None:
    """The CRC Live stores for a file, or None if it can't be read."""
    try:
        with open(path, "rb") as f:
            return crc16(f.read(CRC_BYTES))
    except OSError:
        return None


def same_file(path: str, size: int | None, crc: int | None) -> bool | None:
    """True/False if the file is/isn't the one Live recorded; None if Live recorded nothing."""
    if not size:
        return None
    try:
        if os.path.getsize(path) != size:
            return False
    except OSError:
        return False
    if crc is None:
        return None
    return live_crc(path) == crc


# ---- WAV ---------------------------------------------------------------------

@dataclass
class Wav:
    channels: int
    rate: int
    bits: int
    data_offset: int
    data_size: int

    @property
    def block(self) -> int:
        return self.channels * self.bits // 8

    @property
    def frames(self) -> int:
        return self.data_size // self.block


def read_wav_header(path: str) -> Wav | None:
    """PCM 16/24-bit WAV only (what Live writes for crops of such files)."""
    try:
        with open(path, "rb") as f:
            head = f.read(1 << 16)
            total = os.path.getsize(path)
    except OSError:
        return None
    if head[:4] != b"RIFF" or head[8:12] != b"WAVE":
        return None
    i, fmt = 12, None
    while i + 8 <= len(head):
        cid, size = head[i:i + 4], struct.unpack("<I", head[i + 4:i + 8])[0]
        if cid == b"fmt ":
            tag, ch, rate, _, _, bits = struct.unpack("<HHIIHH", head[i + 8:i + 24])
            fmt = (tag, ch, rate, bits)
        elif cid == b"data":
            if not fmt or fmt[0] != 1 or fmt[3] not in (16, 24):
                return None
            return Wav(fmt[1], fmt[2], fmt[3], i + 8, min(size, total - i - 8))
        i += 8 + size + (size & 1)
    return None


def wav_header(frames: int, channels: int, rate: int, bits: int) -> bytes:
    block = channels * bits // 8
    return (b"RIFF" + struct.pack("<I", 36 + frames * block) + b"WAVEfmt "
            + struct.pack("<IHHIIHH", 16, 1, channels, rate, rate * block, block, bits)
            + b"data" + struct.pack("<I", frames * block))


# ---- finding a cropped stretch inside its original ------------------------------

@dataclass
class Target:
    """A lost file: what Live recorded about it."""
    key: str
    size: int
    crc: int
    onsets: list[float] = field(default_factory=list)  # seconds into the lost file


@dataclass
class Found:
    start: int = 0   # first frame in the original
    frames: int = 0
    sure: bool = False
    why: str = ""
    candidates: int = 0
    rate: int = 44100


def find_positions(audio: bytes, block: int, targets: dict[int, list[tuple[int, int]]],
                   window: int, progress=None) -> dict[int, list[int]]:
    """One pass over the audio. targets: needed window-CRC -> [(target id, max start frame)].
    Returns target id -> start frames whose header+window CRC matches."""
    hits: dict[int, list[int]] = {}
    n = len(audio)
    if n < window:
        return hits
    t = TAB
    rem = [_zeros(crc16(bytes([b])), window - 1) for b in range(256)]
    crc = crc16(audio[:window])
    get = targets.get
    step = max(1, (n - window) // 20)
    for k in range(0, n - window):
        if k % block == 0:
            want = get(crc)
            if want:
                f = k // block
                for tid, last in want:
                    if f <= last:
                        hits.setdefault(tid, []).append(f)
        if progress and k % step == 0:
            progress(k / (n - window))
        crc ^= rem[audio[k]]
        crc = ((crc << 8) & 0xFFFF) ^ t[((crc >> 8) ^ audio[k + window]) & 0xFF]
    if (n - window) % block == 0:
        want = get(crc)
        if want:
            f = (n - window) // block
            for tid, last in want:
                if f <= last:
                    hits.setdefault(tid, []).append(f)
    return hits


class _Reader:
    """Mono (summed) samples from raw PCM, scaled to 16-bit range."""

    def __init__(self, audio: bytes, wav: Wav):
        self.audio, self.wav = audio, wav
        self.arr = None
        if wav.bits == 16:
            import array
            import sys
            self.arr = array.array("h")
            self.arr.frombytes(audio[: len(audio) // 2 * 2])
            if sys.byteorder == "big":
                self.arr.byteswap()

    def mono(self, a: int, b: int) -> list[int]:
        wav = self.wav
        a, b = max(0, a), min(wav.frames, b)
        if b <= a:
            return []
        ch = wav.channels
        if self.arr is not None:
            seg = self.arr[a * ch:b * ch]
            if ch == 1:
                return list(seg)
            if ch == 2:
                return [x + y for x, y in zip(seg[0::2], seg[1::2])]
            return [sum(seg[i:i + ch]) for i in range(0, len(seg), ch)]
        raw = self.audio[a * wav.block:b * wav.block]
        w = wav.bits // 8
        out = []
        for i in range(0, len(raw), wav.block):
            s = 0
            for c in range(ch):
                o = i + c * w
                s += int.from_bytes(raw[o:o + w], "little", signed=True)
            out.append(s >> (wav.bits - 16))
        return out


def onset_scores(reader: _Reader, start: int, onsets: list[float]) -> tuple[float, float, float]:
    """How well the clip's saved transients line up with real attacks at this position.
    For 5, 10 and 25 ms windows: mean log ratio of high-passed energy just after vs just
    before each onset. Around 0 means no relation; a true position scores clearly higher."""
    rate = reader.wav.rate
    out = []
    for ms in (5, 10, 25):
        w = max(8, rate * ms // 1000)
        s, n = 0.0, 0
        for t in onsets:
            p = start + int(round(t * rate))
            seg = reader.mono(p - w - 1, p + w)
            if len(seg) < 2 * w + 1:
                continue
            before = sum((seg[i] - seg[i - 1]) ** 2 for i in range(1, w + 1)) / w
            after = sum((seg[i] - seg[i - 1]) ** 2 for i in range(w + 1, 2 * w + 1)) / w
            s += math.log10((after + 100) / (before + 100))
            n += 1
        out.append(s / n if n else 0.0)
    return out[0], out[1], out[2]


def locate_crops(original: str, targets: list[Target], progress=None) -> dict[str, Found]:
    """Find where each lost crop sat inside `original`. Only 16/24-bit PCM WAV."""
    wav = read_wav_header(original)
    result = {t.key: Found(why="original is not a 16/24-bit PCM WAV") for t in targets}
    if not wav:
        return result
    with open(original, "rb") as f:
        f.seek(wav.data_offset)
        audio = f.read(wav.frames * wav.block)
    header_len = 44
    window = CRC_BYTES - header_len
    want: dict[int, list[tuple[int, int]]] = {}
    for i, t in enumerate(targets):
        body = t.size - header_len
        if body <= 0 or body % wav.block:
            result[t.key] = Found(why="size doesn't fit this original's format")
            continue
        frames = body // wav.block
        if frames > wav.frames:
            result[t.key] = Found(why="longer than the original")
            continue
        if body < window:  # tiny crop: the CRC covers the whole file
            result[t.key] = Found(why="too short to locate")
            continue
        base = _zeros(crc16(wav_header(frames, wav.channels, wav.rate, wav.bits)), window)
        want.setdefault(t.crc ^ base, []).append((i, wav.frames - frames))
        result[t.key] = Found(frames=frames, why="no matching position in the original")
    if not want:
        return result
    hits = find_positions(audio, wav.block, want, window, progress)
    reader, rate = _Reader(audio, wav), wav.rate
    for i, t in enumerate(targets):
        starts = hits.get(i)
        found = result[t.key]
        if not starts:
            continue
        found.candidates = len(starts)
        found.rate = wav.rate
        frames = found.frames
        # How many positions would match by pure chance (a 16-bit CRC: 1 in 65,536).
        chance = (wav.frames - frames + 1) / 65536
        if len(starts) == 1 and chance < 0.05:
            found.start, found.sure = starts[0], True
            found.why = "the only position that fits (Live's fingerprint)"
            continue
        if not t.onsets:
            found.start = starts[0]
            found.why = (f"{len(starts)} possible positions, no transients saved to tell them apart"
                         if len(starts) > 1 else "one possible position, no transients saved to confirm it")
            continue
        scores = {s: onset_scores(reader, s, t.onsets) for s in starts}
        mean = {s: sum(v) / 3 for s, v in scores.items()}
        start = max(starts, key=lambda s: mean[s])
        best = mean[start]
        near = rate // 20  # positions closer than 50 ms blur together in the longer windows
        runner, close = 0.0, False
        for s in starts:
            if s == start:
                continue
            if abs(s - start) < near:
                # Tell close neighbours apart with the sharpest (5 ms) window only.
                if scores[start][0] < 2 * max(scores[s][0], 0.02):
                    close = True
            else:
                runner = max(runner, mean[s])
        found.start = start
        edge = start == 0 or start + frames == wav.frames
        # Thresholds from real crops: true positions scored 0.21-0.34 and at least 2.3x the
        # next best; chance positions and wrong originals stayed at or below 0.12.
        if close:
            found.why = f"{len(starts)} possible positions, two are too close to tell apart"
        elif best >= 0.16 and best >= 2 * max(runner, 0.02):
            found.sure, found.why = True, f"transients line up ({best:.2f} vs next best {runner:.2f})"
        elif edge and best >= 0.08 and best >= 1.5 * max(runner, 0.02):
            found.sure, found.why = True, "fits the start/end of the original, transients line up"
        else:
            found.why = f"{len(starts)} possible positions, best one not clear ({best:.2f} vs {runner:.2f})"
    return result


def rebuild_crop(original: str, start: int, frames: int, out_path: str,
                 size: int, crc: int | None) -> str:
    """Write the cropped stretch as its own WAV. Returns "" on success, else the reason.
    The written file must match the size (and CRC, if known) Live recorded."""
    wav = read_wav_header(original)
    if not wav:
        return "original is not a 16/24-bit PCM WAV"
    with open(original, "rb") as f:
        f.seek(wav.data_offset + start * wav.block)
        body = f.read(frames * wav.block)
    data = wav_header(frames, wav.channels, wav.rate, wav.bits) + body
    if len(data) != size:
        return "rebuilt file has the wrong size"
    if crc is not None and crc16(data[:CRC_BYTES]) != crc:
        return "rebuilt file doesn't match Live's fingerprint"
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    tmp = out_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    from .safe_io import move_into_place
    return move_into_place(tmp, out_path)


# ---- reading the clips that used a lost file -------------------------------------

_CLIP_RE = re.compile(r"<AudioClip [^>]*>.*?</AudioClip>", re.S)
_ONSET_RE = re.compile(r'<OnsetEvent Time="([^"]+)" Energy="([^"]+)" IsVolatile="false"')


def clip_onsets(als_path: str, file_name: str) -> list[float]:
    """Transient times (seconds in the file) Live saved for clips playing `file_name`."""
    try:
        text = gzip.open(als_path, "rb").read().decode("utf-8", "replace")
    except OSError:
        return []
    times: set[float] = set()
    needle = f'<Name Value="{file_name}"'
    for m in _CLIP_RE.finditer(text):
        clip = m.group(0)
        if needle not in clip and f"/{file_name}\"" not in clip and f"\\{file_name}\"" not in clip:
            continue
        for t, energy in _ONSET_RE.findall(clip):
            if energy == "Invalid":
                continue
            try:
                times.add(round(float(t), 6))
            except ValueError:
                pass
    return sorted(times)


_CROP_SUFFIX = re.compile(r"^(.*?)(?:-\d+)?(\.[^.]+)$")


def crop_source_name(crop_name: str) -> str:
    """'BSA-Vox-Lead-Dry-3.wav' -> 'BSA-Vox-Lead-Dry.wav' (Live numbers repeated crops)."""
    m = _CROP_SUFFIX.match(crop_name)
    return (m.group(1) + m.group(2)) if m else crop_name


# ---- reversed files ---------------------------------------------------------------
#
# Live's Reverse writes Samples/Processed/Reverse/<name> R.wav: the same format, a plain
# 44-byte header, and the original's frames in reverse order. Some versions add one more
# frame at the end, a copy of the original's first frame. Checked against real pairs.

_REV_SUFFIX = re.compile(r"^(.*) R(?:-\d+)?(\.[^.]+)$", re.I)


def reverse_source_name(rev_name: str) -> str | None:
    """'Crash R.wav' / 'Crash R-2.wav' -> 'Crash.wav'."""
    m = _REV_SUFFIX.match(rev_name)
    return (m.group(1) + m.group(2)) if m else None


def reversed_wav(original: str, size: int) -> bytes | None:
    """Live's reversed version of `original` with the given total size, or None."""
    wav = read_wav_header(original)
    if not wav:
        return None
    n, block = wav.frames, wav.block
    if size == 44 + n * block:
        extra = 0
    elif size == 44 + (n + 1) * block:
        extra = 1
    else:
        return None
    with open(original, "rb") as f:
        f.seek(wav.data_offset)
        audio = f.read(n * block)
    if len(audio) != n * block:
        return None
    frames = [audio[i:i + block] for i in range(0, len(audio), block)]
    frames.reverse()
    if extra:
        frames.append(frames[-1])
    return wav_header(n + extra, wav.channels, wav.rate, wav.bits) + b"".join(frames)


def reverse_matches(original: str, size: int, crc: int | None) -> bool:
    """True when reversing `original` gives exactly the file Live recorded (size + fingerprint)."""
    if crc is None:
        return False
    wav = read_wav_header(original)
    if not wav:
        return False
    n, block = wav.frames, wav.block
    if size not in (44 + n * block, 44 + (n + 1) * block):
        return False
    extra = (size - 44) // block - n
    # Only the start of the reversed file (the end of the original) is needed for the CRC.
    need = min(n, (CRC_BYTES - 44) // block + 1)
    with open(original, "rb") as f:
        f.seek(wav.data_offset + (n - need) * block)
        tail = f.read(need * block)
    head = b"".join(tail[i:i + block] for i in range(len(tail) - block, -1, -block))
    data = wav_header(n + extra, wav.channels, wav.rate, wav.bits) + head
    if len(data) < CRC_BYTES and extra:
        data += tail[:block]
    return crc16(data[:CRC_BYTES]) == crc


def rebuild_reverse(original: str, out_path: str, size: int, crc: int | None) -> str:
    data = reversed_wav(original, size)
    if data is None:
        return "original doesn't fit the reversed file's size"
    if crc is not None and crc16(data[:CRC_BYTES]) != crc:
        return "rebuilt file doesn't match Live's fingerprint"
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    tmp = out_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    from .safe_io import move_into_place
    return move_into_place(tmp, out_path)


# ---- confirming a renamed copy ----------------------------------------------------

def starts_silent(path: str) -> bool:
    """True when the audio inside the fingerprinted first 16 KB is all digital silence,
    so the fingerprint says nothing about the content."""
    wav = read_wav_header(path)
    if not wav:
        return False
    with open(path, "rb") as f:
        f.seek(wav.data_offset)
        head = f.read(max(0, CRC_BYTES - wav.data_offset))
    return not any(head)


def same_content(paths: list[str]) -> bool:
    """True when all the files are byte-for-byte identical."""
    import hashlib
    digests = set()
    for p in paths:
        h = hashlib.sha1()
        try:
            with open(p, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
        except OSError:
            return False
        digests.add(h.digest())
    return len(digests) == 1


def transient_score(path: str, onsets: list[float]) -> float | None:
    """How well a file's attacks line up with the transients Live saved for the clip
    (same measure as for crops, at position 0). None if it can't be measured."""
    wav = read_wav_header(path)
    if not wav or not onsets:
        return None
    with open(path, "rb") as f:
        f.seek(wav.data_offset)
        audio = f.read(wav.frames * wav.block)
    return sum(onset_scores(_Reader(audio, wav), 0, onsets)) / 3
