"""Compare the plugins projects use with the plugins installed on this computer."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

# Common Windows plugin locations. More can be passed on the command line.
DEFAULT_VST3 = [
    r"C:\Program Files\Common Files\VST3",
    r"C:\Program Files (x86)\Common Files\VST3",
]
DEFAULT_VST2 = [
    r"C:\Program Files\VSTPlugins",
    r"C:\Program Files\VST Plugins",
    r"C:\Program Files\Steinberg\VSTPlugins",
    r"C:\Program Files\Common Files\VST2",
    r"C:\Program Files\Common Files\Steinberg\VST2",
    r"C:\Program Files (x86)\VstPlugins",
    r"C:\Program Files (x86)\Vst Plugins",
    r"C:\Program Files (x86)\Steinberg\VstPlugins",
]


def plugin_key(name: str) -> str:
    """'ValhallaVintageVerb_x64', 'Endless Smile 64.dll', 'Kick 2 x64' -> comparable keys."""
    n = name.lower().strip()
    n = re.sub(r"\.(dll|vst3)$", "", n)
    n = re.sub(r"[\s_\-.(]*(x64|x86_64|64[\s_-]?bit|64)\)?$", "", n)
    return re.sub(r"[^a-z0-9]", "", n)


def plugin_family(name: str) -> str:
    """Name without version numbers or bitness: 'Spire-1.1' and 'Spire-1.5' -> 'spire'."""
    n = re.sub(r"\.(dll|vst3)$", "", name.lower().strip())
    n = re.sub(r"[^a-z]", "", re.sub(r"\bv?\d+(\.\d+)*\b|x64|x86|\d+", "", n))
    return n if len(n) >= 3 else plugin_key(name)


@dataclass
class Installed:
    vst2: dict[str, str] = field(default_factory=dict)  # key -> .dll path
    vst3: dict[str, str] = field(default_factory=dict)  # key -> .vst3 path
    vst2_files: set[str] = field(default_factory=set)  # normalized full .dll paths
    families: dict[str, str] = field(default_factory=dict)  # family -> one installed path
    searched: list[str] = field(default_factory=list)


def _norm(path: str) -> str:
    return path.replace("\\", "/").lower()


def find_installed(vst2_dirs: list[str], vst3_dirs: list[str]) -> Installed:
    inst = Installed()
    for d in vst3_dirs:
        if not os.path.isdir(d):
            continue
        inst.searched.append(d)
        for dirpath, dirnames, files in os.walk(d):
            # A .vst3 can be a single file or a bundle folder; don't look inside bundles.
            for name in [n for n in dirnames if n.lower().endswith(".vst3")]:
                inst.vst3.setdefault(plugin_key(name), os.path.join(dirpath, name))
                inst.families.setdefault(plugin_family(name), os.path.join(dirpath, name))
            dirnames[:] = [n for n in dirnames if not n.lower().endswith(".vst3")]
            for f in files:
                if f.lower().endswith(".vst3"):
                    inst.vst3.setdefault(plugin_key(f), os.path.join(dirpath, f))
                    inst.families.setdefault(plugin_family(f), os.path.join(dirpath, f))
    for d in vst2_dirs:
        if not os.path.isdir(d):
            continue
        inst.searched.append(d)
        for dirpath, dirnames, files in os.walk(d):
            # Some installers put VST3 plugins in the VST2 folder too; count those as VST3.
            for name in [n for n in dirnames if n.lower().endswith(".vst3")]:
                inst.vst3.setdefault(plugin_key(name), os.path.join(dirpath, name))
                inst.families.setdefault(plugin_family(name), os.path.join(dirpath, name))
            dirnames[:] = [n for n in dirnames if not n.lower().endswith(".vst3")]
            for f in files:
                full = os.path.join(dirpath, f)
                if f.lower().endswith(".dll"):
                    inst.vst2.setdefault(plugin_key(f), full)
                    inst.vst2_files.add(_norm(full))
                    inst.families.setdefault(plugin_family(f), full)
                elif f.lower().endswith(".vst3"):
                    inst.vst3.setdefault(plugin_key(f), full)
                    inst.families.setdefault(plugin_family(f), full)
    return inst


@dataclass
class PluginStatus:
    name: str
    fmt: str
    projects: int
    project_names: list[str]
    old_files: list[str]
    status: str  # installed / other format / missing
    found_at: str = ""


def check(usage_rows, inst: Installed) -> list[PluginStatus]:
    out = []
    for r in usage_rows:
        files = [f for f in (r["files"] or "").split(",") if f]
        keys = {plugin_key(r["name"])} | {plugin_key(f.replace("\\", "/").rsplit("/", 1)[-1]) for f in files}
        status, found = "missing", ""
        if r["format"] == "VST2":
            here = next((f for f in files if os.path.exists(f)), "")
            match = here or next((inst.vst2[k] for k in keys if k in inst.vst2), "")
            if match:
                status, found = "installed", match
            elif any(k in inst.vst3 for k in keys):
                status = "only VST3 installed"
                found = next(inst.vst3[k] for k in keys if k in inst.vst3)
        elif r["format"] == "VST3":
            match = next((inst.vst3[k] for k in keys if k in inst.vst3), "")
            if match:
                status, found = "installed", match
            elif any(k in inst.vst2 for k in keys):
                status = "only VST2 installed"
                found = next(inst.vst2[k] for k in keys if k in inst.vst2)
        else:
            status = "not checked (AU)"
        if status == "missing":
            fam = plugin_family(r["name"])
            if fam in inst.families:
                status, found = "different version installed", inst.families[fam]
        out.append(PluginStatus(r["name"], r["format"], r["projects"],
                                sorted((r["project_names"] or "").split(",")), files, status, found))
    return out
