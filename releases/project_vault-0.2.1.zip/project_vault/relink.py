"""Find missing samples and where they live now. Report only: projects are never changed."""
from __future__ import annotations

import os
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from .fingerprint import same_file

AUDIO_EXTS = {".wav", ".aif", ".aiff", ".mp3", ".flac", ".ogg", ".m4a", ".rx2"}

# Folders never worth searching when a whole drive is given.
SKIP_DIRS = {"windows", "program files", "program files (x86)", "programdata", "$recycle.bin",
             "system volume information", "appdata", "windowsapps", "node_modules", ".git",
             "$windows.~bt", "$windows.~ws", "recovery", "perflogs", "msocache"}

# Sounds from Ableton's own packs. Live finds these through the installed pack,
# not the stored path, so they are only truly missing if the pack isn't installed.
ABLETON_LIBRARY_MARKERS = (
    "/programdata/ableton/",
    "/program files/ableton",
    "/program files (x86)/ableton",
    "/factory packs/",
    "/core library/",
    "/ableton/library/",  # Live 8 era library under My Documents
)

# Files Live writes itself. Frozen tracks are rebuilt by Live. Cropped, reversed and
# consolidated files keep the original's name but hold different audio, so a file with
# the same name elsewhere is usually the unedited original, not this file.
LIVE_EDITED = ("crop", "reverse", "consolidate")


def live_generated(path: str) -> str | None:
    p = path.replace("\\", "/").lower()
    if "/samples/processed/freeze/" in p or "/samples/freeze/" in p:
        return "freeze"
    for kind in LIVE_EDITED:
        if f"/samples/processed/{kind}/" in p or f"/samples/{kind}/" in p:
            return kind
    return None


def is_ableton_library(path: str) -> bool:
    p = path.replace("\\", "/").lower()
    return any(m in p for m in ABLETON_LIBRARY_MARKERS)


def old_location(path: str) -> str:
    """Group a path by the computer folder it came from, e.g. C:/Users/chickensoup/Desktop."""
    parts = path.replace("\\", "/").split("/")
    if len(parts) > 3 and parts[1].lower() in ("users", "documents and settings"):
        return "/".join(parts[:4])
    return "/".join(parts[:3])


def sample_exists(row) -> bool:
    if row["path"] and os.path.exists(row["path"]):
        return True
    if row["rel_path"]:
        return (Path(row["project_path"]).parent / row["rel_path"]).exists()
    return False


@dataclass
class MissingProject:
    name: str
    path: str
    # (sample path, file name, size, Live fingerprint) -> track names using it
    samples: dict[tuple, list[str]] = field(default_factory=dict)


def collect_missing(db) -> list[MissingProject]:
    projects: dict[str, MissingProject] = {}
    for r in db.sample_uses_for_check():
        if sample_exists(r):
            continue
        mp = projects.setdefault(r["project_path"], MissingProject(r["project"], r["project_path"]))
        tracks = mp.samples.setdefault((r["path"], r["file_name"], r["size"], r["crc"]), [])
        if r["track_name"] not in tracks:
            tracks.append(r["track_name"])
    return sorted(projects.values(), key=lambda p: p.name.lower())


def build_index(folders: list[str], progress=None) -> tuple[dict[str, list[str]], int]:
    """Map lowercase file name -> every copy found under the given folders."""
    index: dict[str, list[str]] = defaultdict(list)
    count = 0
    for folder in folders:
        for dirpath, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS]
            for f in files:
                if os.path.splitext(f)[1].lower() in AUDIO_EXTS:
                    index[f.lower()].append(os.path.join(dirpath, f))
                    count += 1
                    if progress and count % 20000 == 0:
                        progress(count)
    return index, count


def _dir_parts(path: str) -> list[str]:
    return [p.lower() for p in path.replace("\\", "/").split("/")[:-1] if p]


def _trailing_match(a: list[str], b: list[str]) -> int:
    n = 0
    while n < min(len(a), len(b)) and a[-1 - n] == b[-1 - n]:
        n += 1
    return n


def _size(path: str) -> int | None:
    try:
        return os.path.getsize(path)
    except OSError:
        return None


EDITED_LABEL = {
    "crop": "cropped in Live (only the uncropped original exists)",
    "reverse": "reversed in Live (only the forward original exists)",
    "consolidate": "consolidated in Live (file not found)",
}

# How sure each match type is. "check" ones are worth a listen before trusting them.
EXACT = "exact file (Live's fingerprint matches)"
RENAMED = "renamed copy (Live's fingerprint matches)"
CONFIDENT = {"only copy", "same file size", "same folder names", "identical copies", EXACT, RENAMED}


def find_renamed(wanted: dict[str, tuple[int, int]], index: dict[str, list[str]],
                 progress=None) -> dict[str, list[str]]:
    """Missing sample -> files under any name with the same size and Live fingerprint.
    wanted: old path -> (size, crc). The caller still has to confirm the audio, because
    the fingerprint covers only the first 16 KB (stems that start silent all look alike)."""
    from .fingerprint import live_crc
    by_size: dict[int, list[tuple[str, int]]] = defaultdict(list)
    for path, (size, crc) in wanted.items():
        by_size[size].append((path, crc))
    found: dict[str, list[str]] = defaultdict(list)
    crcs: dict[str, int | None] = {}
    n = 0
    for paths in index.values():
        for c in paths:
            n += 1
            if progress and n % 20000 == 0:
                progress(n)
            size = _size(c)
            if size not in by_size:
                continue
            for old, crc in by_size[size]:
                if c not in crcs:
                    crcs[c] = live_crc(c)
                if crcs[c] == crc:
                    found[old].append(c)
    return found
REBUILD = "rebuilt from the original"  # how-text prefix for crops Project Vault can recreate


def best_match(old_path: str, size: int | None, candidates: list[str],
               crc: int | None = None) -> tuple[str, str]:
    """Pick the most likely new location. Returns (path, how it was chosen)."""
    edited = live_generated(old_path)
    if edited == "freeze":
        return "", "frozen track (Live rebuilds this)"

    # Live recorded the file's size and a fingerprint of its start: a copy that matches
    # both is the very file the project used, wherever it is now.
    exact = [c for c in candidates if same_file(c, size, crc)] if crc is not None else []
    if exact:
        return sorted(exact)[0], EXACT

    if edited:
        # An edited file has the original's name but different audio. Only a file of the
        # exact same size can be it (and not even that if the fingerprint says otherwise).
        same = [c for c in candidates if size and _size(c) == size]
        if same and crc is None:
            return same[0], "same file size"
        return "", EDITED_LABEL[edited]

    if len(candidates) == 1:
        return candidates[0], "only copy"
    pool = candidates
    if size:
        same = [c for c in candidates if _size(c) == size]
        if len(same) == 1:
            return same[0], "same file size"
        if same:
            pool = same
    old_dirs = _dir_parts(old_path)
    scored = sorted(((_trailing_match(old_dirs, _dir_parts(c)), c) for c in pool), reverse=True)
    top_score, top = scored[0]
    if top_score > 0 and (len(scored) == 1 or scored[1][0] < top_score):
        return top, "same folder names"
    # A tie: if every tied copy is the same size, they are duplicates and any one will do.
    tied = [c for score, c in scored if score == top_score]
    sizes = {_size(c) for c in tied}
    if top_score >= 2 and len(sizes) == 1 and None not in sizes:
        return sorted(tied)[0], "identical copies"
    return top, f"check: {len(pool)} different files share this name"
