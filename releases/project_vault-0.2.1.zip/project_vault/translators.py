"""Translate settings between plugin versions that store them differently.

FabFilter plugins save their settings as "FFBS" + version + count + a list of 32-bit floats.
The order of that list differs between product versions, so handing one version's list to
another scrambles it. These translators rebuild the new version's list value by value.

Pro-Q 2 and Pro-Q 3 band layouts are based on Per Ivar Nerseth's PresetConverter
(MIT License, https://github.com/perivar/PresetConverter), checked against Pro-Q 3 data
saved by Ableton Live.
"""
from __future__ import annotations

import math
import struct

SHAPES = ["Bell", "Low Shelf", "Low Cut", "High Shelf", "High Cut", "Notch", "Band Pass", "Tilt Shelf"]
SLOPES = ["6", "12", "18", "24", "30", "36", "48", "72", "96"]


def _floats(chunk: bytes) -> tuple[bytes, int, list[float], bytes] | None:
    """Split a FabFilter chunk into (magic, version, values, trailing bytes)."""
    if len(chunk) < 12 or chunk[:4] not in (b"FFBS", b"FQ2p", b"FQ3p"):
        return None
    version, count = struct.unpack("<II", chunk[4:12])
    end = 12 + 4 * count
    if count == 0 or count > 5000 or len(chunk) < end:
        return None
    return chunk[:4], version, list(struct.unpack(f"<{count}f", chunk[12:end])), chunk[end:]


def _is_int(v: float, lo: int, hi: int) -> bool:
    return v == int(v) and lo <= v <= hi


PROQ2_PARAMS = 191  # automatable parameters Pro-Q 2 exposes to the host
_LOG2_10HZ, _LOG2_30KHZ = math.log2(10), math.log2(30000)


def proq2_from_params(chunk: bytes) -> bytes | None:
    """Older Live versions saved Pro-Q 2 as its host parameters (a 28-byte program name and 191
    values from 0 to 1) instead of FabFilter's own format. The parameters come in the same order
    as FabFilter's list, so rebuild that list from them: band state, frequency (10 Hz-30 kHz,
    log), gain (-30..+30 dB), Q (already 0-1), shape (8), slope (9) and stereo placement (3)."""
    if len(chunk) != 28 + 4 * PROQ2_PARAMS:
        return None
    p = list(struct.unpack(f"<{PROQ2_PARAMS}f", chunk[28:]))
    if not all(-1e-4 <= v <= 1.0001 for v in p):
        return None
    vals = []
    for b in range(24):
        state, freq, gain, q, shape, slope, stereo = p[b * 7:(b + 1) * 7]
        vals += [float(round(state * 2)), _LOG2_10HZ + freq * (_LOG2_30KHZ - _LOG2_10HZ), gain * 60 - 30,
                 q, float(round(shape * 7)), float(round(slope * 8)), float(round(stereo * 2))]
    tail = p[24 * 7:]
    tail[2] = float(round(tail[2]))  # channel mode: 0 = Left/Right, 1 = Mid/Side
    vals += tail
    return b"FFBS" + struct.pack("<II", 1, len(vals)) + struct.pack(f"<{len(vals)}f", *vals)


def proq2_bands(chunk: bytes) -> list[dict] | None:
    """Read Pro-Q 2's 24 bands (7 values each). Returns None if anything looks unexpected."""
    parsed = _floats(chunk) or _floats(proq2_from_params(chunk) or b"")
    if not parsed:
        return None
    _, _, vals, _ = parsed
    if len(vals) < 24 * 7 + 3:
        return None
    channel_mode = vals[24 * 7 + 2]  # 0 = Left/Right, 1 = Mid/Side
    if not _is_int(channel_mode, 0, 1):
        return None
    bands = []
    for b in range(24):
        state, freq, gain, q, shape, slope, stereo = vals[b * 7:(b + 1) * 7]
        if not (_is_int(state, 0, 2) and 3.0 <= freq <= 15.0 and -30.5 <= gain <= 30.5 and 0.0 <= q <= 1.0
                and _is_int(shape, 0, 7) and _is_int(slope, 0, 8) and _is_int(stereo, 0, 2)):
            return None
        is_default = abs(freq - math.log2(1000)) < 1e-3 and gain == 0 and shape == 0
        used = state == 1 or (state == 2 and not is_default)
        bands.append({"used": used, "enabled": state == 1, "freq": freq, "gain": gain, "q": q,
                      "shape": int(shape), "slope": int(slope), "stereo": int(stereo),
                      "mid_side": channel_mode == 1})
    return bands


def proq2_to_proq3(old_chunk: bytes, proq3_chunk: bytes) -> bytes | None:
    """Pro-Q 2 settings -> Pro-Q 3 settings. proq3_chunk is any real Pro-Q 3 state, used for the
    layout and for the values Pro-Q 2 has no equivalent for (dynamic EQ, solo, globals)."""
    bands = proq2_bands(old_chunk)
    target = _floats(proq3_chunk)
    if not bands or not target:
        return None
    magic, version, vals, trailing = target
    if len(vals) < 24 * 13:
        return None
    for b, band in enumerate(bands):
        base = b * 13
        if not band["used"]:  # Pro-Q 3's own unused-band defaults
            vals[base:base + 13] = [0.0, 1.0, math.log2(1000), 0.0, 0.0, 1.0, 1.0, 0.5, 0.0, 1.0, 2.0, 1.0, 0.0]
            continue
        stereo = band["stereo"]
        if band["mid_side"] and stereo in (0, 1):
            stereo = 3 + stereo  # Pro-Q 3: 3 = Mid, 4 = Side
        vals[base + 0] = 1.0  # used
        vals[base + 1] = 1.0 if band["enabled"] else 0.0
        vals[base + 2] = band["freq"]  # log2(Hz) in both versions
        vals[base + 3] = band["gain"]  # dB
        vals[base + 4] = 0.0  # no dynamic range in Pro-Q 2
        vals[base + 7] = band["q"]  # same Q encoding in both versions
        vals[base + 8] = float(band["shape"])  # Pro-Q 2 shapes 0-7 = Pro-Q 3 shapes 0-7
        vals[base + 9] = float(band["slope"])  # 6..96 dB/oct, same numbering
        vals[base + 10] = float(stereo)
        vals[base + 12] = 0.0  # solo off
    return magic + struct.pack("<II", version, len(vals)) + struct.pack(f"<{len(vals)}f", *vals) + trailing


def describe_proq2(old_chunk: bytes) -> str:
    """Short human-readable summary of the used bands, for the swap report."""
    bands = proq2_bands(old_chunk) or []
    parts = []
    for b in bands:
        if not b["used"]:
            continue
        hz = 2 ** b["freq"]
        f = f"{hz / 1000:.1f}kHz" if hz >= 1000 else f"{hz:.0f}Hz"
        q = 10 ** ((b["q"] - 0.5) / 0.312098175)
        if b["shape"] in (2, 4):
            parts.append(f"{SHAPES[b['shape']]} {f} {SLOPES[b['slope']]}dB/oct")
        else:
            parts.append(f"{SHAPES[b['shape']]} {f} {b['gain']:+.1f}dB Q{q:.2f}")
        if not b["enabled"]:
            parts[-1] += " (off)"
    return "; ".join(parts)


def is_fabfilter(plugin_name: str) -> bool:
    return plugin_name.lower().replace(" ", "").startswith("fabfilter")


def is_fabfilter_state(chunk: bytes) -> bool:
    return chunk[:4] in (b"FFBS", b"FQ2p", b"FQ3p")


# ---- Bark of Dog 2 (VST2) -> Bark of Dog 3 (VST3) ---------------------------------------
#
# Bark of Dog 2 saves 7 plain knob positions (0-1): Bypass, Mix, Master Volume, Frequency,
# Boost, Mode, Channel Mode. Bark of Dog 3 saves its knobs by name in real units (JUCE state).
# Bark of Dog 3's curves were measured from Bark of Dog 3 instances in real projects (each
# saves the knob position next to the real value):
#   Frequency = 10 + 1990 * pos ** 3.0517 Hz  (exact on all 4 samples: 64.7, 86.7, 180, 709 Hz)
#   Boost     = 24 * pos dB                   (exact on all 4 samples)
#   Mode      = 0/0.5/1 -> Classic/Passive/Combo
# The same knob positions mean the same in Bark of Dog 2: confirmed by ear in Live, Nov 2026
# (dirt devils kicks: 51 Hz +20.6 dB Passive, 81 Hz +15.2 dB Combo). Bark of Dog 3 has no
# output volume, so a changed Master Volume is reported.

BARK3_STATE = bytes.fromhex(
    "506172616d65746572730000010b504152414d000102696400010b05416e616c6f675f49440076616c756500010904000000000000000000504152414d000102696400010a05426f6f73745f49440076616c75650001090400000040b81e2e4000504152414d0001026964000119054368616e6e656c436f6e66696775726174696f6e5f49440076616c756500010904000000000000000000504152414d000102696400010e054672657175656e63795f49440076616c75650001090400000000a62b864000504152414d000102696400010e05496e7075744761696e5f49440076616c756500010904000000003fb52ac000504152414d000102696400010f054d61737465725f4d69785f49440076616c756500010904000000000000594000504152414d0001026964000109054d6f64655f49440076616c756500010904000000000000000000504152414d000102696400011205506c7567696e5f456e61626c655f49440076616c756500010904000000000000f03f00656469746f7200010273697a652d78000105018a02000073697a652d7900010501c7010000006c6173747072657365740001016e616d650001020500006465736372697074696f6e000102746578745469746c650001020500746578744c6f6e6700010205000000000000000000004a554345507269766174654461746100010142797061737300010103001d000000000000004a5543455072697661746544617461")
BARK3_MODES = ["Classic", "Passive", "Combo"]


def _bark2_values(old_chunk: bytes) -> list[float] | None:
    if len(old_chunk) == 28 + 4 * 7:
        body = old_chunk[28:]
    elif len(old_chunk) == 4 * 7:
        body = old_chunk
    else:
        return None
    vals = list(struct.unpack("<7f", body))
    return vals if all(0.0 <= v <= 1.0 for v in vals) else None


def bark2_to_bark3(old_chunk: bytes, bark3_state: bytes | None) -> bytes | None:
    from .juce_state import build, params, parse, set_params
    vals = _bark2_values(old_chunk)
    if vals is None:
        return None
    parsed = parse(bark3_state) if bark3_state else None
    if not parsed or "Frequency_ID" not in params(parsed[0]):
        parsed = parse(BARK3_STATE)
    tree, tail = parsed
    bypass, mix, _volume, freq, boost, mode, _channels = vals
    set_params(tree, {
        "Plugin_Enable_ID": 0.0 if bypass >= 0.5 else 1.0,
        "Master_Mix_ID": round(mix * 100, 3),
        "Frequency_ID": round(10 + 1990 * freq ** 3.0517, 3),
        "Boost_ID": round(24 * boost, 3),
        "Mode_ID": float(min(2, round(mode * 2))),
        "InputGain_ID": 0.0,
        "ChannelConfiguration_ID": 0.0,  # stereo
        "Analog_ID": 0.0,
    })
    return build(tree, tail)


def describe_bark2(old_chunk: bytes) -> str:
    vals = _bark2_values(old_chunk)
    if vals is None:
        return ""
    bypass, mix, volume, freq, boost, mode, _ = vals
    text = (f"{10 + 1990 * freq ** 3.0517:.0f} Hz, +{24 * boost:.1f} dB, "
            f"{BARK3_MODES[min(2, round(mode * 2))]}, mix {mix * 100:.0f}%")
    if bypass >= 0.5:
        text += ", off"
    if abs(volume - 0.5) > 0.01:
        text += "; Bark of Dog 2's output volume isn't in Bark of Dog 3, set Gain by ear"
    return text


# Kickstart (VST2, Cableguys/Nicky Romero) -> Kickstart 2 (VST3).
# Kickstart's chunk: 32-byte header ("Kickstart") + 1944 floats. Floats 0-23 are the knobs,
# then 32 curve slots of 20 points (x 0..1, y 0..1, shape). Kickstart 2 stores a zlib'd JUCE
# ValueTree ("#zip#" header) with the same 16 curves as points (x 0..8191, y -1..1, factor).
# Learned from 5 Kickstart and 44 Kickstart 2 instances in real projects (Nov 2026):
#   the 16 curves match point for point: x * 8192, 2y - 1, shape 0.25/0.5/1.0 -> 1/2/3, 0 = unused
#   float 1  = selected curve / 16 (Kickstart 2 usedWave)
#   float 16 = mix 0..1
# Every Kickstart seen had the same values in the other knob slots (loop length, MIDI), so only
# exactly those are translated; anything else keeps the safe reset and the saved .fxp.
KICKSTART2_STATE = bytes.fromhex(
    "237a69702300789ced9abf6f133114c7ed5c9d5f0db4a0809080c25809a94285812562a05010b40d0a02862e6ece4d4e"
    "dcd9c7c5096da7ae4c9d5958901833b252f59fe8088c50a02c1503033897a4f95194b338c74d4ab753fcee7dcfcf9ff7"
    "fc7c97ac5d2e5834c73127001a15e2952c46c515ba0eb21e2b78d899c78e181a45f7adfcb312c71e07dc7288b8725c00"
    "13d1f92b2ff96b08004c655baee608c733986300a165029844cefe0f46897b162d0018a98d245053b282ed32a90b830e"
    "9313c8f59859ce73ff411a66a9d6e34c77d98f37ed1f777a8ea1e9a9ab533700b0286f98a690cd98fb80d0022f36cd10"
    "149369374aa27289984f7085b44c40a7c9282ab984988f56dd6e1b42cb0ef130f783eac7e2146294e48a8cdfa666b688"
    "4bc2767cd96658f8828d7b1323febdebbb37c1111ad97ef3f5ef2397abb39f553e01f8a172a4a6336799562345fc358c"
    "2247fc02e0483b25169d21152bdf8b128bde2a624a89dd03368b2ee4792fd8e2c2649ef16e8325c6ec86c56924f2a150"
    "205ece618c176ba9d1b08591e62c7d4324e6b1020e46a2cd571c2d616a2eec6711343a3c8cf9c3773cf2bc4c687eb5db"
    "d7c70e5f49df38c76cd6e6ed6086c4d00b31ff92c88b7bd4242bf5dcab9715668ad809b38337c591cb448cc45dd16ced"
    "425819ad981968a52b5ced933050e783afbfb5bebcef88f832ce73e6b55c446a2e0275c60374eac1eea563c8e8542fe9"
    "d1d93124747ac70dcae84c2643cf474a271309d0d9dcfdf55d623ec794cae86c6ba27443d1aa06e9bc4ae8a1741baac9"
    "bafe503a194469f0d30d14a55b9a28dd8ae9a9a5201554453efcfca6a396f69352342894ee9c395a94a66576620594ae"
    "05512a594bfb434f5a578d3b774ccfbfd023a5d32f7a62ffdbce053465437a440f3d194da78daa4cbfa862c70fcf5b1f"
    "6ba92e7a16c7f46483ae534d465336ec450f919ef0676245f4e85ad5c5a0372a9bef9c1d05ab1aa8a3a8c629d889d575"
    "16479e525d9dc5c30b7a745c999aada25f9cd0930d6b323a83fb7e71c8285dd6747a4a86a754aeff0d9f7552944e5c3c"
    "444ad5f48b0a56f56ef8ee5c4ae7b74c67a1400784efe3e4b23bae261b869b1e6dab2a5313549c2135d1f354d18e3fb0"
    "f4484521930ed0a97db15250e9c1593d94ee29ea7b02774845940e373d938ade9d07cee7e4313d03468f8268a73575cd"
    "d7c2f75752d99094f902a7809e64f81dbf8fdf1c14fc23482ada9f64ba3f15b5277c3648cd672368275644cfaca66ca8"
    "9ed7b33eaadea8fc01fee694ba00000000000000004a5543455072697661746544617461000101427970617373000101"
    "03001d000000000000004a5543455072697661746544617461"
)
_KS1_FIXED = {0: 0.25, 2: 0.0, 3: 1.0, 9: 1 / 17, 14: 5 / 13}
_KS1_SHAPES = {0.25: 1, 0.5: 2, 1.0: 3}


def _ks1_values(old_chunk: bytes) -> tuple[list[float], list[list[tuple[float, float, float]]]] | None:
    if len(old_chunk) != 32 + 4 * 1944 or not old_chunk[8:17] == b"Kickstart":
        return None
    f = struct.unpack("<1944f", old_chunk[32:])
    for i in range(24):
        want = _KS1_FIXED.get(i, f[i] if i in (1, 16) else 0.0)
        if abs(f[i] - want) > 1e-3:
            return None
    if not (0 <= f[16] <= 1) or abs(f[1] * 16 - round(f[1] * 16)) > 1e-3 or not 0 <= f[1] * 16 <= 15:
        return None
    waves = []
    for w in range(16):
        pts = []
        for p in range(20):
            x, y, shape = f[24 + 60 * w + 3 * p: 27 + 60 * w + 3 * p]
            if shape == 0:
                continue  # unused slot
            if shape not in _KS1_SHAPES or not (0 <= x <= 1 and 0 <= y <= 1):
                return None
            pts.append((x, y, shape))
        waves.append(pts)
    return list(f[:24]), waves


def _ks2_split(state: bytes):
    import zlib
    from .juce_state import parse
    if not state or not state.startswith(b"#zip#\0"):
        return None
    try:
        d = zlib.decompressobj()
        inner = d.decompress(state[6:])
    except zlib.error:
        return None
    parsed = parse(inner)
    if not parsed:
        return None
    waves = [k for k in parsed[0].kids if k.get("id") == "waves"]
    if not waves or len(waves[0].kids) != 16:
        return None
    return parsed[0], parsed[1], d.unused_data, waves[0]


def _ks2_set(tree, key: str, value) -> None:
    for k in tree.kids:
        if k.get("id") == key:
            for n, (name, t, body) in enumerate(k.props):
                if name == "value":
                    if isinstance(value, bool):
                        k.props[n] = ("value", 2 if value else 3, b"")
                    elif isinstance(value, int):
                        k.props[n] = ("value", 1, struct.pack("<i", value))
                    else:
                        k.props[n] = ("value", 4, struct.pack("<d", value))
            return


def _ks2_point(x: int, y: float, factor: int):
    from .juce_state import Node
    return Node("Point", [], [
        Node("int", [("id", 5, b"x\0"), ("value", 1, struct.pack("<i", x))], []),
        Node("float", [("id", 5, b"y\0"), ("value", 4, struct.pack("<d", y))], []),
        Node("int", [("id", 5, b"factor\0"), ("value", 1, struct.pack("<i", factor))], []),
    ])


def kickstart_to_kickstart2(old_chunk: bytes, ks2_state: bytes | None) -> bytes | None:
    import zlib
    from .juce_state import build
    vals = _ks1_values(old_chunk)
    if vals is None:
        return None
    knobs, waves = vals
    split = _ks2_split(ks2_state) if ks2_state else None
    tree, tail, rest, wave_list = split or _ks2_split(KICKSTART2_STATE)
    _ks2_set(tree, "loopLength", 1)
    _ks2_set(tree, "speedType", 0)
    _ks2_set(tree, "usedWave", int(round(knobs[1] * 16)))
    _ks2_set(tree, "mix", float(struct.unpack("<f", struct.pack("<f", knobs[16]))[0]))
    _ks2_set(tree, "triggerSmoothing", True)
    _ks2_set(tree, "bandOn", False)
    _ks2_set(tree, "bandSolo", False)
    for model, pts in zip(wave_list.kids, waves):
        if not pts or not model.kids:
            continue
        model.kids[0].kids = [
            _ks2_point(min(8191, round(x * 8192)), struct.unpack("<f", struct.pack("<f", 2 * y - 1))[0],
                       _KS1_SHAPES[s])
            for x, y, s in pts]
    return b"#zip#\0" + zlib.compress(build(tree, tail)) + rest


def describe_kickstart(old_chunk: bytes) -> str:
    vals = _ks1_values(old_chunk)
    if vals is None:
        return ""
    knobs, _ = vals
    return f"curve {round(knobs[1] * 16) + 1}, mix {knobs[16] * 100:.0f}%, curves carried over"


# (old plugin key, new plugin key) -> translator for a VST2 -> VST3 swap:
# (old VST2 chunk, the VST3's template state or None) -> new VST3 state
VST3_TRANSLATORS = {
    ("barkofdog2", "barkofdog3"): (bark2_to_bark3, describe_bark2),
    ("kickstart", "kickstart2"): (kickstart_to_kickstart2, describe_kickstart),
}


# (old plugin key, new plugin key) -> translator(old_chunk, new_plugin_chunk) -> new chunk
TRANSLATORS = {
    ("fabfilterproq2", "fabfilterproq3"): (proq2_to_proq3, describe_proq2),
}
