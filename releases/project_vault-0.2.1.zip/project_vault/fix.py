"""Write relinked copies of Ableton projects.

Only the sample-path entries of missing samples are changed; every other byte of
the project's XML is kept exactly as Live wrote it. The original .als is never
modified: the result is saved next to it as "<name> (relinked).als".
"""
from __future__ import annotations

import csv
import gzip
import html
import re
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from .als_reader import read_als, resolve_file_ref
from .database import norm
from .relink import CONFIDENT, REBUILD

SUFFIX = " (relinked)"
FILEREF_RE = re.compile(r"<FileRef>.*?</FileRef>", re.S)


@dataclass
class FixResult:
    project: str
    output: str = ""
    relinked: int = 0  # FileRef entries rewritten
    samples: int = 0  # distinct samples relinked
    skipped: str = ""  # reason the project was not written
    unchanged_refs: list[str] = field(default_factory=list)  # refs we could not rewrite
    rebuilt: list[str] = field(default_factory=list)  # crop files recreated from their originals
    notes: list[str] = field(default_factory=list)


@dataclass
class Rebuild:
    """A lost Live crop to recreate from its original before relinking to it."""
    source: str
    start: int
    frames: int
    target: Path
    reverse: bool = False


def output_path(als: Path) -> Path:
    from .layout import relinked_path
    return relinked_path(als)  # <original folder>\Relinked\<name> (relinked).als


def project_root(als: Path) -> Path:
    """The Live Project folder a set belongs to (the one holding 'Ableton Project Info'),
    which is where Live keeps Samples/Processed. Falls back to the set's own folder."""
    for folder in [als.parent, *list(als.parent.parents)[:3]]:
        if (folder / "Ableton Project Info").is_dir():
            return folder
    return als.parent


def load_plan(csv_path: str, include_check: bool) -> dict[str, dict[str, "str | Rebuild"]]:
    """project file -> {normalized old sample path: new path or Rebuild} from relink_report.csv."""
    plan: dict[str, dict] = defaultdict(dict)
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            new, how = row["found at"].strip(), row["how it was matched"]
            if not new:
                continue
            if how.startswith(REBUILD + ", reversed"):
                target = project_root(Path(row["project file"])) / "Samples" / "Processed" / "Reverse" / row["sample"]
                plan[row["project file"]][norm(row["old location"])] = Rebuild(new, 0, 0, target, reverse=True)
                continue
            if how.startswith(REBUILD) or (include_check and how.startswith("check: " + REBUILD)):
                m = re.search(r"frames (\d+)-(\d+)", how)
                if m:
                    start, end = int(m.group(1)), int(m.group(2))
                    target = project_root(Path(row["project file"])) / "Samples" / "Processed" / "Crop" / row["sample"]
                    plan[row["project file"]][norm(row["old location"])] = Rebuild(new, start, end - start, target)
                continue
            if how in CONFIDENT or (include_check and how.startswith("check")):
                plan[row["project file"]][norm(row["old location"])] = new
    return plan


def _newline_and_indent(block: str, tag: str) -> tuple[str, str]:
    nl = "\r\n" if "\r\n" in block else "\n"
    m = re.search(r"(?:\r?\n)([ \t]*)<" + tag, block)
    return nl, (m.group(1) if m else "")


def uses_list_ids(text: str) -> bool:
    """Live 9 and later give every list member an Id (<RelativePathElement Id="0" .../>);
    Live 8 does not. Writing the wrong style makes Live call the set corrupt."""
    if re.search(r'<RelativePathElement Id="', text):
        return True
    m = re.search(r'Creator="Ableton Live (\d+)', text[:500])
    return bool(m and int(m.group(1)) >= 9)


def _rewrite_block(block: str, new_path: str, use_ids: bool | None = None) -> str | None:
    """Point one <FileRef> at new_path. Returns None if the layout isn't one we can rewrite.
    use_ids: whether list members need Id attributes (see uses_list_ids); None = match the block."""
    win_path = new_path.replace("/", "\\")
    fwd_path = new_path.replace("\\", "/")

    # Live 11/12: a single absolute <Path Value="..."/>.
    if re.search(r'<Path Value="', block):
        return re.sub(r'(<Path Value=")[^"]*(")',
                      lambda m: m.group(1) + html.escape(fwd_path, quote=True) + m.group(2),
                      block, count=1)

    # Live 8-10 on Windows: the absolute path is UTF-16LE hex inside <Data>.
    data = re.search(r"<Data>(.*?)</Data>", block, re.S)
    if not data:
        return None
    nl, indent = _newline_and_indent(block, "Data")
    hex_text = (win_path.encode("utf-16-le") + b"\0\0").hex().upper()
    lines = [hex_text[i:i + 80] for i in range(0, len(hex_text), 80)]
    inner = "".join(nl + indent + "\t" + ln for ln in lines) + nl + indent
    block = block[:data.start(1)] + inner + block[data.end(1):]

    # Drop the old relative path ("../Samples/..." from the project folder). Live 8-10 tries it
    # before the absolute path, so a stale one leaves the sample "missing". This is how Live
    # itself writes a reference to a file on another drive.
    block = re.sub(r'(<HasRelativePath Value=")[^"]*(")', r"\1false\2", block, count=1)
    block = re.sub(r'(<RelativePathType Value=")[^"]*(")', r"\g<1>0\2", block, count=1)
    block = re.sub(r"<RelativePath>.*?</RelativePath>", "<RelativePath />", block, count=1, flags=re.S)

    # Keep Live's search hint in step: folders only, without the drive letter, as Live writes it.
    hint = re.search(r"<PathHint>(.*?)</PathHint>", block, re.S)
    if hint:
        _, h_indent = _newline_and_indent(block, "PathHint")
        folders = [p for p in fwd_path.split("/")[:-1] if p and not p.endswith(":")]
        if use_ids is None:
            use_ids = 'RelativePathElement Id="' in block
        ids = (lambda i: f' Id="{i}"') if use_ids else (lambda i: "")
        inner = "".join(f'{nl}{h_indent}\t<RelativePathElement{ids(i)} Dir="{html.escape(d, quote=True)}" />'
                        for i, d in enumerate(folders)) + nl + h_indent
        block = block[:hint.start(1)] + inner + block[hint.end(1):]
    return block


def _do_rebuilds(als: Path, mapping: dict, result: FixResult, dry_run: bool) -> dict[str, str]:
    """Recreate lost crops (Rebuild entries) and return a plain old-path -> new-path mapping."""
    from .fingerprint import rebuild_crop, rebuild_reverse, same_file
    plain = {k: v for k, v in mapping.items() if isinstance(v, str)}
    jobs = {k: v for k, v in mapping.items() if isinstance(v, Rebuild)}
    if not jobs:
        return plain
    recorded = {norm(s.path): (s.size, s.crc) for s in read_als(als).samples}
    for key, job in jobs.items():
        size, crc = recorded.get(key, (None, None))
        if not size:
            result.notes.append(f"{job.target.name}: project has no size for it, not rebuilt")
            continue
        target = job.target
        if target.exists() and not same_file(str(target), size, crc):
            target = target.with_name(f"{target.stem} (rebuilt){target.suffix}")
        if not (target.exists() and same_file(str(target), size, crc)) and not dry_run:
            err = (rebuild_reverse(job.source, str(target), size, crc) if job.reverse
                   else rebuild_crop(job.source, job.start, job.frames, str(target), size, crc))
            if err:
                result.notes.append(f"{job.target.name}: {err}, not rebuilt")
                continue
        result.rebuilt.append(str(target))
        plain[key] = str(target)
    return plain


def fix_project(als_path: str, mapping: dict, replace: bool = False,
                dry_run: bool = False) -> FixResult:
    als = Path(als_path)
    result = FixResult(project=als.stem)
    out = output_path(als)
    if not als.exists():
        result.skipped = "project file not found"
        return result
    if als.stem.endswith(SUFFIX) or als.stem.endswith(" (swapped)"):
        result.skipped = "already a copy made by Project Vault"
        return result
    if out.exists() and not replace:
        result.skipped = f"{out.name} already exists (use --replace to overwrite it)"
        return result

    raw = gzip.open(als, "rb").read()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        result.skipped = "project is not UTF-8 XML"
        return result
    mapping = _do_rebuilds(als, mapping, result, dry_run)

    done: set[str] = set()
    list_ids = uses_list_ids(text)

    def repl(m: re.Match) -> str:
        block = m.group(0)
        try:
            el = ET.fromstring(block)
        except ET.ParseError:
            return block
        # Same path logic the scanner used, so keys match the report exactly.
        old, _ = resolve_file_ref(el, als.parent)
        key = norm(old)
        new = mapping.get(key)
        if not new:
            return block
        rewritten = _rewrite_block(block, new, list_ids)
        if rewritten is None:
            result.unchanged_refs.append(old)
            return block
        result.relinked += 1
        done.add(key)
        return rewritten

    new_text = FILEREF_RE.sub(repl, text)
    result.samples = len(done)
    if not result.relinked:
        result.skipped = "no confident matches to apply"
        return result

    # Safety checks before anything is written: still valid XML, list members carry Ids where
    # Live expects them, same number of sample references, and every relinked sample now
    # points at its new location.
    if list_ids and re.search(r"<RelativePathElement (?!Id=)", new_text):
        result.skipped = "internal check failed (list member without Id), nothing written"
        return result
    try:
        ET.fromstring(new_text.encode("utf-8"))
    except ET.ParseError as e:
        result.skipped = f"internal check failed, nothing written ({e})"
        return result
    if len(FILEREF_RE.findall(new_text)) != len(FILEREF_RE.findall(text)):
        result.skipped = "internal check failed (sample reference count changed), nothing written"
        return result

    result.output = str(out)
    if dry_run:
        return result

    # The copy lives in Relinked\: pin every sample that exists to its full location so
    # references relative to the original's folder keep working.
    from .layout import anchor_refs, check_xml
    new_text, _ = anchor_refs(new_text, als.parent)
    try:
        check_xml(new_text)
    except (ValueError, ET.ParseError) as e:
        result.output, result.skipped = "", f"internal check failed, nothing written ({e})"
        return result
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + ".tmp")
    tmp.write_bytes(gzip.compress(new_text.encode("utf-8")))
    try:
        ET.fromstring(new_text.encode("utf-8"))
        check = {norm(s.path) for s in read_als(tmp).samples}
        expected = {norm(mapping[k]) for k in done}
        if not expected <= check:
            raise ValueError("relinked paths did not read back correctly")
    except Exception as e:
        tmp.unlink(missing_ok=True)
        result.output, result.skipped = "", f"internal check failed, nothing written ({e})"
        return result
    from .safe_io import move_into_place
    err = move_into_place(tmp, out)
    if err:
        result.output, result.skipped = "", err
    return result
