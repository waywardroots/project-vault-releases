"""Samples you've accepted as gone for good.

Kept in a small text file next to the database (one sample path per line), so it survives
database rebuilds. relink still searches for these every run, so one that turns up later
(a new drive, a backup) is found and reported; it just stops cluttering the summary."""
from __future__ import annotations

from pathlib import Path

from .database import norm


def lost_file(db_path: str) -> Path:
    return Path(db_path).parent / "lost_samples.txt"


def load(db_path: str) -> set[str]:
    f = lost_file(db_path)
    if not f.exists():
        return set()
    return {line.strip() for line in f.read_text(encoding="utf-8").splitlines() if line.strip()}


def save(db_path: str, paths: set[str]) -> None:
    f = lost_file(db_path)
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text("".join(p + "\n" for p in sorted(paths)), encoding="utf-8")
    tmp.replace(f)


def key(path: str) -> str:
    return norm(path)
