"""Moving a finished file into place on Windows, where a file that is open somewhere
(Live, a preview pane, antivirus, OneDrive) can't be replaced for a moment or at all."""
from __future__ import annotations

import os
import time
from pathlib import Path

IN_USE = ("couldn't replace it: the file is open in another program "
          "(close it in Live or wherever it's open, then run this again)")


def move_into_place(tmp: Path | str, target: Path | str, tries: int = 6) -> str:
    """Replace target with tmp. Returns "" on success, else why it couldn't (tmp is removed).
    Retries briefly first: antivirus and cloud sync often hold a new file for a second."""
    tmp, target = Path(tmp), Path(target)
    for attempt in range(tries):
        try:
            os.replace(tmp, target)
            return ""
        except PermissionError:
            if attempt + 1 < tries:
                time.sleep(0.5 * (attempt + 1))
        except OSError as e:
            tmp.unlink(missing_ok=True)
            return f"couldn't write it ({e.strerror or e})"
    tmp.unlink(missing_ok=True)
    return IN_USE
