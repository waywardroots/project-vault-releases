"""Read Ableton Live Set (.als) files.

An .als file is gzip-compressed XML. This module never writes to it.
Supports the Live 10 sample-path layout (RelativePathElement + Name) and the
Live 11/12 layout (a single <Path Value="..."/>).
"""
from __future__ import annotations

import gzip
import os
import posixpath
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

TRACK_TAGS = {
    "MidiTrack": "midi",
    "AudioTrack": "audio",
    "GroupTrack": "group",
    "ReturnTrack": "return",
}

# Rack containers are listed as devices but also hold child devices.
RACK_TAGS = {
    "InstrumentGroupDevice",
    "AudioEffectGroupDevice",
    "MidiEffectGroupDevice",
    "DrumGroupDevice",
}


@dataclass
class SampleUse:
    path: str  # best available full path, forward slashes
    file_name: str
    track_name: str
    location: str  # "clip" or "device"
    rel_path: str = ""  # path relative to the project folder, if Live stored one
    count: int = 1  # how many clips/zones on this track use the sample
    size: int | None = None  # original file size in bytes, when Live recorded it
    crc: int | None = None  # Live's fingerprint of the file's first 16 KB (see fingerprint.py)


@dataclass
class PluginUse:
    name: str
    fmt: str  # "VST2", "VST3", "AU"
    track_name: str
    file: str = ""  # VST2: the .dll path Live loaded it from


@dataclass
class TrackInfo:
    track_id: str
    kind: str
    name: str
    devices: list[str] = field(default_factory=list)


@dataclass
class LiveSet:
    path: str
    live_version: str
    tempo: float | None
    tracks: list[TrackInfo] = field(default_factory=list)
    samples: list[SampleUse] = field(default_factory=list)
    plugins: list[PluginUse] = field(default_factory=list)


def _val(el: ET.Element | None, child: str) -> str | None:
    """Value attribute of a direct or nested child, e.g. _val(track, 'Name/EffectiveName')."""
    if el is None:
        return None
    node = el.find(child)
    return node.get("Value") if node is not None else None


def load_xml(als_path: str | os.PathLike) -> ET.Element:
    with gzip.open(als_path, "rb") as f:
        return ET.parse(f).getroot()


def _decode_windows_data(hex_data: str) -> str | None:
    """Live 9/10 on Windows stores the absolute path as hex UTF-16LE in <Data>."""
    try:
        raw = bytes.fromhex("".join(hex_data.split()))
        text = raw.decode("utf-16-le").split("\x00")[0]
        return text if (":" in text or text.startswith("\\\\")) else None
    except (ValueError, UnicodeDecodeError):
        return None


def _rel_parts(file_ref: ET.Element) -> list[str]:
    """Old-style relative path; Live writes an empty Dir for 'go up one folder'."""
    return [e.get("Dir", "") or ".." for e in file_ref.findall("RelativePath/RelativePathElement")]


def file_size(file_ref: ET.Element) -> int | None:
    """Live 11/12: OriginalFileSize. Live 9/10: SearchHint/FileSize."""
    value = _val(file_ref, "OriginalFileSize") or _val(file_ref, "SearchHint/FileSize")
    try:
        return int(value) if value and int(value) > 0 else None
    except ValueError:
        return None


def file_crc(file_ref: ET.Element) -> int | None:
    """Live 11/12: OriginalCrc. Live 9/10: SearchHint/Crc. Only meaningful with a size."""
    if not file_size(file_ref):
        return None
    value = _val(file_ref, "OriginalCrc") or _val(file_ref, "SearchHint/Crc")
    try:
        return int(value) if value is not None else None
    except ValueError:
        return None


def relative_path(file_ref: ET.Element) -> str:
    """Project-relative path, used to find samples after a project folder moves."""
    rel = _val(file_ref, "RelativePath")  # Live 11/12: single attribute
    if rel:
        return rel.replace("\\", "/")
    parts = _rel_parts(file_ref)
    name = _val(file_ref, "Name")
    return "/".join(parts + [name]) if parts and name else ""


def resolve_file_ref(file_ref: ET.Element, project_dir: Path) -> tuple[str, str]:
    """Return (full_path, file_name) for a <FileRef>, newest layout first."""
    # Live 11/12: absolute path stored directly.
    path = _val(file_ref, "Path")
    if path:
        path = path.replace("\\", "/")
        return path, path.rsplit("/", 1)[-1]

    # Live 10 and older.
    name = _val(file_ref, "Name") or ""
    data = file_ref.findtext("Data")
    if data:
        decoded = _decode_windows_data(data)
        if decoded:
            decoded = decoded.replace("\\", "/")
            return decoded, decoded.rsplit("/", 1)[-1]

    hint = [e.get("Dir", "") for e in file_ref.findall("SearchHint/PathHint/RelativePathElement")]
    if hint and name:
        joined = "/".join(hint + [name])
        # Windows hints start with a drive letter element such as "C:".
        if not hint[0].endswith(":"):
            joined = "/" + joined
        return joined, name

    rel = _rel_parts(file_ref)
    if name:
        full = str(project_dir.joinpath(*rel, name)).replace("\\", "/")
        return posixpath.normpath(full), name  # collapse "folder/.." steps

    return "", name


def _track_name(track: ET.Element, default: str) -> str:
    return _val(track, "Name/UserName") or _val(track, "Name/EffectiveName") or default


def _default_name(kind: str, number: int, return_index: int) -> str:
    if kind == "return":
        return f"{chr(ord('A') + return_index)}-Return"
    return f"{number}-{ {'midi': 'MIDI', 'audio': 'Audio', 'group': 'Group'}[kind] }"


def _tempo(live_set: ET.Element) -> float | None:
    manual = _val(live_set, ".//Tempo/Manual")  # Live 9+
    if manual:
        return float(manual)
    event = live_set.find(".//Tempo/ArrangerAutomation/Events/FloatEvent")  # Live 8
    return float(event.get("Value")) if event is not None else None


def _vst2_file(info: ET.Element) -> str:
    """Where a VST2 plugin was loaded from: <Path> in Live 9+, <Dir><Data> + <FileName> in Live 8."""
    path = _val(info, "Path")
    if path:
        return path.replace("\\", "/")
    file_name = _val(info, "FileName") or ""
    data = info.findtext("Dir/Data")
    folder = _decode_windows_data(data) if data else None
    if folder:
        return (folder.rstrip("\\/") + "/" + file_name).replace("\\", "/")
    return file_name


def _plugin_from_device(device: ET.Element) -> tuple[str, str, str] | None:
    desc = device.find("PluginDesc")
    if desc is None:
        return None
    vst3 = desc.find("Vst3PluginInfo")
    if vst3 is not None:
        return (_val(vst3, "Name") or "(unknown plugin)", "VST3", "")
    vst2 = desc.find("VstPluginInfo")
    if vst2 is not None:
        return (_val(vst2, "PlugName") or "(unknown plugin)", "VST2", _vst2_file(vst2))
    au = desc.find("AuPluginInfo")
    if au is not None:
        return (_val(au, "Name") or "(unknown plugin)", "AU", "")
    return None


def _scan_track(track: ET.Element, track_name: str, project_dir: Path, live: LiveSet, info: TrackInfo) -> None:
    # Devices: children of every <Devices> list on this track (includes racks' inner chains).
    for devices in track.iter("Devices"):
        for device in devices:
            plugin = _plugin_from_device(device) if device.tag in ("PluginDevice", "AuPluginDevice") else None
            if plugin:
                live.plugins.append(PluginUse(plugin[0], plugin[1], track_name, plugin[2]))
                info.devices.append(plugin[0])
            else:
                info.devices.append(device.tag)

    # Samples: every <SampleRef> holds one <FileRef>. Clips live under ClipSlots / Events.
    found: dict[tuple[str, str], SampleUse] = {}
    clip_refs = set()
    for clip in track.iter("AudioClip"):
        for ref in clip.iter("SampleRef"):
            clip_refs.add(id(ref))
    for ref in track.iter("SampleRef"):
        file_ref = ref.find("FileRef")
        if file_ref is None:
            continue
        path, name = resolve_file_ref(file_ref, project_dir)
        if not path and not name:
            continue
        location = "clip" if id(ref) in clip_refs else "device"
        key = (path or name, location)
        if key in found:
            found[key].count += 1
        else:
            found[key] = SampleUse(path, name, track_name, location, relative_path(file_ref),
                                   size=file_size(file_ref), crc=file_crc(file_ref))
    live.samples.extend(found.values())


def read_als(als_path: str | os.PathLike) -> LiveSet:
    als_path = Path(als_path)
    root = load_xml(als_path)
    live_set = root.find("LiveSet")
    if live_set is None:
        raise ValueError("Not an Ableton Live Set (no <LiveSet> element)")

    live = LiveSet(
        path=str(als_path),
        live_version=root.get("Creator", "unknown"),
        tempo=_tempo(live_set),
    )
    project_dir = als_path.parent

    tracks_el = live_set.find("Tracks")
    if tracks_el is not None:
        number = returns = 0
        for track in tracks_el:
            kind = TRACK_TAGS.get(track.tag)
            if not kind:
                continue
            if kind == "return":
                default = _default_name(kind, 0, returns)
                returns += 1
            else:
                number += 1
                default = _default_name(kind, number, 0)
            name = _track_name(track, default)
            info = TrackInfo(track.get("Id", ""), kind, name)
            # Group tracks hold no clips; their children are separate tracks, so no double counting.
            _scan_track(track, name, project_dir, live, info)
            live.tracks.append(info)

    # Master/Main track (renamed MainTrack in Live 12) can hold devices too.
    for tag in ("MainTrack", "MasterTrack"):
        master = live_set.find(tag)
        if master is not None:
            info = TrackInfo(master.get("Id", ""), "main", "Main")
            _scan_track(master, "Main", project_dir, live, info)
            live.tracks.append(info)
            break

    return live
