"""Project Vault on a Mac: the menu-bar icon (the cat, top right) and its own app window.

The same Agent as on Windows keeps versions and serves the page; this file only draws the
Mac parts with AppKit (through PyObjC, bundled with the Mac app):
  - a menu-bar item with the same menu as the Windows tray icon,
  - a real window with the page in it (WebKit), which shows in the Dock while it's open,
  - nothing in the Dock otherwise: Project Vault lives in the menu bar, like Dropbox.

AppKit wants everything drawn from the main thread; other threads hand work over with call_main().
"""
from __future__ import annotations

import threading
from pathlib import Path

# Nothing Mac-only is imported up here: every version's updater test-imports every module, on
# Windows too, so this file must import cleanly anywhere. AppKit loads in _appkit(), on a Mac.
STATIC = Path(__file__).resolve().parent / "gui_static"
_K = None  # the AppKit names, once loaded


def _appkit():
    global _K
    if _K is not None:
        return _K
    import objc
    from AppKit import (NSApplication, NSApplicationActivationPolicyAccessory, NSApplicationActivationPolicyRegular,
                        NSBackingStoreBuffered, NSImage, NSMakeRect, NSMenu, NSMenuItem, NSStatusBar,
                        NSVariableStatusItemLength, NSWindow, NSWindowStyleMaskClosable,
                        NSWindowStyleMaskMiniaturizable, NSWindowStyleMaskResizable, NSWindowStyleMaskTitled)
    from Foundation import NSURL, NSObject, NSSize, NSURLRequest
    from PyObjCTools import AppHelper
    from WebKit import WKWebView, WKWebViewConfiguration

    class PVTarget(NSObject):
        """Receives the menu's clicks, the menu's 'about to open' and the window's 'closing'."""

        def initWithApp_(self, app):
            self = objc.super(PVTarget, self).init()
            if self is None:
                return None
            self.app = app
            return self

        def menuNeedsUpdate_(self, menu):  # rebuilt each time it opens, so it's always current
            self.app.fill_menu(menu)

        def clicked_(self, item):
            self.app.do(str(item.representedObject()))

        def windowWillClose_(self, note):
            self.app.window_closed()

        # links the page opens in a new window go to the browser instead
        def webView_createWebViewWithConfiguration_forNavigationAction_windowFeatures_(self, view, config,
                                                                                        action, feats):
            url = action.request().URL()
            if url is not None:
                from .macos import open_url
                open_url(str(url.absoluteString()))
            return None

    _K = dict(locals())
    return _K


def call_main(fn, *args) -> None:
    """Run fn on the main thread (where AppKit lives), from any thread."""
    _appkit()["AppHelper"].callAfter(fn, *args)


class MacApp:
    """Same shape as the Windows TrayIcon: show, hide, set_tip, close, loop; plus the window."""

    def __init__(self, agent):
        k = self.k = _appkit()
        NSApplication, NSStatusBar, NSImage, NSMenu = k["NSApplication"], k["NSStatusBar"], k["NSImage"], k["NSMenu"]
        NSApplicationActivationPolicyAccessory = k["NSApplicationActivationPolicyAccessory"]
        NSVariableStatusItemLength, NSSize = k["NSVariableStatusItemLength"], k["NSSize"]
        self.agent = agent
        self.nsapp = NSApplication.sharedApplication()
        self.nsapp.setActivationPolicy_(NSApplicationActivationPolicyAccessory)
        self.target = k["PVTarget"].alloc().initWithApp_(self)
        self.item = NSStatusBar.systemStatusBar().statusItemWithLength_(NSVariableStatusItemLength)
        img = NSImage.alloc().initWithContentsOfFile_(str(STATIC / "logo.png"))
        if img is not None:
            img.setSize_(NSSize(18, 18))
            self.item.button().setImage_(img)
        else:
            self.item.button().setTitle_("PV")
        self.menu = NSMenu.alloc().init()
        self.menu.setDelegate_(self.target)
        self.menu.setAutoenablesItems_(False)
        self.item.setMenu_(self.menu)
        self.window = None
        self.web = None

    # -- the menu (same items as on Windows)
    def fill_menu(self, menu) -> None:
        from .gui import live_window_set
        from .history import startup_mode
        NSMenuItem, NSMenu = self.k["NSMenuItem"], self.k["NSMenu"]
        a = self.agent
        menu.removeAllItems()

        def add(title, cmd, enabled=True, checked=False, to=menu):
            it = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, "clicked:", "")
            it.setTarget_(self.target)
            it.setRepresentedObject_(cmd)
            it.setEnabled_(enabled)
            it.setState_(1 if checked else 0)
            to.addItem_(it)
            return it

        live = live_window_set()
        add("Open Project Vault", "open")
        label = (f"Keep a version of “{live[:38]}” now" if live and live.lower() != "untitled"
                 else "Keep a version of the song in Live now")
        add(label, "keep", enabled=bool(live))
        try:
            from .backup import load
            has_backup = bool(load(a.data)["destinations"])
        except Exception:
            has_backup = False
        add("Back up now", "backup", enabled=has_backup)
        menu.addItem_(NSMenuItem.separatorItem())
        add("Keep a version of every save", "pause", checked=not a.paused)
        sub = NSMenu.alloc().init()
        sub.setAutoenablesItems_(False)
        mode = startup_mode()
        add("When I log in to my Mac", "start_windows", checked=mode == "windows", to=sub)
        add("When I open Ableton Live", "start_live", checked=mode == "live", to=sub)
        add("Only when I open it", "start_off", checked=mode == "off", to=sub)
        parent = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Start Project Vault", None, "")
        parent.setSubmenu_(sub)
        menu.addItem_(parent)
        menu.addItem_(NSMenuItem.separatorItem())
        add("Quit Project Vault", "quit")

    def do(self, cmd: str) -> None:
        a = self.agent
        if cmd == "open":
            a.open_window()
        elif cmd == "keep":
            threading.Thread(target=a.keep_live_version, daemon=True).start()
        elif cmd == "backup" and a.app:
            try:
                a.app.start_job("backup", ["run"])
            except ValueError:
                pass
        elif cmd == "pause":
            a.set_paused(not a.paused)
        elif cmd in ("start_windows", "start_live", "start_off"):
            a.set_startup({"start_windows": "windows", "start_live": "live"}.get(cmd, "off"))
        elif cmd == "quit":
            threading.Thread(target=a.quit, args=("you chose Quit from the menu bar",), daemon=True).start()

    # -- the window
    def open_window(self, url: str) -> None:
        call_main(self._open_window, url)

    def _open_window(self, url: str) -> None:
        k = self.k
        NSWindow, NSMakeRect, NSSize, NSBackingStoreBuffered = k["NSWindow"], k["NSMakeRect"], k["NSSize"], k["NSBackingStoreBuffered"]
        NSWindowStyleMaskTitled, NSWindowStyleMaskClosable = k["NSWindowStyleMaskTitled"], k["NSWindowStyleMaskClosable"]
        NSWindowStyleMaskMiniaturizable = k["NSWindowStyleMaskMiniaturizable"]
        NSWindowStyleMaskResizable = k["NSWindowStyleMaskResizable"]
        WKWebView, WKWebViewConfiguration = k["WKWebView"], k["WKWebViewConfiguration"]
        NSURLRequest, NSURL = k["NSURLRequest"], k["NSURL"]
        if self.window is None:
            style = (NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable
                     | NSWindowStyleMaskResizable)
            w = NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(
                NSMakeRect(0, 0, 1360, 880), style, NSBackingStoreBuffered, False)
            w.setTitle_("Project Vault")
            w.setReleasedWhenClosed_(False)
            w.setMinSize_(NSSize(980, 640))
            w.setDelegate_(self.target)
            w.setFrameAutosaveName_("ProjectVaultMain")  # remembers where you put it
            if not w.setFrameUsingName_("ProjectVaultMain"):
                w.center()
            config = WKWebViewConfiguration.alloc().init()
            web = WKWebView.alloc().initWithFrame_configuration_(w.contentView().bounds(), config)
            web.setAutoresizingMask_(18)  # width and height follow the window
            web.setUIDelegate_(self.target)
            w.contentView().addSubview_(web)
            self.window, self.web = w, web
            self.web.loadRequest_(NSURLRequest.requestWithURL_(NSURL.URLWithString_(url)))
        # a window of its own shows in the Dock and the app switcher while it's open
        self.nsapp.setActivationPolicy_(k["NSApplicationActivationPolicyRegular"])
        self.window.makeKeyAndOrderFront_(None)
        self.nsapp.activateIgnoringOtherApps_(True)

    def window_closed(self) -> None:
        # back to living in the menu bar only; the page keeps its place for next time
        self.nsapp.setActivationPolicy_(self.k["NSApplicationActivationPolicyAccessory"])

    # -- the menu-bar item
    def show(self) -> None:
        call_main(self.item.setVisible_, True)

    def hide(self) -> None:
        call_main(self.item.setVisible_, False)

    def set_tip(self, text: str) -> None:
        call_main(self.item.button().setToolTip_, text)

    def close(self) -> None:
        call_main(self.k["AppHelper"].stopEventLoop)

    def loop(self, visible: bool = True) -> None:
        self.item.setVisible_(bool(visible))
        self.k["AppHelper"].runEventLoop(installInterrupt=True)
