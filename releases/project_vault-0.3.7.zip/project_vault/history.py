"""Version history: a snapshot of a project every time it's saved, what changed, and restore.

Snapshots live next to the database (history\\<project>\\), one compressed .als per version, the
same bytes Live wrote. A version identical to the one before is not kept twice. Live's own
Backup folder (the last 10 saves Live keeps) is imported too, so projects start with history.
Restoring never overwrites anything: it writes "<song> (restored <date>).als" next to the song,
so its samples resolve exactly as the song's do.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import sys
import re
import shutil
import time
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .database import norm

KEEP = 100  # versions kept per project (the oldest go first)
SKIP_DIRS = {"backup", "relinked", "swapped", "__macosx", "history", "project vault"}
BACKUP_RE = re.compile(r"^(?P<stem>.+) \[(?P<d>\d{4}-\d{2}-\d{2}) (?P<t>\d{6})\]\.als$", re.I)
STAMP = "%Y%m%d-%H%M%S"


def history_root(db_path: str | os.PathLike) -> Path:
    return Path(db_path).parent / "history"


def project_dir(root: Path, als: str | os.PathLike) -> Path:
    """The song's folder in the history store, found by the id in its sidecar, so a song keeps
    its history when it (or its whole project folder) is moved or renamed."""
    from .sidecar import song_id
    key = song_id(als)
    for d in root.glob(f"*-{key}") if root.is_dir() else []:
        if d.is_dir():
            return d
    return root / f"{_safe(Path(als).stem)[:60]}-{key}"


def _safe(s: str) -> str:
    return re.sub(r'[<>:"/\\|?*]', "_", s)


def _content_hash(data: bytes) -> str | None:
    """Hash of the set's XML, or None if the file isn't a complete .als (Live still writing it)."""
    try:
        return hashlib.sha1(gzip.decompress(data)).hexdigest()[:12]
    except (OSError, EOFError, ValueError):
        return None


@dataclass
class Version:
    when: datetime
    path: Path
    source: str  # "saved" or "Live backup"

    @property
    def label(self) -> str:
        return self.when.strftime("%Y-%m-%d %H:%M")

    @property
    def key(self) -> str:
        """What labels are stored under (the snapshot's name, unique per version)."""
        return self.path.stem.removesuffix("_b")


def versions(root: Path, als: str | os.PathLike) -> list[Version]:
    d = project_dir(root, als)
    out = []
    for f in sorted(d.glob("*.als")) if d.is_dir() else []:
        m = re.match(r"(\d{8}-\d{6})_[0-9a-f]+(_b)?\.als$", f.name)
        if m:
            out.append(Version(datetime.strptime(m.group(1), STAMP), f, "Live backup" if m.group(2) else "saved"))
    return out


def snapshot(root: Path, als: str | os.PathLike, when: float | None = None, from_backup: bool = False,
             keep: int = KEEP) -> Path | None:
    """Keep a copy of this version of the project. None if unchanged or not readable yet."""
    src = Path(als if not from_backup else als)
    try:
        data = src.read_bytes()
    except OSError:
        return None
    h = _content_hash(data)
    if h is None:
        return None
    target_project = _project_of_backup(src) if from_backup else src
    from . import sidecar
    if from_backup:
        sidecar.ensure(target_project)
    else:
        sidecar.remember_version(target_project, h)  # also recognises a renamed song by its content
    d = project_dir(root, target_project)
    _write_meta(d, target_project)
    existing = versions(root, target_project)
    if any(v.path.name.split("_")[1].startswith(h) for v in existing):
        return None  # this exact version is already kept
    stamp = datetime.fromtimestamp(when if when is not None else src.stat().st_mtime).strftime(STAMP)
    out = d / f"{stamp}_{h}{'_b' if from_backup else ''}.als"
    tmp = out.with_suffix(".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, out)
    for old in versions(root, target_project)[:-keep]:
        old.path.unlink(missing_ok=True)
        old.path.with_suffix(".summary.json").unlink(missing_ok=True)
    return out


def _write_meta(d: Path, als: Path) -> None:
    """project.json: where the song is now (updated when it moves) and its labels."""
    meta = d / "project.json"
    try:
        info = json.loads(meta.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        info = {}
    if info.get("path") != str(als) or info.get("name") != als.stem:
        if info.get("path") and info["path"] != str(als):
            info.setdefault("was", []).append(info["path"])
        info.update(path=str(als), name=als.stem)
        d.mkdir(parents=True, exist_ok=True)
        meta.write_text(json.dumps(info, indent=1, ensure_ascii=False), encoding="utf-8")


def labels(root: Path, als: str | os.PathLike) -> dict[str, str]:
    """Version labels ({version key: text}), from the sidecar and the history store."""
    from .sidecar import read
    try:
        info = json.loads((project_dir(root, als) / "project.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        info = {}
    return {**info.get("labels", {}), **((read(als) or {}).get("labels", {}))}


def set_label(root: Path, als: str | os.PathLike, v: Version, text: str) -> None:
    """Name a version ("sent to label", "club mix"). Empty text removes the label. Kept in both
    the sidecar (travels with the project) and the history store (in case the project folder
    can't be written)."""
    from . import sidecar
    sidecar.set_label(als, v.key, text)
    d = project_dir(root, als)
    meta = d / "project.json"
    try:
        info = json.loads(meta.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        info = {"path": str(als), "name": Path(als).stem}
    lab = info.setdefault("labels", {})
    if text:
        lab[v.key] = text
    else:
        lab.pop(v.key, None)
    d.mkdir(parents=True, exist_ok=True)
    meta.write_text(json.dumps(info, indent=1, ensure_ascii=False), encoding="utf-8")


def _project_of_backup(backup: Path) -> Path:
    m = BACKUP_RE.match(backup.name)
    stem = m.group("stem") if m else backup.stem
    return backup.parent.parent / f"{stem}.als"


def import_live_backups(root: Path, als: str | os.PathLike) -> int:
    """Add the saves Live keeps in the project's Backup folder. Returns how many were new."""
    als = Path(als)
    bdir = als.parent / "Backup"
    n = 0
    if bdir.is_dir():
        for f in bdir.iterdir():
            m = BACKUP_RE.match(f.name)
            if m and m.group("stem").lower() == als.stem.lower():
                when = datetime.strptime(m.group("d") + m.group("t"), "%Y-%m-%d%H%M%S").timestamp()
                if snapshot(root, f, when=when, from_backup=True):
                    n += 1
    return n


def iter_projects(folder: Path):
    for dirpath, dirnames, filenames in os.walk(folder):
        dirnames[:] = [d for d in dirnames if d.lower() not in SKIP_DIRS]
        for f in filenames:
            if f.lower().endswith(".als") and not f.startswith("._"):
                yield Path(dirpath) / f


def find(root: Path, text: str) -> list[tuple[str, Path]]:
    """Projects with history whose name or path contains text -> [(project path, history dir)]."""
    out = []
    t = text.lower()
    for meta in root.glob("*/project.json"):
        info = json.loads(meta.read_text(encoding="utf-8"))
        if t in info["name"].lower() or t == info["path"].lower():
            out.append((info["path"], meta.parent))
    return sorted(out)


# ---------------------------------------------------------------- what changed

@dataclass
class Summary:
    tempo: float | None
    tracks: dict  # track id -> (name, kind, tuple(devices), clips, notes)
    plugins: Counter
    samples: set


def cached_summary(path: str | os.PathLike) -> Summary:
    """summarize() for a kept version, saved beside it (versions never change, so it's read once)."""
    path = Path(path)
    cache = path.with_suffix(".summary.json")
    try:
        d = json.loads(cache.read_text(encoding="utf-8"))
        return Summary(d["tempo"], {k: (v[0], v[1], tuple(v[2]), v[3], v[4]) for k, v in d["tracks"].items()},
                       Counter(d["plugins"]), set(d["samples"]))
    except (OSError, ValueError, KeyError, TypeError, IndexError):
        pass
    s = summarize(path)
    try:
        tmp = cache.with_suffix(".tmp")
        tmp.write_text(json.dumps({"tempo": s.tempo, "tracks": {k: list(v) for k, v in s.tracks.items()},
                                   "plugins": dict(s.plugins), "samples": sorted(s.samples)}), encoding="utf-8")
        os.replace(tmp, cache)
    except (OSError, TypeError):
        pass
    return s


def summarize(path: str | os.PathLike) -> Summary:
    from .als_reader import load_xml, read_als
    live = read_als(path)
    counts = {}
    tracks_el = load_xml(path).find("LiveSet/Tracks")
    for tr in tracks_el if tracks_el is not None else []:
        clips = sum(1 for _ in tr.iter("MidiClip")) + sum(1 for _ in tr.iter("AudioClip"))
        counts[tr.get("Id", "")] = (clips, sum(1 for _ in tr.iter("MidiNoteEvent")))
    tracks = {t.track_id or t.name: (t.name, t.kind, tuple(t.devices), *counts.get(t.track_id, (0, 0)))
              for t in live.tracks}
    return Summary(live.tempo, tracks, Counter(f"{p.name} [{p.fmt}]" for p in live.plugins),
                   {s.file_name for s in live.samples})


def changes(a: Summary, b: Summary) -> list[str]:
    """What changed from version a to version b, in plain words."""
    out = []
    if a.tempo and b.tempo and abs(a.tempo - b.tempo) > 0.001:
        out.append(f"tempo {a.tempo:g} -> {b.tempo:g} BPM")
    for verb, names in (("added", Counter(b.tracks[t][0] for t in b.tracks.keys() - a.tracks.keys())),
                        ("removed", Counter(a.tracks[t][0] for t in a.tracks.keys() - b.tracks.keys()))):
        for name, n in sorted(names.items()):
            out.append(f"{verb} track '{name}'" + (f" (x{n})" if n > 1 else ""))
    for tid in a.tracks.keys() & b.tracks.keys():
        (n1, _, d1, c1, k1), (n2, _, d2, c2, k2) = a.tracks[tid], b.tracks[tid]
        name = n2
        if _plain(n1) != _plain(n2):  # Live renumbering "23-Audio" to "17-Audio" isn't a rename
            out.append(f"renamed track '{n1}' to '{n2}'")
        added = list((Counter(d2) - Counter(d1)).elements())
        gone = list((Counter(d1) - Counter(d2)).elements())
        if added:
            out.append(f"{name}: added {', '.join(added)}")
        if gone:
            out.append(f"{name}: removed {', '.join(gone)}")
        bits = []
        if c1 != c2:
            bits.append(f"{c2 - c1:+d} clip{'s' if abs(c2 - c1) != 1 else ''}")
        if k1 != k2:
            bits.append(f"{k2 - k1:+d} note{'s' if abs(k2 - k1) != 1 else ''}")
        if bits:
            out.append(f"{name}: {', '.join(bits)}")
    new_s, old_s = sorted(b.samples - a.samples), sorted(a.samples - b.samples)
    if new_s:
        out.append(f"new sample{'s' if len(new_s) > 1 else ''}: {', '.join(new_s[:5])}"
                   + (f" and {len(new_s) - 5} more" if len(new_s) > 5 else ""))
    if old_s:
        out.append(f"sample{'s' if len(old_s) > 1 else ''} no longer used: {', '.join(old_s[:5])}"
                   + (f" and {len(old_s) - 5} more" if len(old_s) > 5 else ""))
    return out


def _plain(track_name: str) -> str:
    return re.sub(r"^\d+-", "", track_name)


def one_line(lines: list[str], limit: int = 110) -> str:
    if not lines:
        return "no musical changes (settings or mix only)"
    s = "; ".join(lines)
    if len(s) <= limit:
        return s
    def count(prefix):
        return sum(1 for l in lines if l.startswith(prefix))
    edited = len({l.split(":", 1)[0] for l in lines if ": " in l and not l.startswith(("new sample", "sample"))})
    parts = [f"tempo {l.split('tempo ', 1)[1]}" for l in lines if l.startswith("tempo ")]
    parts += [f"{n} {what}" if n != 1 else f"1 {one}"
              for n, what, one in ((count("added track"), "tracks added", "track added"),
                                   (count("removed track"), "tracks removed", "track removed"),
                                   (count("renamed track"), "renamed", "renamed"),
                                   (edited, "tracks edited", "track edited")) if n]
    new_s = next((l for l in lines if l.startswith("new sample")), "")
    if new_s:
        n = len(new_s.split(": ", 1)[1].split(", ")) + int((re.search(r"and (\d+) more", new_s) or [0, 0])[1])
        parts.append(f"{n} new sample{'s' if n > 1 else ''}")
    return ", ".join(parts)


def collect_sounds(root: Path, als: str | os.PathLike) -> int:
    """Add the song's plugin sounds to the plugin library. Never stops the caller."""
    from . import library, sidecar
    try:
        return library.collect(root.parent / "plugin_library", als, sidecar.song_id(als), Path(als).stem)
    except Exception:  # a sound that can't be read must never stop history being kept
        return 0


def restore(v: Version, project: str | os.PathLike) -> Path:
    """Write the version next to the project as a new set. Never overwrites."""
    project = Path(project)
    base = f"{project.stem} (restored {v.when.strftime('%Y-%m-%d %H%M')})"
    out = project.parent / f"{base}.als"
    n = 2
    while out.exists():
        out = project.parent / f"{base} {n}.als"
        n += 1
    shutil.copyfile(v.path, out)
    return out


# ---------------------------------------------------------------- watching

def watch(root: Path, folders: list[Path], every: float = 10.0, out=print, rounds: int | None = None,
          settle: float = 2.0) -> None:
    """Snapshot a project each time it's saved. Runs until Ctrl+C (or `rounds`, for tests)."""
    seen: dict[str, tuple[float, int]] = {}
    pending: dict[str, float] = {}
    first = True
    n = 0
    while rounds is None or n < rounds:
        n += 1
        now = time.time()
        for folder in folders:
            for als in iter_projects(folder):
                try:
                    st = als.stat()
                except OSError:
                    continue
                key, sig = str(als), (st.st_mtime, st.st_size)
                if first:
                    seen[key] = sig
                    continue
                if seen.get(key) != sig:
                    seen[key] = sig
                    pending[key] = now
        for key, since in list(pending.items()):
            if now - since >= settle:  # wait until Live has finished writing
                kept = snapshot(root, key)
                if kept:
                    import_live_backups(root, key)
                    n_new = collect_sounds(root, key)
                    from .backup import after_snapshot
                    backed = after_snapshot(root.parent, kept, Path(key), folders)
                    out(f"{time.strftime('%H:%M:%S')}  saved a version of {Path(key).stem}"
                        + (f" ({n_new} plugin sound{'s' if n_new != 1 else ''} added to the library)"
                           if n_new else "") + (" (backed up)" if backed else ""))
                    pending.pop(key)
                elif not Path(key).exists() or _content_hash(Path(key).read_bytes()) is not None:
                    pending.pop(key)  # unchanged or gone; a half-written file is retried
        first = False
        if stop_requested(root):
            out(f"{time.strftime('%H:%M:%S')}  stopped (autostart turned off)")
            return
        if rounds is None or n < rounds:
            end = time.time() + every
            while time.time() < end:  # sleep, but stop promptly when asked
                time.sleep(min(0.5, max(0.0, end - time.time())))
                if stop_requested(root):
                    out(f"{time.strftime('%H:%M:%S')}  stopped")
                    return


# ---------------------------------------------------------------- running in the background

STARTUP_NAME = "Project Vault.vbs"
OLD_STARTUP_NAMES = ("Project Vault history.vbs",)  # earlier versions started only the watcher


def startup_script() -> Path:
    """Windows runs everything in this folder at log-in; a Mac runs its LaunchAgents."""
    if sys.platform == "darwin":
        from .macos import launch_agent_path
        return launch_agent_path()
    return (Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
            / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / STARTUP_NAME)


def _stop_file(root: Path) -> Path:
    return root / "watch.stop"


def stop_requested(root: Path) -> bool:
    return _stop_file(root).exists()


class AlreadyRunning(Exception):
    pass


class WatchLock:
    """Only one watcher at a time: a lock on history\\watch.lock, released when it exits.
    (Also used for the background app's own lock, with another name.)"""

    def __init__(self, root: Path, name: str = "watch.lock"):
        root.mkdir(parents=True, exist_ok=True)
        self.f = open(root / name, "a+")
        try:
            if os.name == "nt":
                import msvcrt
                self.f.seek(0)
                msvcrt.locking(self.f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.f.close()
            raise AlreadyRunning()

    def release(self) -> None:
        try:
            self.f.close()
        except OSError:
            pass


def is_running(root: Path) -> bool:
    try:
        WatchLock(root).release()
        return False
    except AlreadyRunning:
        return True


def _pythonw() -> str:
    import sys
    w = Path(sys.executable).with_name("pythonw.exe")
    return str(w if w.exists() else sys.executable)


def watch_command(db_path: str, folders: list[Path], mode: str = "windows") -> list[str]:
    """The background app (tray icon + watcher), as started at log-in."""
    return [_pythonw(), "-m", "project_vault", "--db", str(db_path), "tray", "--when", mode,
            "--watch", *[str(f) for f in folders]]


def _remove_old_launchers() -> None:
    if sys.platform == "darwin":
        return
    for name in OLD_STARTUP_NAMES:
        startup_script().with_name(name).unlink(missing_ok=True)


def startup_mode() -> str:
    """'windows' (at log-in, on a Mac too), 'live' (start when Ableton Live opens) or 'off'."""
    if sys.platform == "darwin":
        from .macos import launch_agent_args
        args = launch_agent_args()
        if args is None:
            return "off"
        return args[args.index("--when") + 1] if "--when" in args[:-1] else "windows"
    try:
        text = startup_script().read_text(encoding="utf-8")
    except OSError:
        return "off"
    return "live" if '""--when"" ""live""' in text else "windows"


def write_launcher(db_path: str, folders: list[Path], package_root: Path, mode: str = "windows") -> Path:
    """Start the background app at every log-in ('live': it waits, quietly, until Live opens)."""
    cmd = watch_command(db_path, folders, mode)
    if sys.platform == "darwin":
        from .macos import write_launch_agent
        return write_launch_agent(cmd, str(package_root))
    quoted = " ".join(f'""{c}""' for c in cmd)
    vbs = ('Set sh = CreateObject("WScript.Shell")\r\n'
           f'sh.CurrentDirectory = "{package_root}"\r\n'
           f'sh.Run "{quoted}", 0, False\r\n')
    target = startup_script()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(vbs, encoding="utf-8")
    _remove_old_launchers()
    return target


def _stop_old_watcher(root: Path) -> None:
    """An earlier version's watcher (its own process): ask it to stop and wait for it."""
    if not is_running(root):
        return
    _stop_file(root).write_text("stop", encoding="utf-8")
    for _ in range(40):
        if not is_running(root):
            break
        time.sleep(0.5)
    _stop_file(root).unlink(missing_ok=True)


def enable_autostart(db_path: str, folders: list[Path], package_root: Path, start_now: bool = True,
                     mode: str = "windows") -> Path:
    """Start Project Vault in the background at every log-in (and now). Returns the launcher."""
    import subprocess
    from .tray import agent_running
    target = write_launcher(db_path, folders, package_root, mode)
    root = history_root(db_path)
    data = Path(db_path).resolve().parent
    if not agent_running(data):
        _stop_old_watcher(root)
    _stop_file(root).unlink(missing_ok=True)
    (data / "agent.quit").unlink(missing_ok=True)
    if start_now and not agent_running(data):
        flags = 0x00000008 | 0x08000000 if os.name == "nt" else 0  # DETACHED_PROCESS | CREATE_NO_WINDOW
        subprocess.Popen(watch_command(db_path, folders, mode), cwd=str(package_root), creationflags=flags,
                         close_fds=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return target


def disable_autostart(db_path: str) -> bool:
    """Don't start at log-in any more, and close the background app. True if it was on."""
    target = startup_script()
    was_on = target.exists() or any(target.with_name(n).exists() for n in OLD_STARTUP_NAMES)
    target.unlink(missing_ok=True)
    _remove_old_launchers()
    root = history_root(db_path)
    data = Path(db_path).resolve().parent
    from .tray import agent_running
    if agent_running(data):
        (data / "agent.quit").write_text("quit", encoding="utf-8")
    elif is_running(root):
        root.mkdir(parents=True, exist_ok=True)
        _stop_file(root).write_text("stop", encoding="utf-8")
    return was_on
