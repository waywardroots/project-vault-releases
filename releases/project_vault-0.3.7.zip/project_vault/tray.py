"""Project Vault in the background: an icon in the taskbar's hidden icons.

    python -m project_vault tray [--when windows|live] [--watch FOLDER ...] [--open]

One process does it all: keeps a version of every save (the history watcher, which also backs
each version up), serves the Project Vault window (opened from the icon), and stays out of the way.
Click the icon to open Project Vault; right-click for quick actions.

--when live: start quietly and wait. Nothing shows until Ableton Live opens; then the icon
appears and saves are kept. When Live closes, the icon goes away again.

The icon uses Windows' own notification-area functions (no extra installs). On a Mac it's a
menu-bar icon with a window of its own (mac_app.py). Elsewhere the same thing runs without an icon
(used by the tests).
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from . import __version__

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
ICON = Path(__file__).with_name("gui_static") / "icon.ico"
AGENT_LOCK = "agent.lock"


def agent_running(data_dir: Path) -> bool:
    from .history import AlreadyRunning, WatchLock
    try:
        WatchLock(Path(data_dir), AGENT_LOCK).release()
        return False
    except AlreadyRunning:
        return True


def launch(db_path: str, open_window: bool = False, mode: str = "windows", folders: list[str] | None = None) -> None:
    """Start the background app in its own hidden process."""
    from .history import _pythonw
    cmd = [_pythonw(), "-m", "project_vault", "--db", str(db_path), "tray", "--when", mode]
    if open_window:
        cmd.append("--open")
    if folders:
        cmd += ["--watch", *folders]
    flags = 0x00000008 | 0x08000000 if os.name == "nt" else 0  # DETACHED_PROCESS | CREATE_NO_WINDOW
    subprocess.Popen(cmd, cwd=str(PACKAGE_ROOT), creationflags=flags, close_fds=True,
                     start_new_session=os.name != "nt",  # keeps running when the Terminal closes
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def ask_to_open(data_dir: Path) -> None:
    """Ask the running background app to bring up its window (on a Mac the window is its own)."""
    (Path(data_dir) / "agent.open").write_text("open", encoding="utf-8")


class Agent:
    def __init__(self, db_path: str, folders: list[str] | None = None, mode: str = "windows"):
        from .gui import data_dir
        from .history import history_root
        self.db_path = str(Path(db_path).resolve())
        self.data = data_dir(self.db_path)
        self.root = history_root(self.db_path)
        self.arg_folders = [f for f in (folders or []) if f]
        self.mode = mode
        self.watcher: threading.Thread | None = None
        self.watch_lock = None
        self.stopping = False
        self.quit_event = threading.Event()
        self.active = mode != "live"  # 'live' mode waits for Live before showing up
        self.last_kept = ""
        self.last_kept_at = ""
        self.note = ""
        self.icon = None
        self.app = None
        self.url = ""
        self.quit_reason = ""  # set when stopping on purpose; empty = an unexpected stop
        self.started = time.time()

    # -- settings
    def settings(self) -> dict:
        from .gui import load_settings
        return load_settings(self.db_path)

    @property
    def paused(self) -> bool:
        return bool(self.settings().get("history_paused"))

    def folders(self) -> list[Path]:
        from .gui import autostart_folders
        s = self.settings()
        fs = s["project_folders"] or self.arg_folders or autostart_folders()
        if not fs and self.app:
            d = self.app.default_project_folder()
            fs = [d] if d else []
        return [Path(f) for f in fs if Path(f).is_dir()]

    # -- the watcher
    def watching(self) -> bool:
        return bool(self.watcher and self.watcher.is_alive())

    def log(self, line: str) -> None:
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            with (self.root / "watch.log").open("a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%Y-%m-%d')} {line}\n")
        except OSError:
            pass
        if "saved a version of" in line:
            self.last_kept = line.split("saved a version of", 1)[1].split(" (", 1)[0].strip()
            self.last_kept_at = time.strftime("%H:%M")
        self.update_tip()

    def start_watcher(self) -> None:
        from .history import AlreadyRunning, WatchLock, _stop_file, watch
        if self.watching() or self.paused or not self.active or self.stopping:
            return
        folders = self.folders()
        if not folders:
            self.note = "choose your projects folder in Settings"
            self.update_tip()
            return
        try:
            self.watch_lock = WatchLock(self.root)
        except AlreadyRunning:
            self.note = "another copy is already keeping versions"
            self.update_tip()
            return
        _stop_file(self.root).unlink(missing_ok=True)
        self.note = ""

        def run():
            try:
                self.log(f"{time.strftime('%H:%M:%S')}  watching {', '.join(str(f) for f in folders)}")
                watch(self.root, folders, out=self.log)
            except Exception as e:  # never take the app down
                self.log(f"{time.strftime('%H:%M:%S')}  watcher stopped: {type(e).__name__}: {e}")
            finally:
                if self.watch_lock:
                    self.watch_lock.release()
                    self.watch_lock = None
                self.update_tip()
        self.watcher = threading.Thread(target=run, daemon=True, name="watcher")
        self.watcher.start()
        self.update_tip()

    def stop_watcher(self, wait: bool = True) -> None:
        from .history import _stop_file
        if not self.watching():
            return
        self.stopping = True
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            _stop_file(self.root).write_text("stop", encoding="utf-8")
            if wait and self.watcher:
                self.watcher.join(timeout=30)
        finally:
            _stop_file(self.root).unlink(missing_ok=True)
            self.stopping = False
            self.update_tip()

    def set_paused(self, paused: bool) -> None:
        from .gui import load_settings, save_settings
        s = load_settings(self.db_path)
        s["history_paused"] = bool(paused)
        save_settings(self.db_path, s)
        if paused:
            threading.Thread(target=self.stop_watcher, daemon=True).start()
        else:
            self.start_watcher()
        self.update_tip()

    def restart_watcher(self) -> None:
        def go():
            self.stop_watcher()
            self.start_watcher()
        threading.Thread(target=go, daemon=True).start()

    # -- start at log-in
    def set_startup(self, mode: str) -> None:
        from .history import startup_script, write_launcher, _remove_old_launchers
        if mode in ("windows", "live"):
            write_launcher(self.db_path, self.folders(), PACKAGE_ROOT, mode)
        else:
            startup_script().unlink(missing_ok=True)
            _remove_old_launchers()

    # -- the window
    def open_window(self) -> None:
        from .gui import open_window
        if not self.url:
            return
        if hasattr(self.icon, "open_window"):  # the Mac app draws its own window
            self.icon.open_window(self.url)
        else:
            open_window(self.url, self.data / "gui_window")

    def keep_live_version(self) -> str:
        from .gui import live_window_set
        name = live_window_set()
        if not name or not self.app:
            return ""
        path = self.app._find_song(name)
        if path:
            self.app.snapshot(path)
        return name

    def update_tip(self) -> None:
        if not self.icon:
            return
        if self.paused:
            state = "Version history paused"
        elif self.note:
            state = self.note[0].upper() + self.note[1:]
        elif self.watching():
            state = (f"Last kept: {self.last_kept[:40]} at {self.last_kept_at}" if self.last_kept
                     else "Keeping every save")
        else:
            state = "Starting…"
        self.icon.set_tip(f"Project Vault\n{state}")

    # -- control files: lets the command line (and updates) reach the running app
    def housekeeping(self) -> None:
        from .gui import live_window_set
        self.quiet_since = None
        while not self.quit_event.wait(2):
            try:
                if self._housekeeping_round(live_window_set):
                    return
            except Exception as e:  # log it and keep going
                self.log(f"{time.strftime('%H:%M:%S')}  background check failed: {type(e).__name__}: {e}")

    def _housekeeping_round(self, live_window_set) -> bool:
        """One round of checks. True = the app is stopping."""
        if (self.data / "agent.quit").exists():
            (self.data / "agent.quit").unlink(missing_ok=True)
            self.quit("asked to close (installer, uninstaller or history autostart --off)")
            return True
        if (self.data / "agent.open").exists():  # opened again from the Dock, Launchpad or Finder
            (self.data / "agent.open").unlink(missing_ok=True)
            self.active = True
            if self.icon:
                self.icon.show()
            self.open_window()
        if (self.data / "agent.restart").exists():
            (self.data / "agent.restart").unlink(missing_ok=True)
            self.restart()
            return True
        if self.mode == "live":
            open_now = bool(live_window_set())
            if open_now and not self.active:
                self.active = True
                if self.icon:
                    self.icon.show()
                self.quiet_since = None
            elif not open_now and self.active:
                # Live closed: step back once nothing's been asked of the window for a minute
                self.quiet_since = self.quiet_since or time.time()
                idle = time.time() - (self.app.last_seen if self.app else 0) > 60
                if time.time() - self.quiet_since > 30 and idle:
                    self.active = False
                    self.stop_watcher()
                    if self.icon:
                        self.icon.hide()
        if self.active and not self.watching() and not self.paused and not self.stopping:
            self.start_watcher()
        return False

    def quit(self, reason: str = "you chose Quit") -> None:
        """Stop for good (until the next start). Every stop says why in the log."""
        if not self.quit_reason:
            self.quit_reason = reason
            self.log(f"{time.strftime('%H:%M:%S')}  closing: {reason}")
        self.quit_event.set()
        self.stop_watcher(wait=True)
        if self.icon:
            self.icon.close()

    def restart(self) -> None:
        """After an update: start again with the new code."""
        self.quit_reason = "restarting with the new version"
        self.log(f"{time.strftime('%H:%M:%S')}  closing: {self.quit_reason}")
        self.quit_event.set()
        self.stop_watcher(wait=True)
        self._release()
        launch(self.db_path, False, self.mode, [str(f) for f in self.folders()])
        if self.icon:
            self.icon.close()

    def _release(self) -> None:
        lock = getattr(self, "lock", None)
        if lock:
            lock.release()
            self.lock = None

    # -- run
    def run(self, open_window: bool = False, icon: bool = True) -> int:
        from .gui import start_server
        from .history import AlreadyRunning, WatchLock
        try:
            self.lock = WatchLock(self.data, AGENT_LOCK)
        except AlreadyRunning:
            if open_window and sys.platform == "darwin":
                ask_to_open(self.data)
            elif open_window:  # already running: just bring up its window
                from .gui import _running_instance, open_window as ow
                url = _running_instance(self.data / "gui.json")
                if url:
                    ow(url, self.data / "gui_window")
            return 0
        # a quit request left from before this start (the installer asks even when nothing is running)
        (self.data / "agent.quit").unlink(missing_ok=True)
        (self.data / "agent.open").unlink(missing_ok=True)
        server, self.app, self.url = start_server(self.db_path, agent=self)
        try:
            if icon and (os.name == "nt" or sys.platform == "darwin"):
                try:
                    if sys.platform == "darwin":
                        from .mac_app import MacApp
                        self.icon = MacApp(self)
                    else:
                        self.icon = TrayIcon(self)
                except Exception as e:  # no icon: keep working without one, and say why in the log
                    self.icon = None
                    where = "menu-bar icon" if sys.platform == "darwin" else "taskbar icon"
                    self.log(f"{time.strftime('%H:%M:%S')}  couldn't show the {where}: {type(e).__name__}: {e}")
                    if sys.platform == "darwin" and isinstance(e, ImportError):
                        self.log("    the Mac window parts (PyObjC) are missing; the window opens in your browser instead")
                        open_window = True  # never run invisibly: show the page somewhere
                    try:
                        from .report import log_error
                        log_error(self.db_path, ["tray"], e)
                    except Exception:
                        pass
            self.log(f"{time.strftime('%H:%M:%S')}  Project Vault {__version__} started"
                     + (" (waiting for Ableton Live)" if not self.active else ""))
            threading.Thread(target=self.housekeeping, daemon=True, name="housekeeping").start()
            self.start_watcher()
            if open_window:
                self.active = True
                self.open_window()
            if self.icon:
                self.icon.loop(visible=self.active)  # until Quit
            else:
                self.quit_event.wait()
        finally:
            unexpected = not self.quit_reason
            if unexpected:
                self.log(f"{time.strftime('%H:%M:%S')}  closing: stopped unexpectedly; starting again")
            self.quit_event.set()
            self.stop_watcher(wait=True)
            server.shutdown()
            self._release()
            if unexpected and self.icon is not None and time.time() - self.started > 120:
                launch(self.db_path, False, self.mode, [str(f) for f in self.folders()])  # not if it can't even get going
            try:
                import json
                info = self.data / "gui.json"
                if json.loads(info.read_text(encoding="utf-8")).get("pid") == os.getpid():
                    info.unlink()
            except (OSError, ValueError):
                pass
        return 0


# ------------------------------------------------------------------ the notification-area icon (Windows)

class TrayIcon:
    WM_TRAY = 0x8000 + 1  # WM_APP + 1
    IDS = {"open": 1, "keep": 2, "backup": 3, "pause": 4, "start_windows": 5, "start_live": 6,
           "start_off": 7, "quit": 9}

    def __init__(self, agent: Agent):
        import ctypes
        from ctypes import wintypes as w
        self.agent = agent
        self.ct, self.w = ctypes, w
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        LRESULT = ctypes.c_ssize_t
        self.WNDPROC = ctypes.WINFUNCTYPE(LRESULT, w.HWND, w.UINT, w.WPARAM, w.LPARAM)

        class WNDCLASSW(ctypes.Structure):
            _fields_ = [("style", w.UINT), ("lpfnWndProc", self.WNDPROC), ("cbClsExtra", ctypes.c_int),
                        ("cbWndExtra", ctypes.c_int), ("hInstance", w.HINSTANCE), ("hIcon", w.HICON),
                        ("hCursor", w.HANDLE), ("hbrBackground", w.HBRUSH), ("lpszMenuName", w.LPCWSTR),
                        ("lpszClassName", w.LPCWSTR)]

        class GUID(ctypes.Structure):
            _fields_ = [("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort), ("Data3", ctypes.c_ushort),
                        ("Data4", ctypes.c_ubyte * 8)]

        class NOTIFYICONDATAW(ctypes.Structure):
            _fields_ = [("cbSize", w.DWORD), ("hWnd", w.HWND), ("uID", w.UINT), ("uFlags", w.UINT),
                        ("uCallbackMessage", w.UINT), ("hIcon", w.HICON), ("szTip", w.WCHAR * 128),
                        ("dwState", w.DWORD), ("dwStateMask", w.DWORD), ("szInfo", w.WCHAR * 256),
                        ("uVersion", w.UINT), ("szInfoTitle", w.WCHAR * 64), ("dwInfoFlags", w.DWORD),
                        ("guidItem", GUID), ("hBalloonIcon", w.HICON)]

        class MSG(ctypes.Structure):
            _fields_ = [("hwnd", w.HWND), ("message", w.UINT), ("wParam", w.WPARAM), ("lParam", w.LPARAM),
                        ("time", w.DWORD), ("pt", w.POINT)]

        self.NOTIFYICONDATAW, self.MSG = NOTIFYICONDATAW, MSG
        u = self.user32
        u.DefWindowProcW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
        u.DefWindowProcW.restype = LRESULT
        u.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASSW)]
        u.RegisterClassW.restype = w.ATOM
        u.CreateWindowExW.argtypes = [w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_int, w.HWND, w.HMENU, w.HINSTANCE, w.LPVOID]
        u.CreateWindowExW.restype = w.HWND
        u.LoadImageW.argtypes = [w.HINSTANCE, w.LPCWSTR, w.UINT, ctypes.c_int, ctypes.c_int, w.UINT]
        u.LoadImageW.restype = w.HANDLE
        u.CreatePopupMenu.restype = w.HMENU
        u.AppendMenuW.argtypes = [w.HMENU, w.UINT, ctypes.c_size_t, w.LPCWSTR]
        u.TrackPopupMenu.argtypes = [w.HMENU, w.UINT, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.HWND, w.LPVOID]
        u.TrackPopupMenu.restype = ctypes.c_int
        u.SetMenuDefaultItem.argtypes = [w.HMENU, w.UINT, w.UINT]
        u.DestroyMenu.argtypes = [w.HMENU]
        u.GetCursorPos.argtypes = [ctypes.POINTER(w.POINT)]
        u.SetForegroundWindow.argtypes = [w.HWND]
        u.PostMessageW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]
        u.GetMessageW.argtypes = [ctypes.POINTER(MSG), w.HWND, w.UINT, w.UINT]
        u.GetMessageW.restype = ctypes.c_int
        u.TranslateMessage.argtypes = [ctypes.POINTER(MSG)]
        u.DispatchMessageW.argtypes = [ctypes.POINTER(MSG)]
        u.DispatchMessageW.restype = LRESULT
        u.DestroyWindow.argtypes = [w.HWND]
        u.PostQuitMessage.argtypes = [ctypes.c_int]
        u.RegisterWindowMessageW.argtypes = [w.LPCWSTR]
        u.RegisterWindowMessageW.restype = w.UINT
        self.shell32.Shell_NotifyIconW.argtypes = [w.DWORD, ctypes.POINTER(NOTIFYICONDATAW)]
        self.shell32.Shell_NotifyIconW.restype = w.BOOL
        kernel32.GetModuleHandleW.argtypes = [w.LPCWSTR]
        kernel32.GetModuleHandleW.restype = w.HMODULE

        self.hinst = kernel32.GetModuleHandleW(None)
        self._proc = self.WNDPROC(self._wndproc)  # kept: Windows calls it for as long as the window lives
        wc = WNDCLASSW()
        wc.lpfnWndProc = self._proc
        wc.hInstance = self.hinst
        wc.lpszClassName = "ProjectVaultTray"
        u.RegisterClassW(ctypes.byref(wc))
        self.hwnd = u.CreateWindowExW(0, "ProjectVaultTray", "Project Vault", 0, 0, 0, 0, 0, None, None, self.hinst, None)
        self.taskbar_created = u.RegisterWindowMessageW("TaskbarCreated")
        self.hicon = u.LoadImageW(None, str(ICON), 1, 0, 0, 0x10 | 0x40)  # IMAGE_ICON, LR_LOADFROMFILE|LR_DEFAULTSIZE
        self.tip = "Project Vault"
        self.visible = False
        self.closing = False
        self.lock = threading.Lock()

    def _data(self, flags: int):
        d = self.NOTIFYICONDATAW()
        d.cbSize = self.ct.sizeof(self.NOTIFYICONDATAW)
        d.hWnd = self.hwnd
        d.uID = 1
        d.uFlags = flags
        d.uCallbackMessage = self.WM_TRAY
        d.hIcon = self.hicon
        d.szTip = self.tip[:127]
        return d

    def show(self) -> None:
        with self.lock:
            if not self.visible:
                self.shell32.Shell_NotifyIconW(0, self.ct.byref(self._data(0x1 | 0x2 | 0x4)))  # NIM_ADD
                self.visible = True

    def hide(self) -> None:
        with self.lock:
            if self.visible:
                self.shell32.Shell_NotifyIconW(2, self.ct.byref(self._data(0)))  # NIM_DELETE
                self.visible = False

    def set_tip(self, text: str) -> None:
        self.tip = text
        with self.lock:
            if self.visible:
                self.shell32.Shell_NotifyIconW(1, self.ct.byref(self._data(0x4)))  # NIM_MODIFY, NIF_TIP

    def close(self) -> None:
        self.closing = True
        self.user32.PostMessageW(self.hwnd, 0x0010, 0, 0)  # WM_CLOSE: handled on the icon's own thread

    def loop(self, visible: bool = True) -> None:
        if visible:
            self.show()
        self.agent.update_tip()
        msg = self.MSG()
        while True:
            got = self.user32.GetMessageW(self.ct.byref(msg), None, 0, 0)
            if got == 0:
                break  # WM_QUIT
            if got < 0:
                self.agent.log(f"{time.strftime('%H:%M:%S')}  taskbar icon error {self.ct.get_last_error()}")
                break
            self.user32.TranslateMessage(self.ct.byref(msg))
            self.user32.DispatchMessageW(self.ct.byref(msg))

    def _wndproc(self, hwnd, msg, wparam, lparam):
        try:
            if msg == self.WM_TRAY:
                if lparam in (0x0202, 0x0203):  # left click / double-click: open the window
                    self.agent.open_window()
                elif lparam in (0x0205, 0x007B):  # right click: the menu
                    self.menu()
                return 0
            if msg == self.taskbar_created:  # Explorer restarted: put the icon back
                was = self.visible
                self.visible = False
                if was:
                    self.show()
                return 0
            if msg == 0x0010:  # WM_CLOSE
                if not self.closing:  # another program asking every window to close: stay running
                    self.agent.log(f"{time.strftime('%H:%M:%S')}  another program asked Project Vault to close; staying open")
                    return 0
                self.hide()
                self.user32.DestroyWindow(hwnd)
                return 0
            if msg == 0x0011:  # WM_QUERYENDSESSION: Windows may sign out; fine by us
                return 1
            if msg == 0x0016:  # WM_ENDSESSION
                if wparam:  # Windows is signing out, restarting or shutting down
                    self.agent.quit_reason = "Windows is signing out or shutting down"
                    self.agent.log(f"{time.strftime('%H:%M:%S')}  closing: {self.agent.quit_reason}")
                    self.agent.quit_event.set()
                    self.agent.stop_watcher(wait=True)
                return 0
            if msg == 0x0002:  # WM_DESTROY
                self.user32.PostQuitMessage(0)
                return 0
        except Exception:
            pass
        return self.user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def menu(self) -> None:
        from .gui import live_window_set
        from .history import startup_mode
        u, ids, a = self.user32, self.IDS, self.agent
        m = u.CreatePopupMenu()
        sub = u.CreatePopupMenu()
        MF_STRING, MF_CHECKED, MF_GRAYED, MF_SEP, MF_POPUP = 0, 0x8, 0x1, 0x800, 0x10
        live = live_window_set()
        u.AppendMenuW(m, MF_STRING, ids["open"], "Open Project Vault")
        u.SetMenuDefaultItem(m, ids["open"], 0)
        label = f"Keep a version of “{live[:38]}” now" if live and live.lower() != "untitled" else "Keep a version of the song in Live now"
        u.AppendMenuW(m, MF_STRING | (0 if live else MF_GRAYED), ids["keep"], label)
        try:
            from .backup import load
            has_backup = bool(load(a.data)["destinations"])
        except Exception:
            has_backup = False
        u.AppendMenuW(m, MF_STRING | (0 if has_backup else MF_GRAYED), ids["backup"], "Back up now")
        u.AppendMenuW(m, MF_SEP, 0, None)
        u.AppendMenuW(m, MF_STRING | (0 if a.paused else MF_CHECKED), ids["pause"], "Keep a version of every save")
        mode = startup_mode()
        u.AppendMenuW(sub, MF_STRING | (MF_CHECKED if mode == "windows" else 0), ids["start_windows"], "When Windows starts")
        u.AppendMenuW(sub, MF_STRING | (MF_CHECKED if mode == "live" else 0), ids["start_live"], "When I open Ableton Live")
        u.AppendMenuW(sub, MF_STRING | (MF_CHECKED if mode == "off" else 0), ids["start_off"], "Only when I open it")
        u.AppendMenuW(m, MF_POPUP, sub or 0, "Start Project Vault")
        u.AppendMenuW(m, MF_SEP, 0, None)
        u.AppendMenuW(m, MF_STRING, ids["quit"], "Quit Project Vault")
        pt = self.w.POINT()
        u.GetCursorPos(self.ct.byref(pt))
        u.SetForegroundWindow(self.hwnd)  # so the menu closes when you click elsewhere
        cmd = u.TrackPopupMenu(m, 0x0100 | 0x0002, pt.x, pt.y, 0, self.hwnd, None)  # TPM_RETURNCMD|TPM_RIGHTBUTTON
        u.PostMessageW(self.hwnd, 0, 0, 0)
        u.DestroyMenu(m)
        self.do(cmd)

    def do(self, cmd: int) -> None:
        a, ids = self.agent, self.IDS
        if cmd == ids["open"]:
            a.open_window()
        elif cmd == ids["keep"]:
            threading.Thread(target=a.keep_live_version, daemon=True).start()
        elif cmd == ids["backup"] and a.app:
            try:
                a.app.start_job("backup", ["run"])
            except ValueError:
                pass
        elif cmd == ids["pause"]:
            a.set_paused(not a.paused)
        elif cmd in (ids["start_windows"], ids["start_live"], ids["start_off"]):
            a.set_startup({ids["start_windows"]: "windows", ids["start_live"]: "live"}.get(cmd, "off"))
        elif cmd == ids["quit"]:
            threading.Thread(target=a.quit, args=("you chose Quit from the icon",), daemon=True).start()


def main(db_path: str, mode: str = "windows", folders: list[str] | None = None, open_window: bool = False) -> int:
    return Agent(db_path, folders, mode).run(open_window=open_window)
