"""Project Vault's window.

    python -m project_vault gui

A small web server on this computer only (127.0.0.1, a fresh random key each time) serves the
app's page and answers its questions; the page opens in an Edge app window (no address bar or
tabs). Closing that window stops the server. Long jobs (scan, relink, swap...) run the same
commands as the command line, in their own process, and the page shows their output live.

Nothing here is reachable from another computer, and a web page open in a browser can't call
it either: every request must carry the key, and the Host must be this computer's own address.
"""
from __future__ import annotations

import json
import mimetypes
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import __version__

STATIC = Path(__file__).with_name("gui_static")
PACKAGE_ROOT = Path(__file__).resolve().parent.parent
NO_WINDOW = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
IS_MAC = sys.platform == "darwin"


def other_drives() -> list[str]:
    """Drives besides the system one, where projects or samples might be."""
    if IS_MAC:
        from .macos import volumes
        return volumes()
    return []

# Commands the page may start, and the options each may carry. Anything else is refused.
JOBS = {
    "scan": "Reading your projects",
    "duplicates": "Finding duplicate copies",
    "relink": "Searching for missing samples",
    "fix": "Writing relinked copies",
    "plugin-check": "Checking plugins",
    "swap": "Writing swapped copies",
    "presets": "Collecting plugin sounds",
    "update": "Installing the update",
    "report": "Making a support report",
    "tidy": "Tidying copies into folders",
    "backup": "Backing up",
}
JOB_FLAGS = {
    "scan": {"--full", "--originals", "--ignore-swapped"},
    "duplicates": {"--ignore"},
    "relink": {"--no-rebuild"},
    "fix": {"--dry-run", "--include-check"},
    "plugin-check": set(),
    "swap": {"--list", "--dry-run"},
    "presets": set(),
    "update": {"--yes"},
    "report": {"--show"},
    "tidy": {"--dry-run"},
    "backup": set(),
}


# ------------------------------------------------------------------ settings

def data_dir(db_path: str | os.PathLike) -> Path:
    return Path(db_path).resolve().parent


def load_settings(db_path) -> dict:
    try:
        s = json.loads((data_dir(db_path) / "gui_settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        s = {}
    s.setdefault("project_folders", [])
    s.setdefault("sample_folders", [])
    return s


def save_settings(db_path, s: dict) -> None:
    p = data_dir(db_path) / "gui_settings.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(s, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, p)


def autostart_folders() -> list[str]:
    """The folders the background watcher was started on (read from its log-in script)."""
    from .history import startup_script
    if IS_MAC:
        from .macos import launch_agent_args
        items = launch_agent_args() or []
        return items[items.index("--watch") + 1:] if "--watch" in items else []
    try:
        text = startup_script().read_text(encoding="utf-8")
    except OSError:
        return []
    items = re.findall(r'""([^"]*)""', text)  # each part of the command is wrapped in doubled quotes
    for flag in ("--watch", "--log"):
        if flag in items:
            return items[items.index(flag) + 1:]
    return []


# ------------------------------------------------------------------ Live's open set

def live_window_set() -> str | None:
    """The name of the set open in Live, from Live's window title ("Song* - Ableton Live 12 Suite")."""
    w = live_window()
    return w[0] if w else None


def live_window() -> tuple[str, bool] | None:
    """(name of the set open in Live, whether it has unsaved changes), or None when Live isn't open."""
    if IS_MAC:
        from .macos import live_window as mac_live_window
        return mac_live_window()
    if os.name != "nt":
        return None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def each(hwnd, _):
        if user32.IsWindowVisible(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            if n:
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(hwnd, buf, n + 1)
                m = re.match(r"^(.*?)(\*?) - Ableton Live \d", buf.value)
                if m:
                    found.append((m.group(1).strip(), bool(m.group(2))))
        return True

    try:
        user32.EnumWindows(each, 0)
    except Exception:
        return None
    return found[0] if found else None


# ------------------------------------------------------------------ the app's state

class App:
    def __init__(self, db_path: str, agent=None):
        self.db_path = str(db_path)
        self.agent = agent  # the background app (tray icon) this window belongs to, if any
        self.lock = threading.Lock()
        self.job: dict | None = None
        self.jobs_done: list[dict] = []
        self.attention: dict = {"state": "idle"}
        self.summaries: dict[str, object] = {}
        self._library: tuple[float, list[dict]] | None = None
        self.last_seen = time.time()
        self.closing_at: float | None = None
        self.pages: dict[str, float] = {}  # each open view of the app -> when it last asked something
        from .resave import Session, open_in_live
        self.resave = Session(opener=open_in_live, live=live_window)
        self.resave_find: dict = {"state": "idle"}
        self.resave_finish: dict = {"state": "idle"}

    # -- helpers
    def db(self):
        from .database import VaultDB
        return VaultDB(self.db_path)

    def history_root(self) -> Path:
        from .history import history_root
        return history_root(self.db_path)

    def library_dir(self) -> Path:
        from .library import library_root
        return library_root(self.db_path)

    def library(self) -> list[dict]:
        from .library import _index, entries
        lib = self.library_dir()
        try:
            mtime = _index(lib).stat().st_mtime
        except OSError:
            return []
        if not self._library or self._library[0] != mtime:
            self._library = (mtime, entries(lib))
        return self._library[1]

    def history_songs(self) -> dict[str, dict]:
        """Songs with history: normalised path -> {path, name, versions, last, dir}."""
        out = {}
        root = self.history_root()
        for meta in root.glob("*/project.json") if root.is_dir() else []:
            try:
                info = json.loads(meta.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            snaps = sorted(meta.parent.glob("*.als"))
            if not snaps:
                continue
            last = snaps[-1].name[:15]
            out[info["path"].lower()] = {"path": info["path"], "name": info.get("name") or Path(info["path"]).stem,
                                         "versions": len(snaps), "last": _stamp(last)}
        return out

    def song_groups(self, rows) -> dict[str, dict]:
        """Each song once: its original and its Relinked/Swapped copies, ignored duplicates left out.
        'rep' is the version to show and check: the swapped copy, else the relinked one, else the original."""
        from .database import norm
        from .duplicates import is_ignored, load_ignored, original_of
        ignored = load_ignored(self.db_path)
        groups: dict[str, dict] = {}
        for r in rows:
            p = Path(r["path"])
            if is_ignored(p, ignored):
                continue
            orig = original_of(p)
            g = groups.setdefault(norm(str(orig)), {"original": str(orig), "files": []})
            g["files"].append(r)
        for g in groups.values():
            def rank(r):
                folder = Path(r["path"]).parent.name.lower()
                return {"swapped": 0, "relinked": 1}.get(folder, 2)
            g["files"].sort(key=rank)
            g["rep"] = g["files"][0]
            g["copy"] = rank(g["rep"]) < 2
        return groups

    def default_project_folder(self) -> str:
        s = load_settings(self.db_path)
        if s["project_folders"]:
            return s["project_folders"][0]
        auto = autostart_folders()
        if auto:
            return auto[0]
        db = self.db()
        try:
            paths = [r[0] for r in db.conn.execute("SELECT path FROM projects WHERE path NOT LIKE '%Relinked%' "
                                                   "AND path NOT LIKE '%Swapped%'")]
        finally:
            db.close()
        try:
            return os.path.commonpath(paths) if paths else ""
        except ValueError:
            return ""

    # -- overview
    def overview(self) -> dict:
        from .duplicates import load_ignored
        db = self.db()
        try:
            stats = db.stats()
            originals = len(self.song_groups(db.conn.execute("SELECT id, path FROM projects").fetchall()))
        finally:
            db.close()
        lib = self.library()
        songs = self.history_songs()
        by_name = {v["name"].lower(): v for v in songs.values()}
        recent = [{"song": v["name"], "path": v["path"], "date": v["last"][:10], "time": v["last"][11:],
                   "versions": v["versions"]}
                  for v in sorted(songs.values(), key=lambda v: v["last"], reverse=True)[:6]]
        live = live_window_set()
        live_song = None
        if live:
            s = by_name.get(live.lower())
            live_song = {"name": live, "path": s["path"] if s else "", "versions": s["versions"] if s else 0,
                         "last": s["last"] if s else ""}
        try:
            ignored = len(load_ignored(self.db_path))
        except Exception:
            ignored = 0
        return {
            "version": __version__,
            "songs": originals, "projects": stats["projects"], "tracks": stats["tracks"],
            "samples": stats["unique samples"], "plugins": stats["unique plugins"],
            "sounds": len(lib), "unique_sounds": len({e["hash"] for e in lib}),
            "sound_plugins": len({e["plugin"] for e in lib}),
            "duplicates_ignored": ignored,
            "history": self._history_state(len(songs)),
            "recent": recent, "live": live_song,
            "project_folder": self.default_project_folder(),
            "needs_setup": self.needs_setup(),
        }

    def needs_setup(self) -> bool:
        """A new install: nothing chosen and nothing read yet (an existing user never sees the setup)."""
        s = load_settings(self.db_path)
        if s.get("setup_done") or s["project_folders"] or autostart_folders():
            return False
        db = self.db()
        try:
            return not db.conn.execute("SELECT 1 FROM projects LIMIT 1").fetchone()
        finally:
            db.close()

    def setup_suggest(self) -> dict:
        return {"projects": suggest_project_folders(), "samples": suggest_sample_folders(),
                "startup": __import__("project_vault.history", fromlist=["startup_mode"]).startup_mode()}

    def setup_finish(self, p: dict) -> dict:
        """Save the choices, start keeping versions, set when it starts, and begin reading the projects."""
        folders = [str(f) for f in p.get("project_folders") or [] if str(f).strip()][:5]
        if not folders or not all(Path(f).is_dir() for f in folders):
            raise ValueError("choose the folder your Live projects are in")
        samples = [str(f) for f in p.get("sample_folders") or [] if str(f).strip() and Path(str(f)).is_dir()][:20]
        mode = str(p.get("startup", "windows"))
        if mode not in ("windows", "live", "off"):
            raise ValueError("unknown choice")
        s = load_settings(self.db_path)
        s.update(project_folders=folders, sample_folders=samples, setup_done=True,
                 history_paused=not p.get("history", True))
        save_settings(self.db_path, s)
        self.set_startup(mode)
        if self.agent:  # watch the chosen folder from now on (or stay off, if they said so)
            if s["history_paused"]:
                self.agent.set_paused(True)
            else:
                self.agent.restart_watcher()
        job = self.start_job("scan", [folders[0]])
        if len(folders) > 1:  # the others after the first, one at a time
            def rest():
                self._wait_job(job["id"])
                for f in folders[1:]:
                    self._wait_job(self._launch("scan", [f])["id"])
            threading.Thread(target=rest, daemon=True).start()
        return {"ok": True}

    def _history_state(self, n_songs: int) -> dict:
        from .history import is_running, startup_mode
        a = self.agent
        mode = startup_mode()
        if a:
            running, paused = a.watching(), a.paused
            folders = [str(f) for f in a.folders()]
        else:
            running, paused = is_running(self.history_root()), bool(load_settings(self.db_path).get("history_paused"))
            folders = autostart_folders()
        return {"autostart": mode != "off", "startup": mode, "running": running, "paused": paused,
                "folders": folders, "songs": n_songs, "agent": bool(a), "note": getattr(a, "note", "")}

    def set_startup(self, mode: str) -> dict:
        if mode not in ("windows", "live", "off"):
            raise ValueError("unknown choice")
        if self.agent:
            self.agent.set_startup(mode)
        else:
            from .history import _remove_old_launchers, startup_script, write_launcher
            if mode == "off":
                startup_script().unlink(missing_ok=True)
                _remove_old_launchers()
            else:
                f = self.default_project_folder()
                write_launcher(self.db_path, [Path(f)] if f else [], PACKAGE_ROOT, mode)
        return {"ok": True}

    # -- what needs attention (slow: checks every sample and plugin on disk)
    def start_attention(self) -> None:
        with self.lock:
            if self.attention.get("state") == "working":
                return
            self.attention = {"state": "working", "started": time.time()}
        threading.Thread(target=self._attention, daemon=True).start()

    @staticmethod
    def _shopping_list(lacking: dict, songs_using, per_project: dict, reps: dict, free_older_version) -> list[dict]:
        """Every plugin a song needs that isn't ready here: the company, where to get it, what to do."""
        from .shopping import STATUS_TEXT, VENDOR_SITES, _found_name, search_link, vendor_for
        only_one: Counter = Counter()
        names: dict = {}
        for pid, g in reps.items():
            need = per_project.get(pid, set()) & set(lacking)
            if len(need) == 1:
                only_one[next(iter(need))] += 1
            for k in need:
                names.setdefault(k, []).append(g["rep"]["name"])
        items = []
        for key, r in lacking.items():
            if not songs_using[key] or r.status not in STATUS_TEXT:
                continue
            vendor, sure = vendor_for(r.name, r.old_files)
            label, advice = STATUS_TEXT[r.status]
            free = free_older_version(r.name) if r.status == "different version installed" else ""
            if free:
                label, advice = "Free with the version you have", free
            ex = sorted(n.replace(" (relinked)", "").replace(" (swapped)", "") for n in names.get(key, []))
            items.append({
                "name": r.name, "format": r.fmt, "status": r.status, "label": label,
                "advice": advice.format(found=_found_name(r.found_at)) if r.found_at else advice,
                "kind": "missing" if r.status == "missing" and not free else "have",
                "projects": songs_using[key], "only_thing": only_one[key], "unit": "song",
                "vendor": vendor if sure else "", "folder_hint": "" if sure else vendor,
                "site": VENDOR_SITES.get(vendor, "") if sure else "",
                "search": search_link(r.name, vendor if sure else ""), "examples": ex[:5],
            })
        items.sort(key=lambda i: (-i["only_thing"], -i["projects"], i["name"].lower()))
        return items

    def shopping(self) -> dict:
        a = self.attention
        if a.get("state") != "done":
            if a.get("state") in (None, "idle"):
                self.start_attention()
            return {"state": self.attention.get("state", "working"), "error": a.get("error", "")}
        return {"state": "done", "at": a["at"], "items": a.get("shopping", []), "songs": a.get("songs", {})}

    def shopping_print(self) -> dict:
        """The same list as a page to print or keep, opened in the browser."""
        from .shopping import write_html
        a = self.attention
        if a.get("state") != "done":
            raise ValueError("still checking your plugins")
        out = data_dir(self.db_path) / "Plugin shopping list.html"
        songs = a.get("songs", {})
        write_html(a.get("shopping", []), str(out), songs.get("total", 0), songs.get("ready", 0))
        if os.name == "nt" or IS_MAC:
            open_path(str(out))
        return {"ok": True, "path": str(out)}

    def _attention(self) -> None:
        try:
            from .plugin_check import DEFAULT_AU, DEFAULT_VST2, DEFAULT_VST3, check, find_installed, free_older_version
            from .relink import collect_missing
            db = self.db()
            try:
                missing = collect_missing(db)
                usage = db.plugin_usage()
                old_dirs = {os.path.dirname(f) for r in usage for f in (r["files"] or "").split(",") if f}
                inst = find_installed(list(dict.fromkeys(DEFAULT_VST2 + sorted(d for d in old_dirs if os.path.isdir(d)))),
                                      DEFAULT_VST3, DEFAULT_AU)
                results = check(usage, inst)
                lacking = {(r.name, r.fmt): r for r in results if r.status not in ("installed", "not checked (AU)")}
                per_project = {}
                for row in db.plugins_by_project():
                    per_project.setdefault(row["project_id"], set()).add((row["name"], row["format"]))
                groups = self.song_groups(db.conn.execute("SELECT id, path, name, live_version FROM projects").fetchall())
            finally:
                db.close()
            reps = {g["rep"]["id"]: g for g in groups.values()}
            rep_paths = {g["rep"]["path"] for g in groups.values()}
            originals = [p for p in missing if p.path in rep_paths]
            unique = {k[0] for p in originals for k in p.samples}
            songs_using = Counter(k for pid in reps for k in per_project.get(pid, ()) if k in lacking)
            def swap_to(r):  # what an installed version is called, from its file name
                return re.sub(r"\.(dll|vst3)$", "", Path(r.found_at.replace("\\", "/")).name, flags=re.I) if r.found_at else ""
            plugins = sorted(({"name": r.name, "fmt": r.fmt, "status": r.status, "projects": songs_using[key],
                               "found_at": r.found_at, "swap_to": swap_to(r), "free": free_older_version(r.name)}
                              for key, r in lacking.items() if songs_using[key]),
                             key=lambda x: (not x["swap_to"], -x["projects"], x["name"].lower()))
            blocked = sum(1 for pid in reps if per_project.get(pid, set()) & set(lacking))
            # only a Live 8/9 set that needs a plugin swapped needs a Live 12 save first
            old_sets = sum(1 for g in groups.values() if 0 < _major(g["rep"]["live_version"]) < 10
                           and per_project.get(g["rep"]["id"], set()) & set(lacking))
            shopping = self._shopping_list(lacking, songs_using, per_project, reps, free_older_version)
            self.attention = {
                "state": "done", "at": time.strftime("%H:%M"), "shopping": shopping,
                "songs": {"total": len(reps), "ready": len(reps) - blocked},
                "missing": {"songs": len(originals), "samples": len(unique),
                            "list": [{"name": p.name, "path": p.path, "count": len(p.samples)} for p in originals[:300]]},
                "plugins": {"count": len(plugins), "projects": blocked, "list": plugins[:250],
                            "swappable": sum(1 for x in plugins if x["swap_to"])},
                "old_sets": old_sets,
            }
        except Exception as e:  # shown on the page, never a crash
            self.attention = {"state": "error", "error": f"{type(e).__name__}: {e}"}

    # -- the song open in Live, and its latest versions (the left panel follows it)
    def _find_song(self, name: str) -> str | None:
        low = name.lower()
        cands = [v["path"] for v in self.history_songs().values() if v["name"].lower() == low]
        if not cands:
            db = self.db()
            try:
                cands = [r[0] for r in db.conn.execute("SELECT path FROM projects WHERE lower(name) = ?", (low,))]
            finally:
                db.close()
        if not cands:
            idx = self._stem_index()
            cands = idx.get(low, [])
        cands = [c for c in cands if Path(c).exists()] or cands
        if not cands:
            return None
        return max(cands, key=lambda c: Path(c).stat().st_mtime if Path(c).exists() else 0)

    def _stem_index(self) -> dict[str, list[str]]:
        """Every set in the projects folders by name; rebuilt at most every two minutes."""
        from .history import iter_projects
        if not getattr(self, "_idx", None) or time.time() - self._idx[0] > 120:
            idx: dict[str, list[str]] = {}
            for f in [self.default_project_folder()] + autostart_folders():
                if f and Path(f).is_dir():
                    for als in iter_projects(Path(f)):
                        idx.setdefault(als.stem.lower(), []).append(str(als))
            self._idx = (time.time(), idx)
        return self._idx[1]

    def now(self) -> dict:
        from . import history as h
        name = live_window_set()
        if not name:
            return {"live": None}
        if name.lower() in ("untitled", ""):
            return {"live": name, "unsaved": True, "versions": [], "total": 0}
        path = self._find_song(name)
        if not path:
            return {"live": name, "path": "", "versions": [], "total": 0}
        root = self.history_root()
        vs = h.versions(root, path)
        key = (path, len(vs), vs[-1].path.name if vs else "", tuple(sorted(h.labels(root, path).items())))
        if getattr(self, "_now", None) and self._now[0] == key:
            return self._now[1]
        names = h.labels(root, path)
        out = []
        tail = vs[-8:]
        prev = self._summary(vs[-9].path) if len(vs) > 8 else None
        first_n = len(vs) - len(tail) + 1
        for i, v in enumerate(tail, first_n):
            cur = self._summary(v.path)
            what = ("first version kept" if i == 1 else
                    "" if cur is None or prev is None else
                    (h.one_line(h.changes(prev, cur), 60) or "mix or settings only"))
            out.append({"n": i, "when": v.when.strftime("%b %d, %I:%M %p").replace(" 0", " "),
                        "label": names.get(v.key, ""),
                        "what": what, "source": v.source})
            prev = cur or prev
        res = {"live": name, "path": path, "total": len(vs), "versions": list(reversed(out))}
        self._now = (key, res)
        return res

    # -- storage (backups to the user's cloud folders)
    def storage(self) -> dict:
        from . import backup
        cfg = backup.load(data_dir(self.db_path))
        linked = {Path(d["path"]).parent for d in cfg["destinations"]}
        found = [dict(f, linked=Path(f["path"]) in linked) for f in backup.detect()]
        kinds = {f["kind"] for f in found}
        missing = [{"kind": k, "name": n, "url": u} for k, (n, u) in backup.INSTALL_LINKS.items() if k not in kinds]
        dests = []
        for d in cfg["destinations"]:
            reach = Path(d["path"]).parent.is_dir()
            dests.append(dict(d, reachable=reach))
        return {"destinations": dests, "found": found, "not_installed": missing, "computer": backup.computer_name()}

    # -- songs
    def songs(self, q: str = "", limit: int = 400) -> dict:
        hist = self.history_songs()
        db = self.db()
        try:
            rows = db.conn.execute("SELECT id, path, name, live_version, mtime FROM projects").fetchall()
        finally:
            db.close()
        t = q.lower().strip()
        seen, out = set(), []
        for g in self.song_groups(rows).values():
            # the file with history is the one being worked on; else the most-fixed version
            withh = [r for r in g["files"] if r["path"].lower() in hist]
            r = withh[0] if withh else g["rep"]
            seen.update(f["path"].lower() for f in g["files"])
            name = Path(g["original"]).stem
            if t and t not in name.lower():
                continue
            h = hist.get(r["path"].lower())
            folder = Path(r["path"]).parent.name.lower()
            out.append({"name": name, "path": r["path"], "live": r["live_version"] or "",
                        "modified": r["mtime"] or 0, "versions": h["versions"] if h else 0,
                        "last": h["last"] if h else "",
                        "copy": folder if folder in ("relinked", "swapped") else ""})
        for low, h in hist.items():  # songs with history that haven't been scanned
            if low not in seen and (not t or t in h["name"].lower()):
                out.append({"name": h["name"], "path": h["path"], "live": "", "modified": 0,
                            "versions": h["versions"], "last": h["last"]})
        out.sort(key=lambda s: (-(s["versions"] > 0), -_ts(s), s["name"].lower()))
        return {"total": len(out), "songs": out[:limit]}

    def _summary(self, path: Path):
        from .history import cached_summary
        key = str(path)
        if key not in self.summaries:
            try:
                self.summaries[key] = cached_summary(path)
            except Exception:
                self.summaries[key] = None
        return self.summaries[key]

    def song(self, path: str) -> dict:
        from . import history as h
        from .sidecar import read as read_sidecar
        root = self.history_root()
        vs = h.versions(root, path)
        names = h.labels(root, path)
        out_versions, prev = [], None
        for i, v in enumerate(vs, 1):
            cur = self._summary(v.path)
            if cur is None:
                what = "couldn't read this version"
            elif prev is None:
                what = "first version kept"
            else:
                what = h.one_line(h.changes(prev, cur)) or "no changes Project Vault can see (mixer or automation)"
            out_versions.append({"n": i, "when": v.when.strftime("%b %d, %Y %I:%M %p").replace(" 0", " "),
                                 "source": v.source, "label": names.get(v.key, ""), "what": what})
            prev = cur or prev
        card = read_sidecar(path) or {}
        info = {"path": path, "name": Path(path).stem, "exists": Path(path).exists(),
                "versions": list(reversed(out_versions)), "renamed_from": card.get("renamed_from", []),
                "branched_from": (card.get("branched_from") or {}).get("song", "")}
        db = self.db()
        try:
            row = db.conn.execute("SELECT * FROM projects WHERE path = ?", (path,)).fetchone()
            if row:
                tracks, samples, plugins = db.project_detail(row["id"])
                info.update(live=row["live_version"] or "", tempo=row["tempo"], tracks=len(tracks),
                            samples=len({s["path"] for s in samples}),
                            plugins=sorted({f'{p["name"]}' for p in plugins}, key=str.lower))
        finally:
            db.close()
        from .sidecar import song_id
        sid = song_id(path)
        info["sounds"] = sum(1 for e in self.library() if e.get("song_id") == sid)
        info["song_id"] = sid
        return info

    def diff(self, path: str, a: int, b: int) -> dict:
        from . import history as h
        vs = h.versions(self.history_root(), path)
        if not (1 <= a <= len(vs) and 1 <= b <= len(vs)):
            raise ValueError("no such version")
        sa, sb = self._summary(vs[a - 1].path), self._summary(vs[b - 1].path)
        if sa is None or sb is None:
            raise ValueError("couldn't read one of these versions")
        return {"a": a, "b": b, "lines": h.changes(sa, sb)}

    def label(self, path: str, n: int, text: str) -> dict:
        from . import history as h
        root = self.history_root()
        vs = h.versions(root, path)
        if not 1 <= n <= len(vs):
            raise ValueError("no such version")
        h.set_label(root, path, vs[n - 1], text.strip()[:120])
        return {"ok": True}

    def restore(self, path: str, n: int) -> dict:
        from . import history as h
        vs = h.versions(self.history_root(), path)
        if not 1 <= n <= len(vs):
            raise ValueError("no such version")
        return {"file": str(h.restore(vs[n - 1], path))}

    def snapshot(self, path: str) -> dict:
        from . import history as h
        kept = h.snapshot(self.history_root(), path)
        if kept:
            h.collect_sounds(self.history_root(), path)
        return {"kept": bool(kept)}

    # -- plugin sounds
    def sounds(self, plugin: str = "", q: str = "", song: str = "", limit: int = 120) -> dict:
        lib = self.library()
        counts = Counter(e["plugin"] for e in lib)
        plugins = [{"name": n, "count": c} for n, c in counts.most_common()]
        t = q.lower().strip()
        sel = [e for e in lib if (not plugin or e["plugin"] == plugin)
               and (not song or song.lower() in e["song"].lower())
               and (not t or t in f"{e['plugin']} {e['song']} {e['track']} {e['preset']}".lower())]
        seen, items = set(), []
        for e in sel:  # one card per distinct sound
            if e["hash"] in seen:
                continue
            seen.add(e["hash"])
            items.append(e)
        uses = Counter(e["hash"] for e in sel)
        return {"plugins": plugins, "total": len(lib), "matching": len(items),
                "songs": len({e["song"] for e in sel}),
                "items": [dict(e, uses=uses[e["hash"]]) for e in items[:limit]]}

    def export_sounds(self, hashes: list[str] | None, plugin: str = "", song: str = "", song_id: str = "") -> dict:
        from .cli import _presets_folder
        from .library import export_entries
        lib = self.library()
        if hashes:
            want, found, seen = set(hashes), [], set()
            for e in lib:
                if e["hash"] in want and e["hash"] not in seen:
                    seen.add(e["hash"])
                    found.append(e)
            name = found[0]["plugin"] if len({e["plugin"] for e in found}) == 1 else "Selected sounds"
        elif song_id:
            found = [e for e in lib if e.get("song_id") == song_id]
            name = song or "Song sounds"
        else:
            found = [e for e in lib if (not plugin or e["plugin"] == plugin)
                     and (not song or song.lower() in e["song"].lower())]
            name = plugin or song or "All sounds"
        to = _presets_folder(name)
        files = export_entries(self.library_dir(), found, to)
        return {"folder": str(to), "count": len(files)}

    # -- background history
    def set_history(self, on: bool, folders: list[str]) -> dict:
        from .history import disable_autostart, enable_autostart
        if self.agent:  # pause or resume keeping versions, inside the running app
            self.agent.set_paused(not on)
            return {"ok": True}
        if on:
            folders = [f for f in folders if f and Path(f).is_dir()]
            if not folders:
                raise ValueError("choose a projects folder first")
            enable_autostart(self.db_path, [Path(f) for f in folders], PACKAGE_ROOT)
        else:
            disable_autostart(self.db_path)
        return {"ok": True}

    # -- jobs
    def start_job(self, kind: str, args: list[str]) -> dict:
        if kind not in JOBS:
            raise ValueError("unknown job")
        flags = [a for a in args if a.startswith("--")]
        if any(f not in JOB_FLAGS[kind] for f in flags):
            raise ValueError("option not allowed")
        paths = [a for a in args if not a.startswith("--")]
        if kind == "presets":
            paths = [p for p in paths if p != "collect"]
            for p in paths:
                if not Path(p).exists():
                    raise ValueError(f"folder not found: {p}")
            args = ["collect", *paths]
        elif kind == "backup":
            from . import backup
            ids = {d["id"] for d in backup.load(data_dir(self.db_path))["destinations"]}
            wanted = [p for p in paths if p != "run"]
            if any(i not in ids for i in wanted):
                raise ValueError("no such backup place")
            args = ["run", *wanted]
        elif kind in ("scan", "relink", "duplicates", "tidy"):
            if not paths:
                raise ValueError("choose a folder first")
            for p in paths:
                if not Path(p).is_dir():
                    raise ValueError(f"folder not found: {p}")
        elif paths:
            raise ValueError("this job takes no folders")
        return self._launch(kind, args)

    def _launch(self, kind: str, args: list[str]) -> dict:
        """Run `python -m project_vault <kind> <args>` as the one running job (checked by the caller)."""
        with self.lock:
            if self.job and self.job["state"] == "running":
                raise ValueError(f"{self.job['title']} is still running")
            job = {"id": secrets.token_hex(4), "kind": kind, "title": JOBS[kind], "state": "running",
                   "lines": [], "code": None, "started": time.time(), "args": args}
            self.job = job
        cmd = [sys.executable, "-m", "project_vault", "--db", self.db_path, kind, *args]
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
        env.pop("PYTHONPATH", None)
        proc = subprocess.Popen(cmd, cwd=str(PACKAGE_ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, env=env, creationflags=NO_WINDOW,
                                text=True, encoding="utf-8", errors="replace", bufsize=1)
        job["pid"] = proc.pid

        def pump():
            for line in proc.stdout:
                job["lines"].append(line.rstrip("\r\n"))
            job["code"] = proc.wait()
            job["state"] = "done" if job["code"] == 0 else "failed"
            job["ended"] = time.time()
            self.summaries.clear()
            if kind in ("scan", "relink", "fix", "swap", "plugin-check", "duplicates"):
                self.attention = {"state": "idle"}
        threading.Thread(target=pump, daemon=True).start()
        return self.job_view(0)

    def _wait_job(self, job_id: str) -> dict:
        while self.job and self.job["id"] == job_id and self.job["state"] == "running":
            time.sleep(0.5)
        return self.job or {}

    # -- guided resave of Live 8/9 sets (one save in Live 12 each, before swap can finish them)
    def resave_list_file(self) -> Path:
        return data_dir(self.db_path) / "resave_list.txt"

    def resave_done_file(self) -> Path:
        return data_dir(self.db_path) / "resave_done.txt"

    def resave_view(self) -> dict:
        if self.resave.state == "idle" and self.resave_find["state"] != "finding":
            f = self.resave_list_file()
            if f.is_file():  # carry on from a list found earlier (another day, or before a restart)
                self.resave.load([l.strip() for l in f.read_text(encoding="utf-8").splitlines() if l.strip()])
        w = live_window()
        return self.resave.view() | {"find": dict(self.resave_find), "finish": dict(self.resave_finish),
                                     "live": {"open": bool(w), "name": w[0] if w else "",
                                              "unsaved": bool(w and w[1])},
                                     "windows": os.name == "nt" or IS_MAC}

    def resave_start_find(self) -> dict:
        with self.lock:
            if self.resave_find["state"] == "finding":
                return self.resave_view()
            if self.job and self.job["state"] == "running":
                raise ValueError(f"{self.job['title']} is still running")
            self.resave_find = {"state": "finding", "n": 0, "of": 0, "started": time.time()}
        self.resave.stop()
        threading.Thread(target=self._resave_find, daemon=True).start()
        return self.resave_view()

    def _resave_find(self) -> None:
        from types import SimpleNamespace
        from .cli import _resave_todo
        def progress(n, of):
            self.resave_find.update(n=n, of=of)
        try:
            db = self.db()
            try:
                todo, made = _resave_todo(db, SimpleNamespace(vst2=[], vst3=[]), progress)
            finally:
                db.close()
            f = self.resave_list_file()
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text("\n".join(todo) + ("\n" if todo else ""), encoding="utf-8")
            self.resave.load(todo, made)
            self.resave_finish = {"state": "idle"}
            self.resave_find = {"state": "done", "at": time.strftime("%H:%M"), "made": made}
        except Exception as e:  # shown on the page
            self.resave_find = {"state": "error", "error": f"{type(e).__name__}: {e}"}

    def resave_action(self, what: str) -> dict:
        r = self.resave
        if what == "start":
            if self.resave_find["state"] == "finding":
                raise ValueError("still finding the sets")
            r.start()
        elif what == "skip":
            r.skip()
        elif what == "reopen":
            r.reopen()
        elif what == "stop":
            r.stop()
        else:
            raise ValueError("unknown request")
        return self.resave_view()

    def resave_start_finish(self) -> dict:
        """After the saves: read the projects again, write the swapped copies of those sets, read again."""
        with self.lock:
            if self.resave_finish["state"] == "working":
                return self.resave_view()
            if self.job and self.job["state"] == "running":
                raise ValueError(f"{self.job['title']} is still running")
            if not self.resave.view()["saved"]:
                raise ValueError("no set has been saved in Live 12 yet")
            self.resave_finish = {"state": "working", "step": 1, "started": time.time()}
        # swap the sets where they are now: a loose set's save may be in a new "<name> Project" folder
        self.resave_done_file().write_text("\n".join(self.resave.saved_paths()) + "\n", encoding="utf-8")
        threading.Thread(target=self._resave_finish, daemon=True).start()
        return self.resave_view()

    def _resave_folders(self) -> list[str]:
        s = load_settings(self.db_path)
        folders = [f for f in (s["project_folders"] or [self.default_project_folder()]) if f and Path(f).is_dir()]
        return folders

    def _resave_finish(self) -> None:
        try:
            folders = self._resave_folders()
            if not folders:
                raise ValueError("choose your projects folder in Settings first")
            fin = self.resave_finish
            fin["step"] = 1  # the saved sets are Live 12 now: read them (the relinked copies, not old swapped ones)
            for f in folders:
                if self._wait_job(self._launch("scan", [f, "--ignore-swapped"])["id"]).get("code"):
                    raise ValueError("reading the projects stopped with an error (see the job panel)")
            fin["step"] = 2  # swapped copies of just those sets; ones already saved in Live are kept
            j = self._wait_job(self._launch("swap", ["--from-list", str(self.resave_done_file()), "--replace"])["id"])
            if j.get("code"):
                raise ValueError("writing the swapped copies stopped with an error (see the job panel)")
            out = j.get("lines", [])
            fin["written"] = [l.strip()[6:].split("  (")[0] for l in out if l.startswith("  Wrote ")]
            fin["notes"] = [l for l in out if "were kept as they are" in l or "still" in l.lower()][:5]
            fin["step"] = 3  # every song's newest copy back in the lists
            for f in folders:
                self._wait_job(self._launch("scan", [f])["id"])
            self.resave_finish = {"state": "done", "at": time.strftime("%H:%M"),
                                  "written": fin.get("written", []), "notes": fin.get("notes", [])}
            self.attention = {"state": "idle"}
        except Exception as e:
            self.resave_finish = {"state": "error", "error": str(e) or type(e).__name__}

    def job_view(self, since: int = 0) -> dict:
        j = self.job
        if not j:
            return {"state": "none"}
        return {k: j[k] for k in ("id", "kind", "title", "state", "code", "started")} | {
            "lines": j["lines"][since:], "next": len(j["lines"]), "ended": j.get("ended")}

    def stop_job(self) -> dict:
        j = self.job
        if j and j["state"] == "running" and j.get("pid"):
            try:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(j["pid"]), "/T", "/F"], capture_output=True,
                                   creationflags=NO_WINDOW)
                else:
                    os.kill(j["pid"], 15)
            except OSError:
                pass
        return {"ok": True}

    # -- updates
    def update_check(self) -> dict:
        from .updater import UpdateError, fetch_release, is_newer
        try:
            rel = fetch_release()
        except (UpdateError, OSError) as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "current": __version__, "latest": rel.version, "newer": is_newer(rel),
                "notes": rel.notes}


def _stamp(s: str) -> str:
    try:
        return time.strftime("%Y-%m-%d %H:%M", time.strptime(s, "%Y%m%d-%H%M%S"))
    except ValueError:
        return ""


def _ts(song: dict) -> float:
    if song.get("last"):
        try:
            return time.mktime(time.strptime(song["last"], "%Y-%m-%d %H:%M"))
        except ValueError:
            pass
    return song.get("modified") or 0


def _major(v: str | None) -> int:
    m = re.search(r"(\d+)", v or "")
    return int(m.group(1)) if m else 0


# ------------------------------------------------------------------ opening things for the user

def open_path(path: str, reveal: bool = False) -> None:
    p = Path(path)
    if not p.exists():
        raise ValueError(f"not found: {path}")
    if IS_MAC:
        from .macos import open_path as mac_open
        mac_open(str(p), reveal)
        return
    if os.name != "nt":
        return
    if reveal:
        subprocess.Popen(["explorer", "/select,", str(p)])
    else:
        os.startfile(str(p))  # .als opens in Live, a folder in Explorer


def pick_folder(title: str = "Choose a folder") -> str:
    """The system's own folder picker, run in its own process so it can't hang the server."""
    if IS_MAC:
        from .macos import pick_folder as mac_pick
        return mac_pick(title)
    code = ("import tkinter as t, tkinter.filedialog as f, sys\n"
            "r = t.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
            f"p = f.askdirectory(title={title!r}, mustexist=True)\n"
            "sys.stdout.write(p or '')\n")
    try:
        r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, timeout=600,
                           creationflags=NO_WINDOW)
        if r.returncode == 0:
            return os.path.normpath(r.stdout.strip()) if r.stdout.strip() else ""
    except (OSError, subprocess.TimeoutExpired):
        pass
    return _pick_folder_powershell(title)


def _pick_folder_powershell(title: str) -> str:
    """The same picker without tkinter (the installed app's Python has none)."""
    if os.name != "nt":
        return ""
    safe = title.replace("'", "''")
    ps = ("Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Application]::EnableVisualStyles(); "
          "$o = New-Object System.Windows.Forms.Form -Property @{TopMost=$true; ShowInTaskbar=$false}; "
          "$d = New-Object System.Windows.Forms.FolderBrowserDialog; "
          f"$d.Description = '{safe}'; $d.ShowNewFolderButton = $false; "
          "if ($d.ShowDialog($o) -eq 'OK') { [Console]::OutputEncoding = [Text.Encoding]::UTF8; "
          "[Console]::Out.Write($d.SelectedPath) }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", ps],
                           capture_output=True, timeout=600, creationflags=NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    out = r.stdout.decode("utf-8", "replace").strip().lstrip("\ufeff")
    return os.path.normpath(out) if out else ""


# ------------------------------------------------------------------ first run: where things are

SKIP_WALK = {"backup", "relinked", "swapped", "$recycle.bin", "system volume information", "windows",
             "program files", "program files (x86)", "programdata", "appdata", "node_modules", ".git",
             "user library", "factory packs", "core library", "packs"}


def count_sets(root: Path, max_depth: int = 4, budget: list | None = None) -> tuple[int, dict[str, int]]:
    """How many Live Sets are under root (not looking deeper than max_depth), and how many in each
    folder directly under it. `budget` caps the folders looked at, so a huge drive can't stall this."""
    budget = budget if budget is not None else [6000]
    total, per_child = 0, {}
    base = len(root.parts)
    try:
        walker = os.walk(root)
        for dirpath, dirnames, filenames in walker:
            budget[0] -= 1
            if budget[0] < 0:
                break
            here = Path(dirpath)
            depth = len(here.parts) - base
            dirnames[:] = [] if depth >= max_depth else [d for d in dirnames if d.lower() not in SKIP_WALK
                                                         and not d.startswith(".")]
            n = sum(1 for f in filenames if f.lower().endswith(".als") and not f.startswith("._"))
            if n:
                total += n
                if depth >= 1:
                    child = here.parts[base]
                    per_child[child] = per_child.get(child, 0) + n
    except OSError:
        pass
    return total, per_child


def suggest_project_folders(home: Path | None = None, drives: list[str] | None = None) -> list[dict]:
    """Folders that look like where someone keeps their Live projects, most sets first."""
    home = home or Path.home()
    cands = []
    for one in ("OneDrive", "OneDrive - Personal"):
        for sub in ("Documents", "Desktop", "Music"):
            cands.append(home / one / sub)
    for sub in ("Documents/Ableton", "Music/Ableton", "Documents", "Music", "Desktop"):
        cands.append(home / sub)
    if drives is None:
        drives = [f"{c}:\\" for c in "DEFGHIJ"] if os.name == "nt" else other_drives()
    cands += [Path(d) for d in drives]
    found, seen = [], set()
    budget = [12000]
    for c in cands:
        if not c.is_dir() or str(c).lower() in seen:
            continue
        seen.add(str(c).lower())
        total, per_child = count_sets(c, budget=budget)
        if not total:
            continue
        best = c
        for _ in range(4):  # one folder inside holding (nearly) all of them is the better answer,
            if not per_child:  # but not a single Live project (that's one song, not the library)
                break
            name, n = max(per_child.items(), key=lambda kv: kv[1])
            child = best / name
            if n < 0.9 * total or (child / "Ableton Project Info").is_dir() and n < 2:
                break
            best = child
            if (child / "Ableton Project Info").is_dir():
                break
            _, per_child = count_sets(child, budget=budget)
        found.append({"path": str(best), "sets": total})
    # a folder already counted inside another suggestion with the same sets adds nothing
    out = []
    for f in sorted(found, key=lambda f: (-f["sets"], len(f["path"]))):
        if any(f["path"].lower() == o["path"].lower() or (
                f["sets"] <= o["sets"] and (f["path"].lower() + os.sep).startswith(o["path"].lower() + os.sep))
               for o in out):
            continue
        out.append(f)
    return out[:5]


def suggest_sample_folders(home: Path | None = None, drives: list[str] | None = None) -> list[dict]:
    """Common places for samples: Splice, Ableton's User Library, other drives."""
    home = home or Path.home()
    named = [("Splice", home / "Splice"), ("Splice", home / "Documents" / "Splice"),
             ("Splice", home / "Music" / "Splice"),
             ("Ableton User Library", home / "Documents" / "Ableton" / "User Library"),
             ("Ableton User Library", home / "Music" / "Ableton" / "User Library"),
             ("Samples", home / "Music" / "Samples"), ("Samples", home / "Documents" / "Samples")]
    if drives is None:
        drives = [f"{c}:\\" for c in "DEFGHIJ"] if os.name == "nt" else other_drives()
    out = [{"label": label, "path": str(p)} for label, p in named if p.is_dir()]
    out += [{"label": f"Drive {d[:2]}", "path": d} for d in drives if Path(d).is_dir()]
    return out


# ------------------------------------------------------------------ the server

class Handler(BaseHTTPRequestHandler):
    app: App
    token: str
    port: int

    def log_message(self, *a):  # quiet
        pass

    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8") -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        if ctype.startswith("text/html"):
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                             "script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _host_ok(self) -> bool:
        return self.headers.get("Host", "") in (f"127.0.0.1:{self.port}", f"localhost:{self.port}")

    def _api_ok(self) -> bool:
        return self._host_ok() and secrets.compare_digest(self.headers.get("X-Vault-Key", ""), self.token)

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, b"{}")
        url = urlparse(self.path)
        if url.path.startswith("/api/"):
            if not self._api_ok():
                return self._json({"error": "not allowed"}, 403)
            return self._api("GET", url.path[5:], {k: v[-1] for k, v in parse_qs(url.query).items()})
        name = "index.html" if url.path in ("/", "/index.html") else url.path.lstrip("/")
        f = (STATIC / name).resolve()
        if STATIC.resolve() not in f.parents or not f.is_file():
            return self._send(404, b"not found", "text/plain")
        ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript", "image/svg+xml"):
            ctype += "; charset=utf-8"
        self._send(200, f.read_bytes(), ctype)

    def do_POST(self):
        url = urlparse(self.path)
        if not url.path.startswith("/api/") or not self._api_ok():
            return self._json({"error": "not allowed"}, 403)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(min(n, 1_000_000)) or b"{}") if n else {}
        except ValueError:
            return self._json({"error": "bad request"}, 400)
        self._api("POST", url.path[5:], body if isinstance(body, dict) else {})

    def _api(self, method: str, name: str, p: dict) -> None:
        app = self.app
        now = time.time()
        page = self.headers.get("X-Vault-Page", "")[:40]
        app.last_seen = now
        app.closing_at = None
        if page:
            app.pages[page] = now
        try:
            if name == "ping":
                return self._json({"ok": True, "version": __version__})
            if name == "bye":  # a view is closing (or reloading: a ping within seconds cancels this)
                app.pages.pop(page, None)
                others = [t for t in app.pages.values() if now - t < 90]
                if not others and not app.agent:  # the last view is gone: stop unless it comes back (a reload)
                    app.closing_at = now + 8
                return self._json({"ok": True})
            if method == "GET":
                if name == "overview":
                    return self._json(app.overview())
                if name == "attention":
                    if p.get("refresh") or app.attention.get("state") == "idle":
                        app.start_attention()
                    return self._json(app.attention)
                if name == "songs":
                    return self._json(app.songs(p.get("q", "")))
                if name == "song":
                    return self._json(app.song(p["path"]))
                if name == "diff":
                    return self._json(app.diff(p["path"], int(p["a"]), int(p["b"])))
                if name == "sounds":
                    return self._json(app.sounds(p.get("plugin", ""), p.get("q", ""), p.get("song", "")))
                if name == "job":
                    return self._json(app.job_view(int(p.get("since", 0))))
                if name == "settings":
                    s = load_settings(app.db_path)
                    if not s["project_folders"] and app.default_project_folder():
                        s["project_folders"] = [app.default_project_folder()]
                    return self._json(s | {"db": app.db_path, "version": __version__})
                if name == "update":
                    return self._json(app.update_check())
                if name == "now":
                    return self._json(app.now())
                if name == "storage":
                    return self._json(app.storage())
                if name == "resave":
                    return self._json(app.resave_view())
                if name == "setup":
                    return self._json(app.setup_suggest())
                if name == "shopping":
                    return self._json(app.shopping())
            else:
                if name == "job":
                    return self._json(app.start_job(p.get("kind", ""), [str(a) for a in p.get("args", [])]))
                if name == "job/stop":
                    return self._json(app.stop_job())
                if name == "label":
                    return self._json(app.label(p["path"], int(p["n"]), p.get("text", "")))
                if name == "restore":
                    return self._json(app.restore(p["path"], int(p["n"])))
                if name == "snapshot":
                    return self._json(app.snapshot(p["path"]))
                if name == "open":
                    open_path(p["path"], bool(p.get("reveal")))
                    return self._json({"ok": True})
                if name == "pick-folder":
                    return self._json({"folder": pick_folder(p.get("title", "Choose a folder"))})
                if name == "sounds/export":
                    return self._json(app.export_sounds(p.get("hashes"), p.get("plugin", ""), p.get("song", ""), p.get("song_id", "")))
                if name == "settings":
                    s = load_settings(app.db_path)
                    for k in ("project_folders", "sample_folders"):
                        if isinstance(p.get(k), list):
                            s[k] = [str(x) for x in p[k] if str(x).strip()][:20]
                    before = load_settings(app.db_path)["project_folders"]
                    save_settings(app.db_path, s)
                    if app.agent and s["project_folders"] != before:
                        app.agent.restart_watcher()
                    return self._json(s)
                if name == "history":
                    return self._json(app.set_history(bool(p.get("on")), p.get("folders") or []))
                if name == "startup":
                    return self._json(app.set_startup(str(p.get("mode", ""))))
                if name == "storage/link":
                    from . import backup
                    return self._json(backup.link(data_dir(app.db_path), p["path"], p.get("name", ""), p.get("kind", "folder")))
                if name == "storage/unlink":
                    from . import backup
                    backup.unlink(data_dir(app.db_path), p["id"])
                    return self._json({"ok": True})
                if name == "storage/what":
                    from . import backup
                    return self._json(backup.set_what(data_dir(app.db_path), p["id"], p.get("what") or {}))
                if name == "setup":
                    return self._json(app.setup_finish(p))
                if name == "shopping/print":
                    return self._json(app.shopping_print())
                if name == "resave/find":
                    return self._json(app.resave_start_find())
                if name == "resave/finish":
                    return self._json(app.resave_start_finish())
                if name.startswith("resave/"):
                    return self._json(app.resave_action(name[7:]))
                if name == "open-url":
                    from . import backup
                    from .shopping import SEARCH, VENDOR_SITES
                    urls = {u for _, u in backup.INSTALL_LINKS.values()} | set(VENDOR_SITES.values())
                    url = str(p.get("url", ""))
                    # only the cloud apps' download pages, plugin companies' sites, or a plugin search
                    if url not in urls and not (url.startswith(SEARCH) and len(url) < 400):
                        raise ValueError("not allowed")
                    import webbrowser
                    webbrowser.open(url)
                    return self._json({"ok": True})
            return self._json({"error": "unknown request"}, 404)
        except (KeyError, ValueError, OSError) as e:
            return self._json({"error": str(e) or type(e).__name__}, 400)
        except Exception as e:
            try:
                from .report import log_error
                log_error(app.db_path, ["gui", name], e)
            except Exception:
                pass
            return self._json({"error": f"{type(e).__name__}: {e}"}, 500)


def edge_path() -> str | None:
    for base in (os.environ.get("PROGRAMFILES(X86)"), os.environ.get("PROGRAMFILES"), os.environ.get("LOCALAPPDATA")):
        if base:
            p = Path(base) / "Microsoft" / "Edge" / "Application" / "msedge.exe"
            if p.exists():
                return str(p)
    return shutil.which("msedge")


def open_window(url: str, profile: Path):
    """An app window of its own (Edge, own profile, so closing it is seen). None = opened a browser tab."""
    edge = edge_path()
    if edge:
        profile.mkdir(parents=True, exist_ok=True)
        return subprocess.Popen([edge, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run",
                                 "--no-default-browser-check", "--window-size=1440,920",
                                 "--disable-features=msEdgeSidebarV2,TranslateUI"],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    import webbrowser
    webbrowser.open(url)
    return None


def _running_instance(info_file: Path) -> str | None:
    """The address of a Project Vault window server already running, if any."""
    import urllib.request
    try:
        info = json.loads(info_file.read_text(encoding="utf-8"))
        req = urllib.request.Request(f"http://127.0.0.1:{info['port']}/api/ping",
                                     headers={"X-Vault-Key": info["key"], "Host": f"127.0.0.1:{info['port']}"})
        with urllib.request.urlopen(req, timeout=2) as r:
            if json.loads(r.read()).get("ok"):
                return f"http://127.0.0.1:{info['port']}/#key={info['key']}"
    except (OSError, ValueError, KeyError):
        pass
    return None


def start_server(db_path: str, port: int = 0, agent=None):
    """Start the window's server in a thread. Returns (server, app, url)."""
    ddir = data_dir(db_path)
    ddir.mkdir(parents=True, exist_ok=True)
    app = App(db_path, agent)
    token = secrets.token_urlsafe(24)
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    port = server.server_address[1]
    Handler.app, Handler.token, Handler.port = app, token, port
    (ddir / "gui.json").write_text(json.dumps({"port": port, "key": token, "pid": os.getpid()}), encoding="utf-8")
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, app, f"http://127.0.0.1:{port}/#key={token}"


def run(db_path: str, open_ui: bool = True, port: int = 0) -> None:
    ddir = data_dir(db_path)
    ddir.mkdir(parents=True, exist_ok=True)
    info_file = ddir / "gui.json"
    existing = _running_instance(info_file)
    if existing and open_ui and IS_MAC:
        from .tray import ask_to_open
        ask_to_open(ddir)
        print("Project Vault is already running; its window is opening.")
        return
    if existing and open_ui:
        open_window(existing, ddir / "gui_window")
        print("Project Vault is already running; opened its window.")
        return
    if open_ui and (os.name == "nt" or IS_MAC):
        # the window belongs to the background app (taskbar's hidden icons; the Mac's menu bar)
        from .history import startup_mode
        from .tray import launch
        mode = startup_mode()
        launch(db_path, open_window=True, mode="live" if mode == "live" else "windows")
        print("Project Vault is opening. It stays in your "
              + ("menu bar (the cat, top right)" if IS_MAC else "taskbar's hidden icons (^)") + " until you quit it there.")
        return
    server, app, url = start_server(db_path, port)
    print(f"Project Vault {__version__} is open in its own window. Closing that window stops it.")
    window = open_window(url, ddir / "gui_window") if open_ui else None
    if not open_ui:
        print(url)
    try:
        while True:
            time.sleep(1)
            if app.job and app.job["state"] == "running":
                continue  # never stop in the middle of a job
            quiet = time.time() - app.last_seen
            if app.closing_at and time.time() > app.closing_at:
                break  # the page said goodbye and didn't come back (not a reload)
            if window is not None and window.poll() is not None and quiet > 30:
                break  # the app window was closed
            if quiet > 900:
                break  # nothing has asked anything for 15 minutes (a browser tab that's gone)
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        try:
            if json.loads(info_file.read_text(encoding="utf-8")).get("port") == server.server_address[1]:
                info_file.unlink()
        except (OSError, ValueError):
            pass
