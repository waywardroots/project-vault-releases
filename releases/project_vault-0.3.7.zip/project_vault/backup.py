"""Backups to the user's own cloud storage (or any folder or drive).

OneDrive, Google Drive, Dropbox, iCloud Drive and Box each install an app that keeps a folder on
this computer in sync with the cloud. Project Vault copies backups into a "Project Vault Backups"
folder inside it and the cloud app uploads them: no sign-in or password ever passes through
Project Vault, and it costs nothing. Any other folder works the same way (a NAS, a USB drive).

What a backup holds, under <destination>\\Project Vault Backups\\<computer name>\\:
  Songs\\     every Live Set in the projects folder, same layout       (small, on by default)
  Versions\\  every kept version of every song                          (on by default)
  Sounds\\    the plugin sound library                                  (on by default)
  Projects\\  the whole projects folder, samples and all                (large, off by default)

Backups only add and update: nothing is ever deleted from a backup, so deleting a song on this
computer never deletes its backup. New versions are copied right after each save by the
background watcher; "backup run" brings everything else up to date.
"""
from __future__ import annotations

import json
import os
import sys
import platform
import secrets
import shutil
import time
from pathlib import Path

FOLDER = "Project Vault Backups"
WHAT_DEFAULT = {"songs": True, "versions": True, "sounds": True, "projects": False}
SKIP_DIRS = {"__macosx", ".git", "$recycle.bin", "system volume information"}
SKIP_SUFFIXES = (".tmp", ".partial", ".crdownload", ".asd")  # .asd = Live's analysis files, rebuilt by Live


def config_file(data_dir: Path) -> Path:
    return Path(data_dir) / "backup.json"


def load(data_dir: Path) -> dict:
    try:
        cfg = json.loads(config_file(data_dir).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        cfg = {}
    cfg.setdefault("destinations", [])
    for d in cfg["destinations"]:
        d["what"] = {**WHAT_DEFAULT, **d.get("what", {})}
    return cfg


def save(data_dir: Path, cfg: dict) -> None:
    f = config_file(data_dir)
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, f)


def computer_name() -> str:
    return "".join(c if c.isalnum() or c in " -_" else "_" for c in (platform.node() or "This computer")).strip() or "This computer"


# ---------------------------------------------------------------- finding cloud folders

def detect(home: Path | None = None, env: dict | None = None, drives: list[str] | None = None) -> list[dict]:
    """Cloud storage apps installed on this computer, with the folder each keeps in sync."""
    home = Path(home or Path.home())
    env = os.environ if env is None else env
    found: list[dict] = []

    def add(kind, name, path):
        p = Path(path)
        if p.is_dir() and not any(Path(f["path"]) == p for f in found):
            found.append({"kind": kind, "name": name, "path": str(p)})

    if sys.platform == "darwin":
        from .macos import cloud_folders, volumes
        for kind, name, path in cloud_folders(home):
            add(kind, name, path)
        for v in (drives if drives is not None else volumes()):
            add("drive", Path(v).name, v)
    for var, name in (("OneDriveConsumer", "OneDrive"), ("OneDrive", "OneDrive"), ("OneDriveCommercial", "OneDrive for work")):
        if env.get(var):
            add("onedrive", name, env[var])
    for p in sorted(home.glob("OneDrive*")):
        add("onedrive", "OneDrive" if p.name == "OneDrive" else p.name.replace("OneDrive - ", "OneDrive: "), p)

    for base in (env.get("LOCALAPPDATA"), env.get("APPDATA")):  # Dropbox writes where its folder is
        if base:
            try:
                info = json.loads((Path(base) / "Dropbox" / "info.json").read_text(encoding="utf-8"))
                for k, v in info.items():
                    if isinstance(v, dict) and v.get("path"):
                        add("dropbox", "Dropbox" if k == "personal" else f"Dropbox ({k})", v["path"])
            except (OSError, ValueError):
                pass
    add("dropbox", "Dropbox", home / "Dropbox")

    # Google Drive for desktop shows up as a drive letter with "My Drive" in it
    letters = drives if drives is not None else ([f"{c}:\\" for c in "DEFGHIJKLMNOPQRSTUVWXYZ"] if os.name == "nt" else [])
    for root in letters:
        add("gdrive", "Google Drive", Path(root) / "My Drive")
    add("gdrive", "Google Drive", home / "Google Drive" / "My Drive")
    add("gdrive", "Google Drive", home / "Google Drive")
    add("gdrive", "Google Drive", home / "My Drive")

    add("icloud", "iCloud Drive", home / "iCloudDrive")
    add("box", "Box", home / "Box")
    return found


INSTALL_LINKS = {
    "onedrive": ("OneDrive", "https://www.microsoft.com/microsoft-365/onedrive/download"),
    "gdrive": ("Google Drive", "https://www.google.com/drive/download/"),
    "dropbox": ("Dropbox", "https://www.dropbox.com/install"),
    "icloud": ("iCloud Drive", "https://support.apple.com/en-us/103232"),
    "box": ("Box", "https://www.box.com/resources/downloads"),
}


# ---------------------------------------------------------------- linking

def link(data_dir: Path, folder: str | os.PathLike, name: str = "", kind: str = "folder") -> dict:
    folder = Path(folder)
    if not folder.is_dir():
        raise ValueError(f"folder not found: {folder}")
    cfg = load(data_dir)
    target = folder if folder.name == FOLDER else folder / FOLDER
    for d in cfg["destinations"]:
        if Path(d["path"]) == target:
            return d
    dest = {"id": secrets.token_hex(3), "name": name or folder.name or str(folder), "kind": kind,
            "path": str(target), "what": dict(WHAT_DEFAULT), "linked": time.strftime("%Y-%m-%d %H:%M"), "last": {}}
    cfg["destinations"].append(dest)
    save(data_dir, cfg)
    return dest


def unlink(data_dir: Path, dest_id: str) -> None:
    """Stop backing up there. The backup already made stays where it is."""
    cfg = load(data_dir)
    cfg["destinations"] = [d for d in cfg["destinations"] if d["id"] != dest_id]
    save(data_dir, cfg)


def set_what(data_dir: Path, dest_id: str, what: dict) -> dict:
    cfg = load(data_dir)
    for d in cfg["destinations"]:
        if d["id"] == dest_id:
            d["what"].update({k: bool(v) for k, v in what.items() if k in WHAT_DEFAULT})
            save(data_dir, cfg)
            return d
    raise ValueError("no such backup place")


def _record(data_dir: Path, dest_id: str, **last) -> None:
    cfg = load(data_dir)
    for d in cfg["destinations"]:
        if d["id"] == dest_id:
            d["last"] = {**d.get("last", {}), **last}
    save(data_dir, cfg)


# ---------------------------------------------------------------- copying

def _same(src: os.stat_result, dst: Path) -> bool:
    try:
        st = dst.stat()
    except OSError:
        return False
    return st.st_size == src.st_size and abs(st.st_mtime - src.st_mtime) < 2.5  # FAT/exFAT keep 2-second times


def copy_file(src: Path, dst: Path) -> bool:
    """Copy if the backup doesn't already hold this exact file. True = copied."""
    st = src.stat()
    if _same(st, dst):
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_name(dst.name + ".pvtmp")
    shutil.copy2(src, tmp)
    os.replace(tmp, dst)
    return True


def _walk(root: Path, only_sets: bool):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d.lower() not in SKIP_DIRS and d != FOLDER]
        for f in filenames:
            low = f.lower()
            if f.startswith("._") or low.endswith(SKIP_SUFFIXES) or low.endswith(".pvtmp"):
                continue
            if only_sets and not low.endswith(".als"):
                continue
            yield Path(dirpath) / f


def _label(folder: Path) -> str:
    return "".join(c if c.isalnum() or c in " -_." else "_" for c in folder.name) or "Projects"


def plan(data_dir: Path, dest: dict, project_folders: list[Path]):
    """(source, target) pairs this backup covers."""
    base = Path(dest["path"]) / computer_name()
    what = dest["what"]
    data_dir = Path(data_dir)
    if what.get("versions"):
        hist = data_dir / "history"
        for f in _walk(hist, False) if hist.is_dir() else ():
            if f.suffix.lower() in (".als", ".json") and f.parent != hist:
                yield f, base / "Versions" / f.relative_to(hist)
    if what.get("sounds"):
        lib = data_dir / "plugin_library"
        for f in _walk(lib, False) if lib.is_dir() else ():
            yield f, base / "Sounds" / f.relative_to(lib)
    for folder in project_folders:
        folder = Path(folder)
        if not folder.is_dir():
            continue
        if what.get("projects"):
            for f in _walk(folder, False):
                yield f, base / "Projects" / _label(folder) / f.relative_to(folder)
        elif what.get("songs"):
            for f in _walk(folder, True):
                yield f, base / "Songs" / _label(folder) / f.relative_to(folder)


def run(data_dir: Path, project_folders: list[Path], dest_ids: list[str] | None = None, out=print) -> int:
    """Bring each backup up to date. Returns how many places failed."""
    cfg = load(data_dir)
    dests = [d for d in cfg["destinations"] if not dest_ids or d["id"] in dest_ids]
    if not dests:
        out("No backup places linked yet. Link one in Storage (python -m project_vault backup add <folder>).")
        return 0
    failed = 0
    for d in dests:
        target = Path(d["path"])
        out(f"Backing up to {d['name']}: {target}")
        if not target.parent.is_dir():
            out(f"  Can't reach {target.parent}. Is {d['name']} still installed and signed in?")
            _record(data_dir, d["id"], at=time.strftime("%Y-%m-%d %H:%M"), error="folder not reachable")
            failed += 1
            continue
        copied = skipped = errors = 0
        size = 0
        started = time.time()
        for src, dst in plan(data_dir, d, project_folders):
            try:
                if copy_file(src, dst):
                    copied += 1
                    size += src.stat().st_size
                    if copied % 200 == 0:
                        out(f"  {copied:,} files copied ({size / 1e6:,.0f} MB)...")
                else:
                    skipped += 1
            except OSError as e:
                errors += 1
                if errors <= 10:
                    out(f"  couldn't copy {src}: {e.strerror or e}")
                if getattr(e, "errno", None) == 28:  # disk full
                    out("  The backup place is full; stopped.")
                    break
        secs = time.time() - started
        out(f"  {copied:,} copied ({size / 1e6:,.1f} MB), {skipped:,} already backed up"
            + (f", {errors} couldn't be copied" if errors else "") + f"  [{secs:.0f}s]")
        _record(data_dir, d["id"], at=time.strftime("%Y-%m-%d %H:%M"), copied=copied, mb=round(size / 1e6, 1),
                error=f"{errors} files couldn't be copied" if errors else "")
        failed += bool(errors)
    return failed


def after_snapshot(data_dir: Path, version: Path, song: Path, project_folders: list[Path]) -> int:
    """Called by the watcher right after a version is kept: copy it (and the song) to every
    linked place. Quick (two small files per place) and never raises."""
    n = 0
    try:
        cfg = load(data_dir)
    except Exception:
        return 0
    hist = Path(data_dir) / "history"
    for d in cfg["destinations"]:
        try:
            if not Path(d["path"]).parent.is_dir():
                continue
            base = Path(d["path"]) / computer_name()
            if d["what"].get("versions"):
                for f in (version, version.parent / "project.json"):
                    if f.exists():
                        n += copy_file(f, base / "Versions" / f.relative_to(hist))
            if d["what"].get("songs") or d["what"].get("projects"):
                for folder in project_folders:
                    try:
                        rel = Path(song).relative_to(folder)
                    except ValueError:
                        continue
                    kind = "Projects" if d["what"].get("projects") else "Songs"
                    n += copy_file(Path(song), base / kind / _label(Path(folder)) / rel)
                    break
            _record(data_dir, d["id"], at=time.strftime("%Y-%m-%d %H:%M"), error="")
        except Exception as e:  # a backup problem must never stop history being kept
            try:
                _record(data_dir, d["id"], error=f"{type(e).__name__}: {e}")
            except Exception:
                pass
    return n
