"""Guided resave: open each old (Live 8/9) copy in Live, wait until it's saved as a newer set, move on.

Live 12 can't take a VST3 plugin inside a Live 8/9 set, so those copies must be saved once in
Live 12 before swap can finish them. Saving can only be done inside Live, so this walks the
person through it: it opens the copy (Windows hands .als files to the running Live), shows the
clicks, and watches the file. As soon as the file on disk says it was saved by Live 10 or newer,
it opens the next one. Nothing is changed by Project Vault itself; only copies are opened.
"""
from __future__ import annotations

import gzip
import os
import re
import sys
import threading
import time
from pathlib import Path
from typing import Callable

STEPS = ("In Live: File > Save Live Set As..., click Save, then Yes if it asks to replace it.\n"
         "      (Live asks this way because the set is from an older version.)")


def saved_by(path: str | os.PathLike) -> int:
    """Major Live version that last saved this set (0 if it can't be read right now)."""
    try:
        with gzip.open(path, "rb") as f:
            head = f.read(2048).decode("utf-8", "replace")
    except (OSError, EOFError):
        return 0  # missing, or Live is still writing it
    m = re.search(r'Creator="Ableton Live (\d+)', head)
    return int(m.group(1)) if m else 0


def saved_copy(path: str | os.PathLike, need: int = 10) -> str:
    """Where this set now is in a Live 10+ save: the file itself, or, for a set that wasn't inside a
    Live project folder, the copy Live's Save As put in a new "<name> Project" folder beside it."""
    p = Path(path)
    for cand in (p, p.parent / f"{p.stem} Project" / p.name):
        if saved_by(cand) >= need:
            return str(cand)
    return ""


def bring_live_to_front() -> None:
    """Put Live's window in front, so the save shortcut goes to Live and not to Project Vault."""
    if sys.platform == "darwin":
        from .macos import bring_live_to_front as mac_front
        mac_front()
        return
    if os.name != "nt":
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        found = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def each(hwnd, _):
            if user32.IsWindowVisible(hwnd):
                n = user32.GetWindowTextLengthW(hwnd)
                if n:
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(hwnd, buf, n + 1)
                    if re.search(r" - Ableton Live \d", buf.value):
                        found.append(hwnd)
            return True

        user32.EnumWindows(each, 0)
        if not found:
            return
        hwnd = found[0]
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        user32.keybd_event(0x12, 0, 0, 0)  # a tap of Alt lets this process hand over the foreground
        user32.keybd_event(0x12, 0, 2, 0)
        user32.SetForegroundWindow(hwnd)
    except Exception:
        pass


def open_in_live(path: str) -> bool:
    """Hand the set to Live the way a double-click would. False where that isn't possible."""
    if sys.platform == "darwin":
        from .macos import open_in_live as mac_open
        return mac_open(path)
    if hasattr(os, "startfile"):
        try:
            os.startfile(path)  # type: ignore[attr-defined]
            threading.Timer(2.5, bring_live_to_front).start()
            return True
        except OSError:
            return False
    return False


def _key_pressed() -> str:
    """A key pressed in this window (Windows), without waiting. '' if none."""
    try:
        import msvcrt  # type: ignore
    except ImportError:
        return ""
    if msvcrt.kbhit():
        return msvcrt.getwch().lower()
    return ""


def guide(paths: list[str], opener: Callable[[str], bool] = open_in_live,
          poll: float = 2.0, timeout: float | None = None, key: Callable[[], str] = _key_pressed,
          out: Callable[[str], None] = print, need: int = 10) -> tuple[list[str], list[str]]:
    """Walk through paths. Returns (saved, skipped). `timeout` (seconds per set) is for tests."""
    saved, skipped = [], []
    todo = [p for p in paths if not saved_copy(p, need)]
    done_before = len(paths) - len(todo)
    if done_before:
        out(f"{done_before} of {len(paths)} were already saved in a newer Live, skipping those.")
    if not todo:
        return saved, skipped
    out("While each one is open:  S = skip it,  Q = stop here (run resave again later to continue).\n")
    for i, path in enumerate(todo, 1):
        name = Path(path).name
        out(f"[{i}/{len(todo)}] {name}")
        if not opener(path):
            out(f"      Open it in Live yourself: {path}")
        out(f"      {STEPS}")
        start = time.monotonic()
        while True:
            if saved_copy(path, need):
                saved.append(path)
                out("      Saved. Next...\n")
                break
            k = key()
            if k == "s":
                skipped.append(path)
                out("      Skipped.\n")
                break
            if k == "q":
                skipped.extend(p for p in todo[i - 1:])
                out("      Stopped.")
                return saved, skipped
            if timeout is not None and time.monotonic() - start > timeout:
                skipped.append(path)
                break
            time.sleep(poll)
    return saved, skipped


def run(paths: list[str], folder: str = "<your projects folder>") -> int:
    if not paths:
        print("Nothing to resave: every project can already be swapped.")
        return 0
    if not hasattr(os, "startfile"):
        print("(Opening sets automatically only works on Windows; the paths are shown instead.)")
    print(f"{len(paths)} project copy(ies) need one save in Live 12. Keep Live open.\n")
    try:
        saved, skipped = guide(paths)
    except KeyboardInterrupt:
        print("\nStopped. Run resave again later to continue where you left off.")
        return 1
    print(f"\nDone: {len(saved)} saved, {len(skipped)} skipped.")
    if saved:
        print("Next, so swap uses the newly saved copies:\n"
              f'  python -m project_vault scan "{folder}" --ignore-swapped\n'
              "  python -m project_vault swap --try-settings --replace")
    return 0 if not skipped else 1


# ------------------------------------------------------------------ the guided resave behind the window

class Session:
    """One set open in Live at a time, watched until Live 10+ has saved it, then the next one.

    The window asks for view() every couple of seconds; skip(), reopen() and stop() are its buttons.
    It never opens a set while another set in Live has unsaved changes (other than one it opened
    itself), so nothing the person is working on can be lost to Live's "save changes?" question.
    """

    def __init__(self, opener: Callable[[str], bool] = open_in_live,
                 live: Callable[[], tuple[str, bool] | None] = lambda: None,
                 poll: float = 1.5, need: int = 10):
        self.opener, self.live, self.poll, self.need = opener, live, poll, need
        self.lock = threading.Lock()
        self.state = "idle"  # idle | ready | running | waiting | done
        self.sets: list[dict] = []
        self.current = -1
        self.note = ""
        self.made = 0
        self.opened: set[str] = set()  # names of the sets this session opened in Live
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # -- the list
    def load(self, paths: list[str], made: int = 0) -> None:
        self.stop()
        with self.lock:
            self.sets = []
            for p in paths:
                at = saved_copy(p, self.need)
                self.sets.append({"path": p, "name": Path(p).stem, "folder": Path(p).parent.parent.name,
                                  "state": "saved" if at else "todo", "before": bool(at), "saved_to": at})
            self.made, self.current, self.note = made, -1, ""
            self.state = "done" if self.sets and self._next() is None else "ready" if self.sets else "idle"

    def _next(self) -> int | None:
        for i, s in enumerate(self.sets):
            if s["state"] in ("todo", "open"):
                return i
        return None

    def view(self) -> dict:
        with self.lock:
            counts = {k: sum(1 for s in self.sets if s["state"] == k) for k in ("todo", "open", "saved", "skipped")}
            return {"state": self.state, "current": self.current, "note": self.note, "made": self.made,
                    "sets": [dict(s) for s in self.sets], "total": len(self.sets),
                    "saved": counts["saved"], "skipped": counts["skipped"],
                    "left": counts["todo"] + counts["open"],
                    "before": sum(1 for s in self.sets if s["before"])}

    # -- buttons
    def start(self) -> dict:
        with self.lock:
            busy = self._thread is not None and self._thread.is_alive()
            if not busy:
                for s in self.sets:
                    if s["state"] == "skipped":  # starting again gives skipped sets another go
                        s["state"] = "todo"
                if self._next() is None:
                    self.state = "done" if self.sets else "idle"
                else:
                    self._stop.clear()
                    self.state = "running"
                    self._thread = threading.Thread(target=self._run, daemon=True)
                    self._thread.start()
        return self.view()

    def skip(self) -> dict:
        with self.lock:
            i = self.current
            if 0 <= i < len(self.sets) and self.sets[i]["state"] in ("todo", "open"):
                self.sets[i]["state"] = "skipped"
        return self.view()

    def reopen(self) -> dict:
        with self.lock:
            i = self.current
            path = self.sets[i]["path"] if 0 <= i < len(self.sets) and self.sets[i]["state"] == "open" else ""
        if path:
            self.opener(path)
        return self.view()

    def stop(self) -> dict:
        self._stop.set()
        t = self._thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=5)
        with self.lock:
            for s in self.sets:
                if s["state"] == "open":
                    s["state"] = "todo"
            if self.state in ("running", "waiting"):
                self.state = "ready"
            self.note = ""
        return self.view()

    # -- the loop
    def saved_paths(self) -> list[str]:
        """Each saved set where it is now (Live may have saved it into a new project folder)."""
        with self.lock:
            return [s.get("saved_to") or s["path"] for s in self.sets if s["state"] == "saved"]

    def _blocked_by(self) -> str:
        """The name of a set open in Live with unsaved changes that this session didn't open, else ''."""
        try:
            w = self.live()
        except Exception:
            return ""
        if w and w[1] and w[0].lower() not in self.opened:
            return w[0]
        return ""

    def _run(self) -> None:
        while not self._stop.is_set():
            with self.lock:
                i = self._next()
                if i is None:
                    self.state, self.current, self.note = "done", -1, ""
                    return
                self.current = i
                s = self.sets[i]
                path, opening = s["path"], s["state"] == "todo"
            at = saved_copy(path, self.need)
            if at:
                with self.lock:
                    s["state"], s["saved_to"] = "saved", at
                continue
            if opening:
                other = self._blocked_by()
                if other:
                    with self.lock:
                        self.state = "waiting"
                        self.note = (f"\u201c{other}\u201d has unsaved changes in Live. Save it (or close it) and "
                                     "the next set opens by itself.")
                    self._stop.wait(self.poll)
                    continue
                with self.lock:
                    self.state, self.note = "running", ""
                    s["state"] = "open"
                    self.opened.add(s["name"].lower())
                ok = self.opener(path)
                with self.lock:
                    s["opened"] = ok
                    if not ok:
                        self.note = "Couldn't hand it to Live. Open it yourself from the folder button."
            self._stop.wait(self.poll)
