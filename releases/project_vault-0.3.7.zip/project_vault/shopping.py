"""Turn plugin-check results into a shopping / reinstall list grouped by company."""
from __future__ import annotations

import html
import re
from collections import defaultdict
from datetime import date
from urllib.parse import quote_plus

# Well-known plugins -> company. Matched against the plugin name and its old install path.
# Only entries we are sure of; anything else falls back to a hint from the old folder name.
VENDORS = [
    (r"serum|lfotool|cthulhu|\bott\b|xfer", "Xfer Records"),
    (r"fabfilter|fab filter|^pro-(q|c|l|mb|r|ds|g)\b|^simplon|^saturn|^timeless|^volcano", "FabFilter"),
    (r"spire|reveal sound", "Reveal Sound"),
    (r"arturia|minimoog v|prophet|arp 2600|jupiter-8|pigments|analog lab|solina|cs-80|mini v|"
     r"sem v|matrix-12|synclavier|dx7 v|cz v|buchla", "Arturia"),
    (r"native instruments|massive|guitar ?rig|\braum\b|replika|\bfm[78]\b|kontakt|solid bus comp|"
     r"solid eq|reaktor|absynth|monark|supercharger|transient master|battery", "Native Instruments"),
    (r"albino|morphox|cronox|linplug", "LinPlug"),
    (r"predator|subboombass|rp-distort|rob papen|\bblue\b|vectorizer|sublime", "Rob Papen"),
    (r"sylenth", "LennarDigital"),
    (r"effectrix|\bwow\d?\b|turnado|obscurium|cyclop|looperator|thesys|sugar bytes", "Sugar Bytes"),
    (r"sausage fat+ener|endless ?smile|dada life", "Dada Life"),
    (r"bark ?of ?dog|boz digital", "Boz Digital Labs"),
    (r"kickstart", "Nicky Romero"),
    (r"rhythmizer", "Futurephonic"),
    (r"izotope|\biris\b|trash ?2|ozone|neutron|nectar", "iZotope"),
    (r"camelphat|alchemy|camel audio", "Camel Audio (discontinued, now part of Apple)"),
    (r"waves|waveshell|maxxbass|oneknob|\bc6\b|cla bass|center stereo|renaissance|h-delay|"
     r"x-noise|inphase", "Waves"),
    (r"^bx_|black box analog|plugin alliance", "Plugin Alliance"),
    (r"gladiator|electrax|tone2", "Tone2"),
    (r"vanguard", "reFX"),
    (r"toxic biohazard", "Image-Line"),
    (r"stylus ?rmx", "Spectrasonics"),
    (r"trackspacer", "Wavesfactory"),
    (r"^khs |kilohearts", "Kilohearts"),
    (r"gatekeeper|manipulator|^wider$|polyverse", "Polyverse"),
    (r"^thermal$", "Output"),
    (r"^dseq", "Tokyo Dawn Labs"),
    (r"^dsk ", "DSK Music"),
    (r"key ?detector", "Key Detector"),
    (r"novation|ultranova", "Novation"),
    (r"^ace$|diva|hive|repro|zebra|bazille|satin|presswerk|uhbik|u-he", "u-he"),
    (r"morphine", "Image-Line"),
    (r"truepianos", "4Front"),
    (r"largo|waldorf", "Waldorf"),
    (r"sonivox|orchestral ?companion", "SONiVOX"),
    (r"samplitude|am-phibia|am-track|filtox", "MAGIX (Samplitude FX)"),
    (r"the drop|cytomic", "Cytomic"),
    (r"cakewalk|z3ta", "Cakewalk / BandLab"),
    (r"omnisphere|trilian|keyscape|spectrasonics", "Spectrasonics"),
    (r"^ambience$", "Smartelectronix"),
    (r"valhalla", "Valhalla DSP"),
    (r"soundtoys|decapitator|echoboy|panman|tremolator|crystallizer|microshift", "Soundtoys"),
    (r"nexus|refx", "reFX"),
    (r"kick ?2|ana ?2|sonic academy", "Sonic Academy"),
    (r"shaperbox|cableguys|volumeshaper", "Cableguys"),
    (r"comeback ?kid|spaced ?out|parallel aggressor|baby audio", "Baby Audio"),
    (r"klevgrand|grandfinale", "Klevgrand"),
    (r"^air[a-z]|air music", "AIR Music Technology"),
    (r"ds-10|xln", "XLN Audio"),
    (r"pitch ?monster|devious", "Devious Machines"),
    (r"theriser|the riser", "Image Sounds"),
    (r"glitch2?|illformed|dblue", "Illformed"),
]

# Each company's own website (only ones we're sure of). Others get a web search instead.
VENDOR_SITES = {
    "Xfer Records": "https://xferrecords.com",
    "FabFilter": "https://www.fabfilter.com",
    "Reveal Sound": "https://www.revealsound.com",
    "Arturia": "https://www.arturia.com",
    "Native Instruments": "https://www.native-instruments.com",
    "LinPlug": "https://www.linplug.com",
    "Rob Papen": "https://www.robpapen.com",
    "LennarDigital": "https://www.lennardigital.com",
    "Sugar Bytes": "https://sugar-bytes.com",
    "Boz Digital Labs": "https://www.bozdigitallabs.com",
    "iZotope": "https://www.izotope.com",
    "Waves": "https://www.waves.com",
    "Plugin Alliance": "https://www.plugin-alliance.com",
    "Tone2": "https://www.tone2.com",
    "reFX": "https://refx.com",
    "Image-Line": "https://www.image-line.com",
    "Spectrasonics": "https://www.spectrasonics.net",
    "Wavesfactory": "https://www.wavesfactory.com",
    "Kilohearts": "https://kilohearts.com",
    "Polyverse": "https://polyversemusic.com",
    "Output": "https://output.com",
    "Tokyo Dawn Labs": "https://www.tokyodawn.net",
    "Novation": "https://novationmusic.com",
    "u-he": "https://u-he.com",
    "Waldorf": "https://waldorfmusic.com",
    "Valhalla DSP": "https://valhalladsp.com",
    "Soundtoys": "https://www.soundtoys.com",
    "Sonic Academy": "https://www.sonicacademy.com",
    "Cytomic": "https://cytomic.com",
    "Baby Audio": "https://babyaud.io",
    "Klevgrand": "https://klevgrand.com",
    "AIR Music Technology": "https://www.airmusictech.com",
    "XLN Audio": "https://www.xlnaudio.com",
    "Devious Machines": "https://www.deviousmachines.com",
    "Illformed": "https://illformed.com",
}

SEARCH = "https://www.google.com/search?q="


def search_link(name: str, vendor: str = "") -> str:
    return SEARCH + quote_plus(" ".join(x for x in (name, vendor, "plugin download") if x))


GENERIC_FOLDERS = {
    "c:", "e:", "d:", "program files", "program files (x86)", "vstplugins", "vst plugins", "vst",
    "vst2", "vst3", "plugins", "plug-ins", "effects", "effect", "fx", "synths", "synth", "vsts",
    "instruments", "common files", "steinberg", "library", "audio", "x64", "64bit", "32bit",
    "data", "offline",
}


def vendor_for(name: str, old_files: list[str]) -> tuple[str, bool]:
    """(company, sure). When not sure, returns a hint taken from the old install folder."""
    haystacks = [name.lower()] + [f.lower() for f in old_files]
    for pattern, vendor in VENDORS:
        if any(re.search(pattern, h) for h in haystacks):
            return vendor, True
    # Fall back to a hint only for the common layout ".../<Company>/<Product folder>/<plugin>.dll",
    # where the product folder is named after the plugin, so a shared folder isn't mistaken for a company.
    plug = re.sub(r"[^a-z]", "", name.lower())[:4]
    for f in old_files:
        parts = [x for x in f.replace("\\", "/").split("/")[:-1] if x]
        for i in range(len(parts) - 1):
            company, product = parts[i], parts[i + 1]
            if (company.lower() not in GENERIC_FOLDERS and plug
                    and plug in re.sub(r"[^a-z]", "", product.lower())
                    and plug not in re.sub(r"[^a-z]", "", company.lower())):
                return company, False
    return "", False


STATUS_TEXT = {
    "different version installed": ("Older version of one you have",
                                    "You have {found}. Your songs need this older version, which "
                                    "vendors often offer in your account's download page."),
    "only VST3 installed": ("Reinstall with VST2", "You have the VST3. Re-run the installer and tick VST2."),
    "only VST2 installed": ("Reinstall with VST3", "You have the VST2. Re-run the installer and tick VST3."),
    "only VST installed": ("Reinstall with Audio Unit", "You have {found} as a VST. Your songs use the Audio Unit: "
                           "re-run its installer and tick AU (Audio Unit)."),
    "missing": ("Not installed", "Reinstall it if you still own it, or buy a new copy."),
}


def _found_name(path: str) -> str:
    return re.sub(r"\.(dll|vst3|vst|component)$", "", path.replace("\\", "/").rsplit("/", 1)[-1], flags=re.I)


def build_list(results, only_missing_counts: dict) -> list[dict]:
    items = []
    for r in results:
        if r.status not in STATUS_TEXT:
            continue
        from .plugin_check import free_older_version
        vendor, sure = vendor_for(r.name, r.old_files)
        label, advice = STATUS_TEXT[r.status]
        free = free_older_version(r.name) if r.status == "different version installed" else ""
        if free:
            label, advice = "Free with the version you have", free
        items.append({
            "name": r.name, "format": r.fmt, "projects": r.projects,
            "only_thing": only_missing_counts.get((r.name, r.fmt), 0),
            "vendor": vendor if sure else "", "folder_hint": "" if sure else vendor,
            "status": r.status, "label": label,
            "advice": advice.format(found=_found_name(r.found_at)) if r.found_at else advice,
            "examples": [n.replace(" (relinked)", "") for n in r.project_names[:5]],
            "search": search_link(r.name, vendor if sure else ""),
            "site": VENDOR_SITES.get(vendor, "") if sure else "",
        })
    return items


def write_html(items: list[dict], path: str, total_projects: int, ready: int) -> None:
    groups = defaultdict(list)
    for it in items:
        groups[it["vendor"] or "Company unknown"].append(it)
    order = sorted(groups, key=lambda v: (v == "Company unknown", -sum(i["projects"] for i in groups[v])))
    e = html.escape
    unit = items[0].get("unit", "project") if items else "project"  # the window counts songs

    def card(it):
        hint = f' <span class="hint">(was installed in a folder named “{e(it["folder_hint"])}”)</span>' \
            if it["folder_hint"] else ""
        win = (f'<span class="win">Only thing missing in {it["only_thing"]} {unit}'
               f'{"s" if it["only_thing"] != 1 else ""}</span>') if it["only_thing"] else ""
        ex = ", ".join(e(x) for x in it["examples"])
        more = f" and {it['projects'] - len(it['examples'])} more" if it["projects"] > len(it["examples"]) else ""
        return f"""<li class="item">
  <label><input type="checkbox"> <b>{e(it["name"])}</b> <span class="fmt">{e(it["format"])}</span></label>{hint}
  <div class="meta"><span class="tag {e(it["status"].split()[0])}">{e(it["label"])}</span>
    <span>{it["projects"]} {unit}{"s" if it["projects"] != 1 else ""}</span> {win}
    <a href="{e(it["search"])}" target="_blank" rel="noopener">Find it</a></div>
  <div class="advice">{e(it["advice"])}</div>
  <div class="ex">Used in: {ex}{more}</div>
</li>"""

    def site(v):
        u = next((i.get("site") for i in groups[v] if i.get("site")), "")
        return f' <a class="site" href="{e(u)}" target="_blank" rel="noopener">{e(u.split("//", 1)[-1])}</a>' if u else ""

    sections = "\n".join(
        f'<section><h2>{e(v)} <span class="count">{len(groups[v])} plugin{"s" if len(groups[v]) != 1 else ""}'
        f' · used in {sum(i["projects"] for i in groups[v])} {unit}s</span>{site(v)}</h2><ul>'
        + "\n".join(card(i) for i in sorted(groups[v], key=lambda i: (-i["only_thing"], -i["projects"])))
        + "</ul></section>" for v in order)
    wins = sorted((i for i in items if i["only_thing"]), key=lambda i: -i["only_thing"])[:10]
    win_rows = "".join(f'<li><b>{e(i["name"])}</b> <span class="fmt">{e(i["format"])}</span> '
                       f'completes {i["only_thing"]} {unit}{"s" if i["only_thing"] != 1 else ""}</li>'
                       for i in wins)

    page = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Plugin shopping list · Project Vault</title>
<style>
:root {{ --ink:#1d1d1f; --mute:#6b6b70; --line:#e4e4e8; --bg:#fafafa; --card:#fff; --accent:#3d5afe;
        --old:#8a5a00; --oldbg:#fff4dc; --miss:#b3261e; --missbg:#fdecea; --fmt:#0b6e4f; --fmtbg:#e3f5ec; }}
* {{ box-sizing:border-box }}
body {{ margin:0; font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif; color:var(--ink); background:var(--bg) }}
main {{ max-width:860px; margin:0 auto; padding:40px 20px 80px }}
h1 {{ font-size:28px; margin:0 0 6px }} .sub {{ color:var(--mute); margin:0 0 28px }}
.summary {{ display:flex; gap:12px; flex-wrap:wrap; margin-bottom:28px }}
.stat {{ background:var(--card); border:1px solid var(--line); border-radius:10px; padding:12px 16px; min-width:150px }}
.stat b {{ display:block; font-size:22px }} .stat span {{ color:var(--mute); font-size:13px }}
.wins {{ background:var(--card); border:1px solid var(--line); border-radius:10px; padding:16px 20px; margin-bottom:32px }}
.wins h2 {{ margin:0 0 8px; font-size:17px }} .wins ol {{ margin:0; padding-left:20px }}
section h2 {{ font-size:19px; margin:34px 0 10px; padding-bottom:6px; border-bottom:1px solid var(--line) }}
.count {{ color:var(--mute); font-weight:400; font-size:13px; margin-left:6px }}
ul {{ list-style:none; padding:0; margin:0 }}
.item {{ background:var(--card); border:1px solid var(--line); border-radius:10px; padding:12px 16px; margin:8px 0 }}
.item label {{ cursor:pointer }} .item input:checked + b {{ text-decoration:line-through; color:var(--mute) }}
.fmt {{ font-size:12px; color:var(--mute); border:1px solid var(--line); border-radius:4px; padding:0 5px; margin-left:4px }}
.meta {{ display:flex; gap:12px; flex-wrap:wrap; align-items:center; font-size:13px; color:var(--mute); margin-top:6px }}
.tag {{ border-radius:999px; padding:1px 9px; font-weight:600; font-size:12px }}
.tag.different {{ color:var(--old); background:var(--oldbg) }} .tag.missing {{ color:var(--miss); background:var(--missbg) }}
.tag.only {{ color:var(--fmt); background:var(--fmtbg) }}
.win {{ color:var(--ink); font-weight:600 }} a {{ color:var(--accent) }}
.advice {{ font-size:13px; margin-top:4px }} .ex {{ font-size:12px; color:var(--mute); margin-top:4px }}
.hint {{ font-size:12px; color:var(--mute) }}
h2 .site {{ float:right; font-size:13px; font-weight:600 }}
@media print {{ a {{ color:inherit; text-decoration:none }} .item {{ break-inside:avoid }} }}
</style></head><body><main>
<h1>Plugin shopping list</h1>
<p class="sub">Plugins your Ableton {unit}s use that aren't ready on this computer. Made by Project Vault on
{date.today():%B %d, %Y}. Tick items off as you go.</p>
<div class="summary">
  <div class="stat"><b>{ready} of {total_projects}</b><span>{unit}s have every plugin</span></div>
  <div class="stat"><b>{sum(1 for i in items if i["status"] == "different version installed")}</b><span>older versions of plugins you have</span></div>
  <div class="stat"><b>{sum(1 for i in items if i["status"].startswith("only"))}</b><span>need the other format</span></div>
  <div class="stat"><b>{sum(1 for i in items if i["status"] == "missing")}</b><span>not installed</span></div>
</div>
{f'<div class="wins"><h2>Biggest wins</h2><ol>{win_rows}</ol></div>' if win_rows else ""}
{sections}
</main></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(page)
