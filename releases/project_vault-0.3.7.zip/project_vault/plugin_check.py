"""Compare the plugins projects use with the plugins installed on this computer."""
from __future__ import annotations

import os
import re
import sys
from dataclasses import dataclass, field

# Common Windows plugin locations. More can be passed on the command line.
WIN_VST3 = [
    r"C:\Program Files\Common Files\VST3",
    r"C:\Program Files (x86)\Common Files\VST3",
]
WIN_VST2 = [
    r"C:\Program Files\VSTPlugins",
    r"C:\Program Files\VST Plugins",
    r"C:\Program Files\Steinberg\VSTPlugins",
    r"C:\Program Files\Common Files\VST2",
    r"C:\Program Files\Common Files\Steinberg\VST2",
    r"C:\Program Files (x86)\VstPlugins",
    r"C:\Program Files (x86)\Vst Plugins",
    r"C:\Program Files (x86)\Steinberg\VstPlugins",
]

if sys.platform == "darwin":
    from .macos import plugin_folders as _mac_folders
    _MAC = _mac_folders()
    DEFAULT_VST2, DEFAULT_VST3, DEFAULT_AU = _MAC["VST2"], _MAC["VST3"], _MAC["AU"]
else:
    DEFAULT_VST2, DEFAULT_VST3, DEFAULT_AU = WIN_VST2, WIN_VST3, []


def plugin_key(name: str) -> str:
    """'ValhallaVintageVerb_x64', 'Endless Smile 64.dll', 'Kick 2 x64' -> comparable keys."""
    n = name.lower().strip()
    n = re.sub(r"\.(dll|vst3|vst|component)$", "", n)
    n = re.sub(r"[\s_\-.(]*(x64|x86_64|64[\s_-]?bit|64)\)?$", "", n)
    return re.sub(r"[^a-z0-9]", "", n)


def plugin_family(name: str) -> str:
    """Name without version numbers or bitness: 'Spire-1.1' and 'Spire-1.5' -> 'spire'."""
    n = re.sub(r"\.(dll|vst3|vst|component)$", "", name.lower().strip())
    n = re.sub(r"[^a-z]", "", re.sub(r"\bv?\d+(\.\d+)*\b|x64|x86|\d+", "", n))
    return n if len(n) >= 3 else plugin_key(name)


@dataclass
class Installed:
    vst2: dict[str, str] = field(default_factory=dict)  # key -> .dll path
    vst3: dict[str, str] = field(default_factory=dict)  # key -> .vst3 path
    vst2_files: set[str] = field(default_factory=set)  # normalized full .dll paths
    au: dict[str, str] = field(default_factory=dict)  # key -> .component path (Mac)
    families: dict[str, str] = field(default_factory=dict)  # family -> one installed path
    searched: list[str] = field(default_factory=list)


def _norm(path: str) -> str:
    return path.replace("\\", "/").lower()


def find_installed(vst2_dirs: list[str], vst3_dirs: list[str], au_dirs: list[str] | None = None) -> Installed:
    """Plugins installed in these folders. On Windows a VST2 is a .dll; on a Mac every plugin is a
    bundle folder (.vst, .vst3, .component), and Audio Units count as their own format."""
    inst = Installed()
    bundles = (".vst3", ".vst", ".component")

    def add(kind: str, name: str, full: str) -> None:
        table = {"vst2": inst.vst2, "vst3": inst.vst3, "au": inst.au}[kind]
        table.setdefault(plugin_key(name), full)
        inst.families.setdefault(plugin_family(name), full)
        if kind == "vst2":
            inst.vst2_files.add(_norm(full))

    def walk(d: str, default_kind: str) -> None:
        if not os.path.isdir(d):
            return
        inst.searched.append(d)
        for dirpath, dirnames, files in os.walk(d):
            # a plugin can be a bundle folder; count it and don't look inside
            for name in [n for n in dirnames if n.lower().endswith(bundles)]:
                low = name.lower()
                kind = "vst3" if low.endswith(".vst3") else "au" if low.endswith(".component") else "vst2"
                add(kind, name, os.path.join(dirpath, name))
            dirnames[:] = [n for n in dirnames if not n.lower().endswith(bundles)]
            for f in files:
                low = f.lower()
                if low.endswith(".vst3"):  # some installers put VST3s in the VST2 folder too
                    add("vst3", f, os.path.join(dirpath, f))
                elif low.endswith(".dll") and default_kind == "vst2":
                    add("vst2", f, os.path.join(dirpath, f))

    for d in vst3_dirs:
        walk(d, "vst3")
    for d in vst2_dirs:
        walk(d, "vst2")
    for d in au_dirs or []:
        walk(d, "au")
    return inst


@dataclass
class PluginStatus:
    name: str
    fmt: str
    projects: int
    project_names: list[str]
    old_files: list[str]
    status: str  # installed / other format / missing
    found_at: str = ""


def check(usage_rows, inst: Installed) -> list[PluginStatus]:
    out = []
    for r in usage_rows:
        files = [f for f in (r["files"] or "").split(",") if f]
        keys = {plugin_key(r["name"])} | {plugin_key(f.replace("\\", "/").rsplit("/", 1)[-1]) for f in files}
        status, found = "missing", ""
        if r["format"] == "VST2":
            here = next((f for f in files if os.path.exists(f)), "")
            match = here or next((inst.vst2[k] for k in keys if k in inst.vst2), "")
            if match:
                status, found = "installed", match
            elif any(k in inst.vst3 for k in keys):
                status = "only VST3 installed"
                found = next(inst.vst3[k] for k in keys if k in inst.vst3)
        elif r["format"] == "VST3":
            match = next((inst.vst3[k] for k in keys if k in inst.vst3), "")
            if match:
                status, found = "installed", match
            elif any(k in inst.vst2 for k in keys):
                status = "only VST2 installed"
                found = next(inst.vst2[k] for k in keys if k in inst.vst2)
        elif r["format"] == "AU" and (inst.au or sys.platform == "darwin"):
            match = next((inst.au[k] for k in keys if k in inst.au), "")
            other = next((d[k] for d in (inst.vst3, inst.vst2) for k in keys if k in d), "")
            if match:
                status, found = "installed", match
            elif other:
                status, found = "only VST installed", other
        else:
            status = "not checked (AU)"
        if status == "missing":
            fam = plugin_family(r["name"])
            if fam in inst.families:
                status, found = "different version installed", inst.families[fam]
        out.append(PluginStatus(r["name"], r["format"], r["projects"],
                                sorted((r["project_names"] or "").split(",")), files, status, found))
    return out


# Older versions that come free with the newer one you own. Installing them beats any swap:
# projects open exactly as they were. Only vendor-confirmed cases (checked Nov 2026:
# support.xferrecords.com/article/62-can-i-still-purchase-serum-1).
FREE_OLDER_VERSIONS = {
    "serum": ("Serum 1 is included with Serum 2 bought from xferrecords.com: download it from your "
              "Xfer Records account. Got Serum 2 through Splice Rent-to-Own? Once it's paid off, Xfer "
              "adds a Serum 1 license to your account on request. With Serum 1 installed, projects "
              "open with their original Serum sounds and need no swap."),
}


def free_older_version(name: str) -> str:
    """Advice when this (missing) plugin is an older version included with a newer license."""
    return FREE_OLDER_VERSIONS.get(plugin_key(name), "")

