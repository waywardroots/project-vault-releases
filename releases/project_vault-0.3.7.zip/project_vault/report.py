"""Build a support report: one zip with what we need to fix a problem on someone else's computer.

Nothing is sent anywhere. The zip is written next to you, the person opens it to look,
and attaches it themselves. No audio, no project files: only text about the setup,
what Project Vault did, and (if asked for) the stored settings of one plugin.
Paths are shortened so the Windows user name doesn't appear.
"""
from __future__ import annotations

import csv
import gzip
import hashlib
import io
import os
import platform
import re
import sys
import time
import traceback
import zipfile
from collections import Counter
from pathlib import Path

from . import __version__

ERRORS_LOG = "errors.log"
HISTORY_LOG = "history.log"
MAX_SAMPLES = 20                # plugin settings samples per report
MAX_SAMPLE_BYTES = 4_000_000    # skip any single plugin block bigger than this
MAX_LOG_LINES = 400


# ---------------------------------------------------------------- privacy

class Redactor:
    """Replace the home folder with ~ and the Windows user name with <user>."""

    def __init__(self, home: str | None = None, user: str | None = None):
        home = home if home is not None else str(Path.home())
        user = user if user is not None else (os.environ.get("USERNAME") or os.environ.get("USER")
                                              or Path(home).name)
        variants = {home, home.replace("\\", "/"), home.replace("/", "\\")}
        self.home_re = re.compile("|".join(re.escape(v) for v in sorted(variants, key=len, reverse=True) if v),
                                  re.I) if home else None
        # Only whole words, and only names long enough not to hit ordinary words.
        self.user_re = re.compile(rf"(?<![A-Za-z0-9]){re.escape(user)}(?![A-Za-z0-9])", re.I) \
            if user and len(user) >= 3 else None

    def __call__(self, text: str) -> str:
        if self.home_re:
            text = self.home_re.sub("~", text)
        if self.user_re:
            text = self.user_re.sub("<user>", text)
        return text


# ---------------------------------------------------------------- logs kept between runs

def log_dir(db_path: str | os.PathLike) -> Path:
    return Path(db_path).parent


def log_command(db_path, argv: list[str], status: str) -> None:
    """One line per command run, so a report can show what happened before a problem."""
    try:
        with (log_dir(db_path) / HISTORY_LOG).open("a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  v{__version__}  {status:5s}  "
                    f"{' '.join(argv)}\n")
    except OSError:
        pass


def log_error(db_path, argv: list[str], exc: BaseException) -> Path | None:
    """Save the full error, so the person doesn't have to copy it from the window."""
    path = log_dir(db_path) / ERRORS_LOG
    try:
        with path.open("a", encoding="utf-8") as f:
            f.write(f"=== {time.strftime('%Y-%m-%d %H:%M:%S')}  v{__version__}  {' '.join(argv)}\n")
            f.write("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
            f.write("\n")
        return path
    except OSError:
        return None


def _tail(path: Path, lines: int = MAX_LOG_LINES) -> str:
    try:
        return "".join(path.read_text(encoding="utf-8", errors="replace").splitlines(True)[-lines:])
    except OSError:
        return ""


# ---------------------------------------------------------------- pieces of the report

def live_versions_installed() -> list[str]:
    """Live versions that have a settings folder on this computer."""
    roots = []
    if os.environ.get("APPDATA"):
        roots.append(Path(os.environ["APPDATA"]) / "Ableton")
    if sys.platform == "darwin":
        from .macos import ableton_dirs
        roots.extend(ableton_dirs())
    roots.append(Path.home() / "Library" / "Preferences" / "Ableton")
    found = set()
    for r in roots:
        if r.is_dir():
            found |= {p.name for p in r.glob("Live *") if p.is_dir()}
    return sorted(found)


def _read_csv(path: Path) -> list[dict]:
    try:
        with path.open(encoding="utf-8-sig", newline="") as f:
            return list(csv.DictReader(f))
    except (OSError, csv.Error, UnicodeDecodeError):
        return []


def summarize_reports(folder: Path) -> list[str]:
    """Counts from the last relink, plugin-check and swap reports in this folder."""
    out = []
    rows = _read_csv(folder / "relink_report.csv")
    if rows:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime((folder / "relink_report.csv").stat().st_mtime))
        out.append(f"relink_report.csv ({when}): {len(rows)} sample uses in "
                   f"{len({r.get('project file') for r in rows})} projects")
        for how, n in Counter(r.get("how it was matched", "") for r in rows).most_common(20):
            out.append(f"  {n:7d}  {how}")
    rows = _read_csv(folder / "plugin_report.csv")
    if rows:
        out.append(f"plugin_report.csv: {len(rows)} plugins")
        for st, n in Counter(r.get("status", "") for r in rows).most_common():
            out.append(f"  {n:7d}  {st}")
    rows = _read_csv(folder / "swap_report.csv")
    if rows:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime((folder / "swap_report.csv").stat().st_mtime))
        out.append(f"swap_report.csv ({when}): {len(rows)} swaps in "
                   f"{len({r.get('original file') for r in rows})} projects")
        out.append("  settings:")
        for st, n in Counter(_short(r.get("settings", "")) for r in rows).most_common(15):
            out.append(f"  {n:7d}  {st}")
        out.append("  swaps:")
        for (a, b), n in Counter((r.get("old plugin", ""), r.get("new plugin", "")) for r in rows).most_common(25):
            out.append(f"  {n:7d}  {a} -> {b}")
    return out


def _short(settings: str) -> str:
    """'translated (Frequency 80 Hz, ...)' -> 'translated' so counts group together."""
    return settings.split(" (")[0].strip()


def plugin_samples(db, text: str, limit: int = MAX_SAMPLES) -> list[tuple[str, str, str]]:
    """(file name, plugin name, <PluginDevice> XML) for one plugin, from different projects.
    These are the stored settings we need to learn how to carry them to another version."""
    from .swap import DESC_RE, DEVICE_RE, describe
    want = text.lower()
    seen_hash, seen_proj, out = set(), set(), []
    for row in db.projects_with_plugin(text):
        path = row["path"]
        if path in seen_proj or not os.path.isfile(path):
            continue
        seen_proj.add(path)
        try:
            xml = gzip.open(path, "rb").read().decode("utf-8", errors="replace")
        except (OSError, EOFError):
            continue
        for dev in DEVICE_RE.finditer(xml):
            block = dev.group(0)
            dm = DESC_RE.search(block)
            src = describe(dm.group(0)) if dm else None
            if not src or want not in src[0].lower() or len(block) > MAX_SAMPLE_BYTES:
                continue
            h = hashlib.sha1(dm.group(0).encode()).hexdigest()
            if h in seen_hash:
                continue
            seen_hash.add(h)
            name = re.sub(r'[<>:"/\\|?*]', "_", f"{len(out) + 1:02d} - {src[0]} ({src[1]}).xml")
            out.append((name, f"{src[0]} ({src[1]})", f"<!-- from: {row['name']} -->\n{block}\n"))
            if len(out) >= limit:
                return out
    return out


def installed_plugins() -> list[str]:
    from .plugin_check import DEFAULT_AU, DEFAULT_VST2, DEFAULT_VST3, find_installed
    inst = find_installed(DEFAULT_VST2, DEFAULT_VST3, DEFAULT_AU)
    lines = [f"Searched: {d}" for d in inst.searched]
    lines += [f"VST3  {Path(p).name}" for p in sorted(inst.vst3.values(), key=str.lower)]
    lines += [f"VST2  {Path(p).name}" for p in sorted(inst.vst2.values(), key=str.lower)]
    return lines


def project_section(db, text: str, folder: Path) -> list[str]:
    out = []
    projects = db.find_projects(text)[:3]
    if not projects:
        return [f"No project name contains {text!r}."]
    for p in projects:
        tracks, samples, plugins = db.project_detail(p["id"])
        out += [f"Project: {p['name']}", f"  file: {p['path']}", f"  made in: {p['live_version']}",
                f"  tempo: {p['tempo']}", f"  tracks: {len(tracks)}"]
        for t in tracks:
            out.append(f"    [{t['kind']}] {t['name']}: {t['devices']}")
        out.append(f"  plugins: {len(plugins)}")
        for pl in plugins:
            out.append(f"    {pl['name']} ({pl['format']}) on {pl['track_name']}")
        out.append(f"  samples: {len(samples)}")
        for s in samples[:300]:
            exists = "ok" if os.path.exists(s["path"]) else "MISSING"
            out.append(f"    {exists:7s} {s['file_name']}  ({s['track_name']})  {s['path']}")
        name = p["name"].lower()
        rel = [r for r in _read_csv(folder / "relink_report.csv") if r.get("project", "").lower() == name]
        if rel:
            out.append("  last relink:")
            out += [f"    {r.get('sample')}: {r.get('how it was matched')}  -> {r.get('found at')}" for r in rel]
        sw = [r for r in _read_csv(folder / "swap_report.csv")
              if Path(r.get("original file", "")).stem.lower().startswith(name)]
        if sw:
            out.append("  last swap:")
            out += [f"    {r.get('track')}: {r.get('old plugin')} -> {r.get('new plugin')}  [{r.get('settings')}]"
                    for r in sw]
        out.append("")
    return out


def crash_section() -> list[str]:
    from .crash_doctor import default_locations, diagnose, report
    usage, crash = default_locations()
    if not usage:
        return ["Live's usage logs weren't found."]
    lines: list[str] = []
    report(diagnose(usage, crash, last=5), out=lines.append)
    return lines


# ---------------------------------------------------------------- the zip

def build_report(db, db_path, out_path: Path, folder: Path, plugin: str | None = None,
                 project: str | None = None, note: str | None = None,
                 redact: Redactor | None = None, with_crashes: bool = True,
                 with_installed: bool = True) -> list[tuple[str, int]]:
    """Write the zip. Returns [(file name in zip, bytes)] so the person can see what's in it."""
    redact = redact or Redactor()
    files: dict[str, str] = {}

    def safe(label: str, fn):
        try:
            return fn()
        except Exception as e:  # a report must never fail because one part did
            return [f"({label} couldn't be read: {type(e).__name__}: {e})"]

    lines = [
        "Project Vault support report",
        f"made: {time.strftime('%Y-%m-%d %H:%M')}",
        f"Project Vault: {__version__}",
        f"Python: {sys.version.split()[0]}  ({platform.architecture()[0]})",
        f"System: {platform.platform()}",
        f"Live installed: {', '.join(live_versions_installed()) or 'not found'}",
        "",
    ]
    if note:
        lines += ["What happened (in your words):", f"  {note}", ""]
    st = safe("database", db.stats)
    if isinstance(st, dict):
        lines.append("Database:")
        lines += [f"  {k:15s} {v}" for k, v in st.items()]
        made_in = Counter(r[0] for r in db.conn.execute("SELECT live_version FROM projects"))
        lines.append("  projects made in:")
        lines += [f"  {n:7d}  {v or 'unknown'}" for v, n in made_in.most_common(10)]
        lines.append("")
    reports = safe("reports", lambda: summarize_reports(folder))
    if reports:
        lines += ["Last reports in " + str(folder) + ":"] + reports + [""]
    files["report.txt"] = "\n".join(lines) + "\n"

    usage = safe("plugins", lambda: [f"{r['name']},{r['format']},{r['projects']}" for r in db.plugin_counts()])
    files["plugins_used.csv"] = "plugin,format,projects\n" + "\n".join(usage) + "\n"
    if with_installed:
        files["plugins_installed.txt"] = "\n".join(safe("installed plugins", installed_plugins)) + "\n"
    if with_crashes:
        files["crashes.txt"] = "\n".join(safe("crash logs", crash_section)) + "\n"
    if project:
        files["project.txt"] = "\n".join(safe("project", lambda: project_section(db, project, folder))) + "\n"
    if plugin:
        samples = safe("plugin settings", lambda: plugin_samples(db, plugin))
        if samples and isinstance(samples[0], tuple):
            for name, _, xml in samples:
                files[f"plugin_settings/{name}"] = xml
        else:
            files["plugin_settings/none.txt"] = (
                "\n".join(samples) if samples else f"No scanned project uses a plugin named like {plugin!r}.") + "\n"
    for log in (ERRORS_LOG, HISTORY_LOG):
        text = _tail(log_dir(db_path) / log)
        if text:
            files[log] = text

    contents = []
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = out_path.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, text in files.items():
            data = redact(text).encode("utf-8")
            z.writestr(name, data)
            contents.append((name, len(data)))
    os.replace(tmp, out_path)
    return contents


def describe_contents(name: str) -> str:
    if name.startswith("plugin_settings/"):
        return "stored settings of that plugin from your projects (no audio)"
    return {
        "report.txt": "versions, totals and counts from your last relink/swap",
        "plugins_used.csv": "plugin names and how many projects use each",
        "plugins_installed.txt": "plugin file names installed on this computer",
        "crashes.txt": "Live's recent crashes and the plugins open at the time",
        "project.txt": "that project's tracks, devices, samples and last results",
        ERRORS_LOG: "errors Project Vault hit, with details",
        HISTORY_LOG: "the commands you ran, with dates",
    }.get(name, "")
