"""The Mac side of Project Vault's desktop pieces: Live's open set, opening files, the folder picker,
starting at login, and where Live and plugins keep things.

Everything here uses tools every Mac has (open, osascript, pgrep, launchctl), so nothing extra
needs installing. The Windows versions live next to their callers; callers ask IS_MAC first.
"""
from __future__ import annotations

import os
import plistlib
import re
import subprocess
import sys
from pathlib import Path

IS_MAC = sys.platform == "darwin"
LIVE_BUNDLE = "com.ableton.live"
AGENT_LABEL = "com.fuzzyaudio.projectvault"


def _run(args: list[str], timeout: float = 10) -> subprocess.CompletedProcess | None:
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return None


def osascript(script: str, timeout: float = 10) -> str | None:
    """Run AppleScript; its result as text, or None if it failed (or was refused permission)."""
    r = _run(["osascript", "-e", script], timeout)
    if r is None or r.returncode != 0:
        return None
    return r.stdout.rstrip("\n")


# ---------------------------------------------------------------- Live

def live_running() -> bool:
    r = _run(["pgrep", "-x", "Live"])
    return bool(r and r.returncode == 0 and r.stdout.strip())


# Live's window title on a Mac: "Song Name" or "Song Name*" (unsaved), sometimes followed by
# "  [Song Name Project]" and/or " - Ableton Live 12 Suite".
_TITLE = re.compile(r"^(.*?)(\*?)(?:\s+\[[^\]]*\])?(?:\s+-\s+Ableton Live.*)?$")


def parse_live_title(title: str) -> tuple[str, bool] | None:
    title = (title or "").strip()
    if not title or title.lower() in ("live", "ableton live") or title.startswith("Ableton Live"):
        return None
    m = _TITLE.match(title)
    if not m or not m.group(1).strip():
        return None
    name = m.group(1).strip()
    if name.lower().endswith(".als"):
        name = name[:-4]
    return name, bool(m.group(2))


def live_window() -> tuple[str, bool] | None:
    """(set open in Live, unsaved?) from Live's front window title. Needs the Accessibility
    permission for Project Vault (macOS asks once); without it this quietly answers None."""
    if not live_running():
        return None
    out = osascript('tell application "System Events" to tell (first process whose bundle identifier is '
                    f'"{LIVE_BUNDLE}") to get name of every window', timeout=5)
    if not out:
        return None
    for title in out.split(", "):
        got = parse_live_title(title)
        if got:
            return got
    return None


def bring_live_to_front() -> None:
    _run(["open", "-b", LIVE_BUNDLE])


def open_in_live(path: str) -> bool:
    """A Live Set opens in whichever Live opens .als files (the newest one, usually)."""
    r = _run(["open", "-b", LIVE_BUNDLE, path], timeout=20)
    if r is None or r.returncode != 0:
        r = _run(["open", path], timeout=20)
    return bool(r and r.returncode == 0)


# ---------------------------------------------------------------- files and folders

def open_path(path: str, reveal: bool = False) -> bool:
    """Open a file or folder like a double-click in Finder, or show it selected in Finder."""
    r = _run(["open", "-R", path] if reveal else ["open", path], timeout=20)
    return bool(r and r.returncode == 0)


def open_url(url: str) -> bool:
    r = _run(["open", url])
    return bool(r and r.returncode == 0)


def pick_folder(title: str = "Choose a folder") -> str:
    safe = title.replace("\\", "\\\\").replace('"', '\\"')
    out = osascript(f'POSIX path of (choose folder with prompt "{safe}")', timeout=600)
    return os.path.normpath(out) if out else ""


def volumes() -> list[str]:
    """Other drives: everything in /Volumes except the startup disk."""
    out = []
    try:
        for p in sorted(Path("/Volumes").iterdir()):
            if p.is_dir() and not p.is_symlink():  # the startup disk is a link to /
                out.append(str(p))
    except OSError:
        pass
    return out


# ---------------------------------------------------------------- where things are

def home() -> Path:
    return Path.home()


def plugin_folders(home_dir: Path | None = None) -> dict[str, list[str]]:
    """Where Mac plugins live: for everyone (/Library) and for this user (~/Library)."""
    h = home_dir or Path.home()
    dirs = {"VST2": [], "VST3": [], "AU": []}
    for root in (Path("/Library/Audio/Plug-Ins"), h / "Library" / "Audio" / "Plug-Ins"):
        dirs["VST2"].append(str(root / "VST"))
        dirs["VST3"].append(str(root / "VST3"))
        dirs["AU"].append(str(root / "Components"))
    return dirs


def ableton_dirs(home_dir: Path | None = None) -> list[Path]:
    """Live's preferences, logs and crash reports on a Mac."""
    h = home_dir or Path.home()
    return [h / "Library" / "Preferences" / "Ableton", h / "Library" / "Application Support" / "Ableton"]


def cloud_folders(home_dir: Path | None = None) -> list[tuple[str, str, Path]]:
    """(kind, name, folder) for the cloud storage apps' folders on a Mac."""
    h = home_dir or Path.home()
    found: list[tuple[str, str, Path]] = []
    cs = h / "Library" / "CloudStorage"
    try:
        entries = sorted(cs.iterdir()) if cs.is_dir() else []
    except OSError:
        entries = []
    for p in entries:
        n = p.name
        if n.startswith("OneDrive"):
            rest = n[len("OneDrive"):].lstrip("-")
            found.append(("onedrive", "OneDrive" if rest in ("", "Personal") else f"OneDrive: {rest}", p))
        elif n.startswith("GoogleDrive"):
            mine = p / "My Drive"
            found.append(("gdrive", "Google Drive", mine if mine.is_dir() else p))
        elif n.startswith("Dropbox"):
            found.append(("dropbox", "Dropbox", p))
        elif n.startswith("Box"):
            found.append(("box", "Box", p))
    icloud = h / "Library" / "Mobile Documents" / "com~apple~CloudDocs"
    found.append(("icloud", "iCloud Drive", icloud))
    found.append(("dropbox", "Dropbox", h / "Dropbox"))
    return found


# ---------------------------------------------------------------- start at login

def launch_agent_path(home_dir: Path | None = None) -> Path:
    return (home_dir or Path.home()) / "Library" / "LaunchAgents" / f"{AGENT_LABEL}.plist"


def write_launch_agent(args: list[str], workdir: str, home_dir: Path | None = None) -> Path:
    """Start Project Vault at login (a per-user LaunchAgent; no admin password)."""
    p = launch_agent_path(home_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    plist = {"Label": AGENT_LABEL, "ProgramArguments": args, "WorkingDirectory": workdir,
             "RunAtLoad": True, "KeepAlive": False, "ProcessType": "Interactive",
             "StandardErrorPath": str(Path(home_dir or Path.home()) / ".project_vault" / "agent.err.log")}
    p.write_bytes(plistlib.dumps(plist))
    return p


def remove_launch_agent(home_dir: Path | None = None) -> bool:
    p = launch_agent_path(home_dir)
    if not p.exists():
        return False
    p.unlink()
    return True


def launch_agent_args(home_dir: Path | None = None) -> list[str] | None:
    try:
        return list(plistlib.loads(launch_agent_path(home_dir).read_bytes()).get("ProgramArguments") or [])
    except (OSError, ValueError, plistlib.InvalidFileException):
        return None
