"""Find out which plugin is crashing Ableton Live, from Live's own logs, and write a copy of a
set without it so the set opens.

Live writes a usage log for every session (Live Reports/Usage/*.log). A session that ended
normally finishes with an "end" line; a crashed one just stops. The log lists every device
Live loads (device_add) and unloads (device_remove), so the last lines show what Live was
doing when it died:

  * crashed while the set was open, or while closing it: the plugins that were loaded then
    are the suspects;
  * crashed while opening another set: the closed set's plugins are not to blame.

Live also keeps <date>_CrashRecoveryInfo.cfg files that name the set that was open. Across
several crashes, the plugin present in all of them, and that rarely unloads cleanly anywhere
else, is the likely culprit.

Live's crash dump (.dmp) is often empty, so this works from the logs alone.
"""
from __future__ import annotations

import gzip
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

LINE_RE = re.compile(r"^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?)=([\w-]+)\s*(\{.*\})?\s*$")
THIRD_PARTY = ("VST2", "VST3", "AU", "AUv3", "CLAP")
SAFE_DIR = "Safe"


@dataclass
class Session:
    path: Path
    start: datetime | None = None
    end: datetime | None = None
    clean: bool = False
    running: bool = False
    phase: str = ""  # "while the set was open", "while closing a set", "while opening a set"
    suspects: list[tuple[str, str]] = field(default_factory=list)  # (name, format)
    opened: Counter = field(default_factory=Counter)  # plugin -> times loaded fine
    closed: Counter = field(default_factory=Counter)  # plugin -> times unloaded fine
    set_path: str = ""

    @property
    def crashed(self) -> bool:
        return not self.clean and not self.running and self.end is not None


def _ts(s: str) -> datetime:
    return datetime.fromisoformat(s[:26]).replace(tzinfo=timezone.utc)


def _session_start(path: Path) -> datetime | None:
    m = re.match(r"(\d{8}T\d{6})_", path.name)
    return datetime.strptime(m.group(1), "%Y%m%dT%H%M%S").replace(tzinfo=timezone.utc) if m else None


def read_session(path: Path) -> Session:
    s = Session(path=path, start=_session_start(path))
    s.running = Path(str(path) + ".lock").exists()
    events = []  # (time, kind, plugin) for plugins that actually ran
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        m = LINE_RE.match(line.strip())
        if not m:
            continue
        when, kind, payload = m.groups()
        s.end = _ts(when)
        if kind == "end":
            s.clean = True
            continue
        if kind not in ("device_add", "device_remove") or not payload:
            continue
        try:
            d = json.loads(payload)
        except ValueError:
            continue
        arch = d.get("device_architecture", "")
        if arch not in THIRD_PARTY or d.get("error"):  # "Plugin not loaded": never ran
            continue
        key = (d.get("device_name", ""), arch)
        events.append((when, kind, key))
        (s.opened if kind == "device_add" else s.closed)[key] += 1
    if not s.crashed:
        return s
    # Live logs a set's devices in one batch with a single time stamp when it finishes loading.
    # The set that was open is the last such batch, plus anything added by hand after it.
    batch_at = next((i for i in range(len(events) - 1, 0, -1)
                     if events[i][1] == "device_add" and events[i - 1][1] == "device_add"
                     and events[i][0] == events[i - 1][0]), None)
    if batch_at is None:
        s.phase = "while opening a set"
        return s
    start = batch_at
    while start > 0 and events[start - 1][1] == "device_add" and events[start - 1][0] == events[batch_at][0]:
        start -= 1
    loaded: Counter = Counter()
    removed_after = 0
    for _, kind, key in events[start:]:
        if kind == "device_add":
            loaded[key] += 1
        elif loaded[key] > 0:
            loaded[key] -= 1
            removed_after += 1
    still = sorted(k for k, n in loaded.items() if n > 0)
    if removed_after and not still:
        s.phase = "while opening a set"  # the old set unloaded fine; the new one never finished
    elif removed_after:
        s.phase = "while closing a set"
        s.suspects = still
    else:
        s.phase = "while the set was open"
        s.suspects = still
    return s


def recovery_sets(crash_dirs: list[Path]) -> list[tuple[datetime, str]]:
    """(local time Live noticed the crash, set that was open) from *_CrashRecoveryInfo.cfg."""
    out = []
    for d in crash_dirs:
        for f in d.glob("*_CrashRecoveryInfo.cfg"):
            m = re.match(r"(\d{4})_(\d\d)_(\d\d)__(\d\d)_(\d\d)_(\d\d)_", f.name)
            if not m:
                continue
            text = f.read_bytes().decode("utf-16-le", "replace")
            paths = [p for p in re.findall(r"(?:[A-Za-z]:|/Users)/[^\x00\ufffd]*?\.als", text)
                     if "/Preferences/" not in p.replace("\\", "/")]
            if paths:
                out.append((datetime(*map(int, m.groups())), paths[0]))
    return sorted(out)


def match_sets(sessions: list[Session], sets: list[tuple[datetime, str]]) -> None:
    """Pair each crash with the set Live offered to recover. Live names the recovery file with
    the local time of the next start, while the logs use UTC: try every time-zone offset and
    keep the one that lines up the most crashes with the start of the following session."""
    starts = [(i, s) for i, s in enumerate(sessions) if s.crashed and i + 1 < len(sessions)]
    if not starts or not sets:
        return
    best, best_hits = None, 0
    for quarter in range(-14 * 4, 14 * 4 + 1):
        off = timedelta(minutes=15 * quarter)
        hits = sum(1 for i, _ in starts for t, _ in sets
                   if abs((t - off).replace(tzinfo=timezone.utc) - sessions[i + 1].start) < timedelta(minutes=3))
        if hits > best_hits:
            best, best_hits = off, hits
    if best is None:
        return
    for i, s in starts:
        for t, p in sets:
            if abs((t - best).replace(tzinfo=timezone.utc) - sessions[i + 1].start) < timedelta(minutes=3):
                s.set_path = p


def default_locations() -> tuple[list[Path], list[Path]]:
    """Live's usage-log and crash-recovery folders on this computer (Windows and Mac)."""
    roots = []
    if os.environ.get("APPDATA"):
        roots.append(Path(os.environ["APPDATA"]) / "Ableton")
    if sys.platform == "darwin":
        from .macos import ableton_dirs
        roots.extend(ableton_dirs())
    home = Path.home()
    roots += [home / "Library" / "Application Support" / "Ableton", home / "Library" / "Preferences" / "Ableton"]
    usage = [r / "Live Reports" / "Usage" for r in roots if (r / "Live Reports" / "Usage").is_dir()]
    crash = [p for r in roots if r.is_dir() for p in r.glob("Live */Preferences/Crash") if p.is_dir()]
    return usage, crash


def diagnose(usage_dirs: list[Path], crash_dirs: list[Path], last: int = 10) -> dict:
    logs = sorted((p for d in usage_dirs for p in d.glob("*.log")), key=lambda p: p.name)
    sessions = [read_session(p) for p in logs]
    match_sets(sessions, recovery_sets(crash_dirs))
    crashes = [s for s in sessions if s.crashed][-last:]
    opened, closed, blamed = Counter(), Counter(), Counter()
    for s in sessions:
        opened.update(s.opened)
        closed.update(s.closed)
    for s in crashes:
        blamed.update(set(s.suspects))
    with_suspects = sum(1 for s in crashes if s.suspects)
    ranking = sorted(blamed, key=lambda k: (-blamed[k], closed[k], k))
    return {"sessions": sessions, "crashes": crashes, "ranking": ranking, "blamed": blamed,
            "with_suspects": with_suspects, "opened": opened, "closed": closed}


def report(result: dict, out=print, tz_local: bool = True) -> None:
    crashes = result["crashes"]
    if not crashes:
        out("No crashes found in Live's logs.")
        return
    out(f"{len(crashes)} crash(es) found in Live's logs:\n")
    for s in crashes:
        when = s.end.astimezone() if tz_local else s.end
        out(f"  {when:%Y-%m-%d %H:%M}  crashed {s.phase}")
        if s.set_path:
            out(f"      set: {s.set_path}")
        if s.suspects:
            out(f"      plugins loaded at the time: {', '.join(f'{n} [{f}]' for n, f in s.suspects)}")
        elif s.phase == "while opening a set":
            out("      the set being opened never finished loading; its plugins are the suspects")
    ranking = result["ranking"]
    if not ranking:
        return
    n = result["with_suspects"]
    out(f"\nMost likely culprits (loaded during the crash / times unloaded cleanly in other sessions):")
    for k in ranking[:8]:
        out(f"  {k[0]} [{k[1]}]: in {result['blamed'][k]} of {n} crash(es), "
            f"closed fine {result['closed'][k]} time(s) elsewhere")
    top = ranking[0]
    sets = {s.set_path for s in crashes if s.suspects}
    if len(ranking) > 1 and result["blamed"][top] == result["blamed"][ranking[1]]:
        why = "one set" if len(sets) <= 1 else "the same plugins"
        out(f"\nEvery crash involved {why}, so this is a short list rather than one name. Plugins near "
            "the top close cleanly less often elsewhere. To find the one, make test copies that each "
            "leave out one plugin, open each and close it: the copy that doesn't crash is missing the culprit.")
    target = next((s.set_path for s in reversed(crashes) if s.set_path), "SET.als")
    out("\nTest copies, one per suspect:")
    out(f'  python -m project_vault crash-doctor --safe "{target}" --each')
    out("A copy without one plugin:")
    out(f'  python -m project_vault crash-doctor --safe "{target}" --remove "{top[0]}"')


# ---- safe copy --------------------------------------------------------------------------
DEVICE_ANY_RE = re.compile(r"<(PluginDevice|AuPluginDevice)(?: Id=\"\d+\")?>.*?</\1>", re.S)


def plugins_in(als_path: str) -> list[tuple[str, str]]:
    from .als_reader import read_als
    return sorted({(p.name, p.fmt) for p in read_als(als_path).plugins})


def safe_copy(als_path: str, remove: list[str], dry_run: bool = False, tag: str = "") -> dict:
    """Write <project>/Safe/<name> (safe).als without the named plugins. The original is not
    touched; their VST2 settings are saved as preset files next to the copy."""
    from .layout import anchor_refs, base_stem, check_xml, home_dir
    from .plugin_check import plugin_key
    from .swap import TRACK_RE, describe, preset_from_desc

    als = Path(als_path)
    text = gzip.open(als, "rb").read().decode("utf-8")
    wanted = {plugin_key(r) for r in remove}
    tracks = []
    for m in TRACK_RE.finditer(text):
        n = re.search(r'<EffectiveName Value="([^"]*)"', text[m.start():m.start() + 4000])
        tracks.append((m.start(), n.group(1) if n else "?"))
    removed, targets, presets = [], set(), []

    def repl(m: re.Match) -> str:
        desc = re.search(r"<PluginDesc>.*?</PluginDesc>", m.group(0), re.S)
        d = describe(desc.group(0)) if desc else None
        if not d or plugin_key(d[0]) not in wanted:
            return m.group(0)
        track = next((n for pos, n in reversed(tracks) if pos < m.start()), "?")
        removed.append((track, d[0], d[1]))
        targets.update(re.findall(r'<(?:AutomationTarget|ModulationTarget) Id="(\d+)"', m.group(0)))
        exported = preset_from_desc(desc.group(0)) if d[1] == "VST2" else None
        if exported:
            stem = re.sub(r'[<>:"/\\|?*]', "_", f"{track} - {d[0]}")
            n = sum(1 for p, _ in presets if p.rsplit(".", 1)[0].split(" (")[0] == stem)
            presets.append((stem + (f" ({n + 1})" if n else "") + exported[0], exported[1]))
        return ""

    new = DEVICE_ANY_RE.sub(repl, text)
    lanes = 0
    if targets:
        def drop(env: re.Match) -> str:
            pid = re.search(r'<PointeeId Value="(\d+)"', env.group(0))
            return "" if pid and pid.group(1) in targets else env.group(0)
        before = len(re.findall(r"<(?:AutomationEnvelope|ClipEnvelope) ", new))
        new = re.sub(r"<AutomationEnvelope Id=\"\d+\">.*?</AutomationEnvelope>", drop, new, flags=re.S)
        new = re.sub(r"<ClipEnvelope Id=\"\d+\">.*?</ClipEnvelope>", drop, new, flags=re.S)
        lanes = before - len(re.findall(r"<(?:AutomationEnvelope|ClipEnvelope) ", new))
    home = home_dir(als) if als.parent.name != SAFE_DIR else als.parent.parent
    out = home / SAFE_DIR / f"{base_stem(als.stem)} (safe{tag}).als"
    result = {"output": str(out), "removed": removed, "lanes": lanes, "presets": [p for p, _ in presets]}
    if not removed:
        result["output"] = ""
        return result
    ET.fromstring(new.encode("utf-8"))  # never write a broken set
    new, _ = anchor_refs(new, als.parent)  # samples stay found from the Safe folder
    check_xml(new)
    if dry_run:
        return result
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(gzip.compress(new.encode("utf-8")))
    if presets:
        folder = out.parent / "Plugin settings" / base_stem(als.stem)
        folder.mkdir(parents=True, exist_ok=True)
        for name, data in presets:
            (folder / name).write_bytes(data)
    return result
