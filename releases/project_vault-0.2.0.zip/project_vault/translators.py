"""Translate settings between plugin versions that store them differently.

FabFilter plugins save their settings as "FFBS" + version + count + a list of 32-bit floats.
The order of that list differs between product versions, so handing one version's list to
another scrambles it. These translators rebuild the new version's list value by value.

Pro-Q 2 and Pro-Q 3 band layouts are based on Per Ivar Nerseth's PresetConverter
(MIT License, https://github.com/perivar/PresetConverter), checked against Pro-Q 3 data
saved by Ableton Live.
"""
from __future__ import annotations

import math
import struct

SHAPES = ["Bell", "Low Shelf", "Low Cut", "High Shelf", "High Cut", "Notch", "Band Pass", "Tilt Shelf"]
SLOPES = ["6", "12", "18", "24", "30", "36", "48", "72", "96"]


def _floats(chunk: bytes) -> tuple[bytes, int, list[float], bytes] | None:
    """Split a FabFilter chunk into (magic, version, values, trailing bytes)."""
    if len(chunk) < 12 or chunk[:4] not in (b"FFBS", b"FQ2p", b"FQ3p"):
        return None
    version, count = struct.unpack("<II", chunk[4:12])
    end = 12 + 4 * count
    if count == 0 or count > 5000 or len(chunk) < end:
        return None
    return chunk[:4], version, list(struct.unpack(f"<{count}f", chunk[12:end])), chunk[end:]


def _is_int(v: float, lo: int, hi: int) -> bool:
    return v == int(v) and lo <= v <= hi


PROQ2_PARAMS = 191  # automatable parameters Pro-Q 2 exposes to the host
_LOG2_10HZ, _LOG2_30KHZ = math.log2(10), math.log2(30000)


def proq2_from_params(chunk: bytes) -> bytes | None:
    """Older Live versions saved Pro-Q 2 as its host parameters (a 28-byte program name and 191
    values from 0 to 1) instead of FabFilter's own format. The parameters come in the same order
    as FabFilter's list, so rebuild that list from them: band state, frequency (10 Hz-30 kHz,
    log), gain (-30..+30 dB), Q (already 0-1), shape (8), slope (9) and stereo placement (3)."""
    if len(chunk) != 28 + 4 * PROQ2_PARAMS:
        return None
    p = list(struct.unpack(f"<{PROQ2_PARAMS}f", chunk[28:]))
    if not all(-1e-4 <= v <= 1.0001 for v in p):
        return None
    vals = []
    for b in range(24):
        state, freq, gain, q, shape, slope, stereo = p[b * 7:(b + 1) * 7]
        vals += [float(round(state * 2)), _LOG2_10HZ + freq * (_LOG2_30KHZ - _LOG2_10HZ), gain * 60 - 30,
                 q, float(round(shape * 7)), float(round(slope * 8)), float(round(stereo * 2))]
    tail = p[24 * 7:]
    tail[2] = float(round(tail[2]))  # channel mode: 0 = Left/Right, 1 = Mid/Side
    vals += tail
    return b"FFBS" + struct.pack("<II", 1, len(vals)) + struct.pack(f"<{len(vals)}f", *vals)


def proq2_bands(chunk: bytes) -> list[dict] | None:
    """Read Pro-Q 2's 24 bands (7 values each). Returns None if anything looks unexpected."""
    parsed = _floats(chunk) or _floats(proq2_from_params(chunk) or b"")
    if not parsed:
        return None
    _, _, vals, _ = parsed
    if len(vals) < 24 * 7 + 3:
        return None
    channel_mode = vals[24 * 7 + 2]  # 0 = Left/Right, 1 = Mid/Side
    if not _is_int(channel_mode, 0, 1):
        return None
    bands = []
    for b in range(24):
        state, freq, gain, q, shape, slope, stereo = vals[b * 7:(b + 1) * 7]
        if not (_is_int(state, 0, 2) and 3.0 <= freq <= 15.0 and -30.5 <= gain <= 30.5 and 0.0 <= q <= 1.0
                and _is_int(shape, 0, 7) and _is_int(slope, 0, 8) and _is_int(stereo, 0, 2)):
            return None
        is_default = abs(freq - math.log2(1000)) < 1e-3 and gain == 0 and shape == 0
        used = state == 1 or (state == 2 and not is_default)
        bands.append({"used": used, "enabled": state == 1, "freq": freq, "gain": gain, "q": q,
                      "shape": int(shape), "slope": int(slope), "stereo": int(stereo),
                      "mid_side": channel_mode == 1})
    return bands


def proq2_to_proq3(old_chunk: bytes, proq3_chunk: bytes) -> bytes | None:
    """Pro-Q 2 settings -> Pro-Q 3 settings. proq3_chunk is any real Pro-Q 3 state, used for the
    layout and for the values Pro-Q 2 has no equivalent for (dynamic EQ, solo, globals)."""
    bands = proq2_bands(old_chunk)
    target = _floats(proq3_chunk)
    if not bands or not target:
        return None
    magic, version, vals, trailing = target
    if len(vals) < 24 * 13:
        return None
    for b, band in enumerate(bands):
        base = b * 13
        if not band["used"]:  # Pro-Q 3's own unused-band defaults
            vals[base:base + 13] = [0.0, 1.0, math.log2(1000), 0.0, 0.0, 1.0, 1.0, 0.5, 0.0, 1.0, 2.0, 1.0, 0.0]
            continue
        stereo = band["stereo"]
        if band["mid_side"] and stereo in (0, 1):
            stereo = 3 + stereo  # Pro-Q 3: 3 = Mid, 4 = Side
        vals[base + 0] = 1.0  # used
        vals[base + 1] = 1.0 if band["enabled"] else 0.0
        vals[base + 2] = band["freq"]  # log2(Hz) in both versions
        vals[base + 3] = band["gain"]  # dB
        vals[base + 4] = 0.0  # no dynamic range in Pro-Q 2
        vals[base + 7] = band["q"]  # same Q encoding in both versions
        vals[base + 8] = float(band["shape"])  # Pro-Q 2 shapes 0-7 = Pro-Q 3 shapes 0-7
        vals[base + 9] = float(band["slope"])  # 6..96 dB/oct, same numbering
        vals[base + 10] = float(stereo)
        vals[base + 12] = 0.0  # solo off
    return magic + struct.pack("<II", version, len(vals)) + struct.pack(f"<{len(vals)}f", *vals) + trailing


def describe_proq2(old_chunk: bytes) -> str:
    """Short human-readable summary of the used bands, for the swap report."""
    bands = proq2_bands(old_chunk) or []
    parts = []
    for b in bands:
        if not b["used"]:
            continue
        hz = 2 ** b["freq"]
        f = f"{hz / 1000:.1f}kHz" if hz >= 1000 else f"{hz:.0f}Hz"
        q = 10 ** ((b["q"] - 0.5) / 0.312098175)
        if b["shape"] in (2, 4):
            parts.append(f"{SHAPES[b['shape']]} {f} {SLOPES[b['slope']]}dB/oct")
        else:
            parts.append(f"{SHAPES[b['shape']]} {f} {b['gain']:+.1f}dB Q{q:.2f}")
        if not b["enabled"]:
            parts[-1] += " (off)"
    return "; ".join(parts)


def is_fabfilter(plugin_name: str) -> bool:
    return plugin_name.lower().replace(" ", "").startswith("fabfilter")


def is_fabfilter_state(chunk: bytes) -> bool:
    return chunk[:4] in (b"FFBS", b"FQ2p", b"FQ3p")


# ---- Bark of Dog 2 (VST2) -> Bark of Dog 3 (VST3) ---------------------------------------
#
# Bark of Dog 2 saves 7 plain knob positions (0-1): Bypass, Mix, Master Volume, Frequency,
# Boost, Mode, Channel Mode. Bark of Dog 3 saves its knobs by name in real units (JUCE state).
# Bark of Dog 3's curves were measured from Bark of Dog 3 instances in real projects (each
# saves the knob position next to the real value):
#   Frequency = 10 + 1990 * pos ** 3.0517 Hz  (exact on all 4 samples: 64.7, 86.7, 180, 709 Hz)
#   Boost     = 24 * pos dB                   (exact on all 4 samples)
#   Mode      = 0/0.5/1 -> Classic/Passive/Combo
# The same knob positions mean the same in Bark of Dog 2: confirmed by ear in Live, Nov 2026
# (dirt devils kicks: 51 Hz +20.6 dB Passive, 81 Hz +15.2 dB Combo). Bark of Dog 3 has no
# output volume, so a changed Master Volume is reported.

BARK3_STATE = bytes.fromhex(
    "506172616d65746572730000010b504152414d000102696400010b05416e616c6f675f49440076616c756500010904000000000000000000504152414d000102696400010a05426f6f73745f49440076616c75650001090400000040b81e2e4000504152414d0001026964000119054368616e6e656c436f6e66696775726174696f6e5f49440076616c756500010904000000000000000000504152414d000102696400010e054672657175656e63795f49440076616c75650001090400000000a62b864000504152414d000102696400010e05496e7075744761696e5f49440076616c756500010904000000003fb52ac000504152414d000102696400010f054d61737465725f4d69785f49440076616c756500010904000000000000594000504152414d0001026964000109054d6f64655f49440076616c756500010904000000000000000000504152414d000102696400011205506c7567696e5f456e61626c655f49440076616c756500010904000000000000f03f00656469746f7200010273697a652d78000105018a02000073697a652d7900010501c7010000006c6173747072657365740001016e616d650001020500006465736372697074696f6e000102746578745469746c650001020500746578744c6f6e6700010205000000000000000000004a554345507269766174654461746100010142797061737300010103001d000000000000004a5543455072697661746544617461")
BARK3_MODES = ["Classic", "Passive", "Combo"]


def _bark2_values(old_chunk: bytes) -> list[float] | None:
    if len(old_chunk) == 28 + 4 * 7:
        body = old_chunk[28:]
    elif len(old_chunk) == 4 * 7:
        body = old_chunk
    else:
        return None
    vals = list(struct.unpack("<7f", body))
    return vals if all(0.0 <= v <= 1.0 for v in vals) else None


def bark2_to_bark3(old_chunk: bytes, bark3_state: bytes | None) -> bytes | None:
    from .juce_state import build, params, parse, set_params
    vals = _bark2_values(old_chunk)
    if vals is None:
        return None
    parsed = parse(bark3_state) if bark3_state else None
    if not parsed or "Frequency_ID" not in params(parsed[0]):
        parsed = parse(BARK3_STATE)
    tree, tail = parsed
    bypass, mix, _volume, freq, boost, mode, _channels = vals
    set_params(tree, {
        "Plugin_Enable_ID": 0.0 if bypass >= 0.5 else 1.0,
        "Master_Mix_ID": round(mix * 100, 3),
        "Frequency_ID": round(10 + 1990 * freq ** 3.0517, 3),
        "Boost_ID": round(24 * boost, 3),
        "Mode_ID": float(min(2, round(mode * 2))),
        "InputGain_ID": 0.0,
        "ChannelConfiguration_ID": 0.0,  # stereo
        "Analog_ID": 0.0,
    })
    return build(tree, tail)


def describe_bark2(old_chunk: bytes) -> str:
    vals = _bark2_values(old_chunk)
    if vals is None:
        return ""
    bypass, mix, volume, freq, boost, mode, _ = vals
    text = (f"{10 + 1990 * freq ** 3.0517:.0f} Hz, +{24 * boost:.1f} dB, "
            f"{BARK3_MODES[min(2, round(mode * 2))]}, mix {mix * 100:.0f}%")
    if bypass >= 0.5:
        text += ", off"
    if abs(volume - 0.5) > 0.01:
        text += "; Bark of Dog 2's output volume isn't in Bark of Dog 3, set Gain by ear"
    return text


# (old plugin key, new plugin key) -> translator for a VST2 -> VST3 swap:
# (old VST2 chunk, the VST3's template state or None) -> new VST3 state
VST3_TRANSLATORS = {
    ("barkofdog2", "barkofdog3"): (bark2_to_bark3, describe_bark2),
}


# (old plugin key, new plugin key) -> translator(old_chunk, new_plugin_chunk) -> new chunk
TRANSLATORS = {
    ("fabfilterproq2", "fabfilterproq3"): (proq2_to_proq3, describe_proq2),
}
