"""Find projects that are exact copies of each other (often whole folders copied 2-4 times).

Only identical sets count: same Live XML, byte for byte, whatever the file is called. Same-named
sets that differ are different versions and are only reported. Nothing is moved or deleted: with
`--ignore`, the extra copies go on a list next to the database and scan leaves them out, so every
later relink, swap and report works on one copy of each song. `--clear` undoes it.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from .database import norm

SKIP_DIRS = {"backup", "relinked", "swapped", "__macosx", "history"}
COPY_SUFFIXES = (" (relinked)", " (swapped)")


def ignore_file(db_path: str | os.PathLike) -> Path:
    return Path(db_path).parent / "duplicates_ignored.txt"


def load_ignored(db_path: str | os.PathLike) -> set[str]:
    f = ignore_file(db_path)
    if not f.exists():
        return set()
    return {norm(l.strip()) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()}


def save_ignored(db_path: str | os.PathLike, paths: list[str]) -> None:
    f = ignore_file(db_path)
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text("".join(p + "\n" for p in sorted(paths)), encoding="utf-8")
    tmp.replace(f)


def original_of(als: Path) -> Path:
    """'X\\Relinked\\Song (relinked).als' -> 'X\\Song.als' (the project a copy belongs to)."""
    if als.parent.name.lower() in ("relinked", "swapped"):
        stem = als.stem
        for suf in COPY_SUFFIXES:
            while stem.endswith(suf):
                stem = stem[: -len(suf)]
        return als.parent.parent / f"{stem}.als"
    return als


def is_ignored(als: Path, ignored: set[str]) -> bool:
    return bool(ignored) and norm(str(original_of(als))) in ignored


def iter_originals(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d.lower() not in SKIP_DIRS]
        for f in filenames:
            if f.lower().endswith(".als") and not f.startswith("._"):
                yield Path(dirpath) / f


def content_hash(path: Path, cache: dict) -> str | None:
    try:
        st = path.stat()
    except OSError:
        return None
    key = norm(str(path))
    hit = cache.get(key)
    if hit and hit[0] == st.st_mtime and hit[1] == st.st_size:
        return hit[2]
    try:
        with gzip.open(path, "rb") as f:
            h = hashlib.sha1()
            for block in iter(lambda: f.read(1 << 20), b""):
                h.update(block)
        digest = h.hexdigest()
    except (OSError, EOFError):
        return None
    cache[key] = (st.st_mtime, st.st_size, digest)
    return digest


@dataclass
class Report:
    groups: list[list[Path]] = field(default_factory=list)   # identical sets, the one to keep first
    folder_pairs: list[tuple[Path, Path, int, int]] = field(default_factory=list)  # copy, of, same, total
    same_name_differs: int = 0
    scanned: int = 0
    unreadable: list[Path] = field(default_factory=list)


def _keep_score(p: Path, prefer: list[str]):
    """Lower is better: inside a preferred folder, then fewest folders deep, then oldest path text."""
    np = norm(str(p))
    preferred = any(np.startswith(norm(x).rstrip("/") + "/") for x in prefer)
    return (0 if preferred else 1, len(p.parts), np)


def find_duplicates(root: Path, cache_path: Path | None = None, prefer: list[str] | None = None,
                    progress=None) -> Report:
    prefer = prefer or []
    cache = {}
    if cache_path and cache_path.exists():
        try:
            cache = {k: tuple(v) for k, v in json.loads(cache_path.read_text(encoding="utf-8")).items()}
        except (OSError, ValueError):
            cache = {}
    rep = Report()
    by_hash: dict[str, list[Path]] = defaultdict(list)
    by_name: dict[str, set[str]] = defaultdict(set)
    per_dir = Counter()
    for i, als in enumerate(iter_originals(root), 1):
        if progress and i % 200 == 0:
            progress(i)
        h = content_hash(als, cache)
        rep.scanned += 1
        if h is None:
            rep.unreadable.append(als)
            continue
        by_hash[h].append(als)
        by_name[als.stem.lower()].add(h)
        per_dir[als.parent] += 1
    if cache_path:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps(cache), encoding="utf-8")

    pair_count = Counter()
    for paths in by_hash.values():
        if len(paths) < 2:
            continue
        group = sorted(paths, key=lambda p: _keep_score(p, prefer))
        rep.groups.append(group)
        for extra in group[1:]:
            pair_count[(extra.parent, group[0].parent)] += 1
    rep.groups.sort(key=lambda g: norm(str(g[0])))
    rep.folder_pairs = sorted(((a, b, n, per_dir[a]) for (a, b), n in pair_count.items()),
                              key=lambda t: (-t[2], norm(str(t[0]))))
    rep.same_name_differs = sum(1 for hs in by_name.values() if len(hs) > 1)
    return rep
