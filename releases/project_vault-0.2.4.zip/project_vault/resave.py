"""Guided resave: open each old (Live 8/9) copy in Live, wait until it's saved as a newer set, move on.

Live 12 can't take a VST3 plugin inside a Live 8/9 set, so those copies must be saved once in
Live 12 before swap can finish them. Saving can only be done inside Live, so this walks the
person through it: it opens the copy (Windows hands .als files to the running Live), shows the
clicks, and watches the file. As soon as the file on disk says it was saved by Live 10 or newer,
it opens the next one. Nothing is changed by Project Vault itself; only copies are opened.
"""
from __future__ import annotations

import gzip
import os
import re
import sys
import time
from pathlib import Path
from typing import Callable

STEPS = ("In Live: File > Save Live Set As (Ctrl+Shift+S), click Save, then Yes to replace it.\n"
         "      (Live asks this way because the set is from an older version.)")


def saved_by(path: str | os.PathLike) -> int:
    """Major Live version that last saved this set (0 if it can't be read right now)."""
    try:
        with gzip.open(path, "rb") as f:
            head = f.read(2048).decode("utf-8", "replace")
    except (OSError, EOFError):
        return 0  # missing, or Live is still writing it
    m = re.search(r'Creator="Ableton Live (\d+)', head)
    return int(m.group(1)) if m else 0


def open_in_live(path: str) -> bool:
    """Hand the set to Live the way a double-click would. False where that isn't possible."""
    if hasattr(os, "startfile"):
        try:
            os.startfile(path)  # type: ignore[attr-defined]
            return True
        except OSError:
            return False
    return False


def _key_pressed() -> str:
    """A key pressed in this window (Windows), without waiting. '' if none."""
    try:
        import msvcrt  # type: ignore
    except ImportError:
        return ""
    if msvcrt.kbhit():
        return msvcrt.getwch().lower()
    return ""


def guide(paths: list[str], opener: Callable[[str], bool] = open_in_live,
          poll: float = 2.0, timeout: float | None = None, key: Callable[[], str] = _key_pressed,
          out: Callable[[str], None] = print, need: int = 10) -> tuple[list[str], list[str]]:
    """Walk through paths. Returns (saved, skipped). `timeout` (seconds per set) is for tests."""
    saved, skipped = [], []
    todo = [p for p in paths if saved_by(p) < need]
    done_before = len(paths) - len(todo)
    if done_before:
        out(f"{done_before} of {len(paths)} were already saved in a newer Live, skipping those.")
    if not todo:
        return saved, skipped
    out("While each one is open:  S = skip it,  Q = stop here (run resave again later to continue).\n")
    for i, path in enumerate(todo, 1):
        name = Path(path).name
        out(f"[{i}/{len(todo)}] {name}")
        if not opener(path):
            out(f"      Open it in Live yourself: {path}")
        out(f"      {STEPS}")
        start = time.monotonic()
        while True:
            if saved_by(path) >= need:
                saved.append(path)
                out("      Saved. Next...\n")
                break
            k = key()
            if k == "s":
                skipped.append(path)
                out("      Skipped.\n")
                break
            if k == "q":
                skipped.extend(p for p in todo[i - 1:])
                out("      Stopped.")
                return saved, skipped
            if timeout is not None and time.monotonic() - start > timeout:
                skipped.append(path)
                break
            time.sleep(poll)
    return saved, skipped


def run(paths: list[str], folder: str = "<your projects folder>") -> int:
    if not paths:
        print("Nothing to resave: every project can already be swapped.")
        return 0
    if not hasattr(os, "startfile"):
        print("(Opening sets automatically only works on Windows; the paths are shown instead.)")
    print(f"{len(paths)} project copy(ies) need one save in Live 12. Keep Live open.\n")
    try:
        saved, skipped = guide(paths)
    except KeyboardInterrupt:
        print("\nStopped. Run resave again later to continue where you left off.")
        return 1
    print(f"\nDone: {len(saved)} saved, {len(skipped)} skipped.")
    if saved:
        print("Next, so swap uses the newly saved copies:\n"
              f'  python -m project_vault scan "{folder}" --ignore-swapped\n'
              "  python -m project_vault swap --try-settings --replace")
    return 0 if not skipped else 1
