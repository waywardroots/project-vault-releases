"""Swap missing plugins in a project for ones installed on this computer.

The original .als is never changed: the result is saved next to it as
"<name> (swapped).als". For each swapped plugin:

* The plugin is replaced by the target, using the target's description taken from one
  of your own projects that already uses it (that is where Live's plugin IDs come from).
* Settings are kept when the old data should load in the target (same plugin in 32/64-bit,
  or a minor version like Spire 1.1 -> 1.5). Otherwise the target starts from its default
  sound, and the old settings are saved as a .fxp preset next to the project so you can
  try loading them into the new version.
* Automation on a reset plugin is removed, because its knobs no longer line up.
* The device is renamed "<new> (was <old>)" so it is easy to spot in Live.
"""
from __future__ import annotations

import gzip
import html
import re
import struct
import zlib
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from .als_reader import read_als
from .plugin_check import plugin_key
from .translators import TRANSLATORS, is_fabfilter, is_fabfilter_state

SUFFIX = " (swapped)"
DEVICE_RE = re.compile(r"<PluginDevice Id=\"\d+\">.*?</PluginDevice>", re.S)
DESC_RE = re.compile(r"<PluginDesc>.*?</PluginDesc>", re.S)
TRACK_RE = re.compile(r"<(MidiTrack|AudioTrack|GroupTrack|ReturnTrack|MainTrack|MasterTrack)[ >]")
# Live 12 can't read a VST3 device inside a Live 8/9 set ("Unknown class 'Vst3PluginInfo'"), but it
# can inside a Live 10 set (tested Nov 2026: dusty news, Live 10.1.3, Bark of Dog 3 loaded). Older sets
# must be opened and saved once in Live 12 before swaps to or from VST3.
MIN_LIVE_MAJOR = 10


def live_major(creator: str) -> int:
    m = re.search(r"Live (\d+)", creator or "")
    return int(m.group(1)) if m else 0


def describe(desc_xml: str) -> tuple[str, str] | None:
    """(plugin name, format) of a <PluginDesc> block."""
    try:
        el = ET.fromstring(desc_xml)
    except ET.ParseError:
        return None
    v3 = el.find("Vst3PluginInfo")
    if v3 is not None:
        return (v3.find("Name").get("Value") if v3.find("Name") is not None else "", "VST3")
    v2 = el.find("VstPluginInfo")
    if v2 is not None:
        return (v2.find("PlugName").get("Value") if v2.find("PlugName") is not None else "", "VST2")
    return None


def _bitness_or_minor(a: str, b: str) -> bool:
    """True when two VST2 names differ only by 32/64-bit naming or a minor version."""
    strip_bits = lambda s: re.sub(r"(x64|x86|32|64)(bit)?", "", plugin_key(s))
    if strip_bits(a) == strip_bits(b):
        return True
    na, nb = re.findall(r"\d+", a), re.findall(r"\d+", b)
    return bool(na and nb and na[0] == nb[0]
                and re.sub(r"[\d.]+", "", plugin_key(a)) == re.sub(r"[\d.]+", "", plugin_key(b)))


# Swaps tested in Live where the new plugin loads the old plugin's settings.
# Add a pair here once it has been confirmed by opening a swapped project.
# (Pro-Q 2 -> Pro-Q 3 is not here: Pro-Q 3 accepts Pro-Q 2's data but reads it in its own
# order, which scrambles the bands. It goes through translators.py instead.)
TESTED_CARRY_OVER: set[tuple[str, str]] = set()

# Swaps tested in Live where the new plugin rejects the old settings (error on load or the set
# fails to open). These always start the new plugin from its default sound.
TESTED_REJECTS = {
    ("serumx64", "serum2"),  # Nov 2026: "host provided invalid data to the audio processor"
    ("serum", "serum2"),
    ("wow", "wow2"),  # Nov 2026: WOW2 pops up "This is not a WOW2 file" for every instance
    # SubBoomBass 2 has 2048 parameters in a different order from SubBoomBass's 800: the old
    # values can't be carried. It ships the same factory sounds ("sub: X" -> "sub- X"), so the
    # kept preset name tells you which one to load.
    ("subboombass", "subboombass2"),
}


# VST2 -> VST3 swaps tested in Live where the VST3 reads the old VST2 settings and keeps the
# sound. These carry the settings over without --try-vst3.
TESTED_VST3_MIGRATION = {
    ("pigments", "pigments"),  # Nov 2026: patch, arp and FX came through intact
}


# VST3 -> VST2 swaps tested in Live where the VST2 reads the VST3's saved settings as they are.
# These carry the settings over without --try-settings.
TESTED_VST3_TO_VST2 = {
    ("diva", "diva"),  # Nov 2026: Journey, 6 of 6 patches identical after reload (only version fields differ)
    # Nov 2026: Dive, both basses sound right by ear and the bank comes back byte for byte. Live's
    # device still shows "LD Saw Init" as the program name; that label doesn't mean it was reset.
    ("nexus", "nexus"),
}


def tested_vst3_to_vst2(src: tuple[str, str], dst: tuple[str, str]) -> bool:
    return ((src[1], dst[1]) == ("VST3", "VST2")
            and (plugin_key(src[0]), plugin_key(dst[0])) in TESTED_VST3_TO_VST2)


def tested_vst3_migration(src: tuple[str, str], dst: tuple[str, str]) -> bool:
    return ((src[1], dst[1]) == ("VST2", "VST3")
            and (plugin_key(src[0]), plugin_key(dst[0])) in TESTED_VST3_MIGRATION)


def rejects_settings(src: tuple[str, str], dst: tuple[str, str]) -> bool:
    from .plugin_check import plugin_family
    pair = (plugin_key(src[0]), plugin_key(dst[0]))
    return pair in TESTED_REJECTS or (re.sub(r"\d", "", pair[0]), pair[1]) in TESTED_REJECTS


def tested_carry_over(src: tuple[str, str], dst: tuple[str, str]) -> bool:
    return src[1] == dst[1] == "VST2" and (plugin_key(src[0]), plugin_key(dst[0])) in TESTED_CARRY_OVER


def keeps_settings(src: tuple[str, str], dst: tuple[str, str]) -> bool:
    return src[1] == dst[1] == "VST2" and (_bitness_or_minor(src[0], dst[0]) or tested_carry_over(src, dst))


@dataclass
class Template:
    name: str
    fmt: str
    desc: str  # <PluginDesc> with the stored sound removed
    live_major: int
    source_project: str
    branch_id: str = ""  # Live 11+/12 plugin ID, e.g. device:vst3:instr:5653...
    browser_path: str = ""  # where Live's browser lists the plugin
    raw_desc: str = ""  # the description with its stored settings, for translators


def make_template(desc_xml: str, fmt: str) -> str:
    """Strip the stored sound out of a <PluginDesc>, so the plugin opens with its defaults."""
    d = desc_xml
    if fmt == "VST3":
        d = re.sub(r"<ProcessorState>.*?</ProcessorState>", "<ProcessorState />", d, flags=re.S)
        d = re.sub(r"<ControllerState>.*?</ControllerState>", "<ControllerState />", d, flags=re.S)
    else:
        d = re.sub(r"<Buffer>.*?</Buffer>", "<Buffer />", d, flags=re.S)
    d = re.sub(r"<ParameterSettings>.*?</ParameterSettings>", "<ParameterSettings />", d, flags=re.S)
    return d


def find_template(project_paths: list[tuple[str, str]], name: str, fmt: str) -> Template | None:
    """Take the target plugin's description from a project that already uses it (newest Live first)."""
    for path, creator in sorted(project_paths, key=lambda p: -live_major(p[1])):
        try:
            text = gzip.open(path, "rb").read().decode("utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for dev in DEVICE_RE.finditer(text):
            m = DESC_RE.search(dev.group(0))
            if m and describe(m.group(0)) == (name, fmt):
                bid = re.search(r'<BranchDeviceId Value="([^"]*)"', dev.group(0))
                bpath = re.search(r'<BrowserContentPath Value="([^"]*)"', dev.group(0))
                return Template(name, fmt, make_template(m.group(0), fmt), live_major(creator), path,
                                bid.group(1) if bid else "", bpath.group(1) if bpath else "", m.group(0))
    return None


# ---- exporting the old settings as a preset file ---------------------------------------
FPCH, FBCH = 0x46504368, 0x46424368  # 'FPCh' program chunk, 'FBCh' bank chunk
FXCK, FXBK = 0x4678436B, 0x4678426B  # 'FxCk' program / 'FxBk' bank of plain parameter values
PARAM_KINDS = (FXCK, FXBK)


def _vst2_preset(desc_xml: str):
    el = ET.fromstring(desc_xml)
    preset = el.find("VstPluginInfo/Preset/VstPreset")
    if preset is None or preset.find("Type") is None:
        return None
    kind = int(preset.find("Type").get("Value")) & 0xFFFFFFFF
    hex_text = "".join((preset.findtext("Buffer") or "").split())
    if kind not in (FPCH, FBCH, FXCK, FXBK) or not hex_text:
        return None
    val = lambda tag, default=0: int(preset.find(tag).get("Value")) if preset.find(tag) is not None else default
    name = preset.find("Name").get("Value") if preset.find("Name") is not None else ""
    return {"kind": kind, "chunk": bytes.fromhex(hex_text), "fx_id": val("UniqueId") & 0xFFFFFFFF,
            "fx_version": val("PluginVersion", 1), "programs": val("ProgramCount", 1),
            "params": val("ParameterCount"), "name": name}


def _param_program(p: dict) -> tuple[bytes, list[float]] | None:
    """(28-byte program name, values) of a plugin saved as plain parameters, one program only.
    Live keeps them as the program name followed by little-endian floats."""
    chunk, n = p["chunk"], p["params"]
    if p["kind"] not in PARAM_KINDS or p["programs"] > 1 or n <= 0:
        return None
    if len(chunk) == 28 + 4 * n:
        name, body = chunk[:28], chunk[28:]
    elif len(chunk) == 4 * n:
        name, body = p["name"].encode("latin-1", "replace")[:27].ljust(28, b"\0"), chunk
    else:
        return None
    return name, list(struct.unpack(f"<{n}f", body))


def _ccnk(p: dict, kind: int) -> bytes:
    """Standard VST2 preset container ('CcnK') around a program or bank chunk."""
    chunk = p["chunk"]
    if kind in PARAM_KINDS:  # plain parameters: a standard 'FxCk' preset (big-endian values)
        name_b, values = _param_program(p)
        body = (b"FxCk" + struct.pack(">iIii", 1, p["fx_id"], p["fx_version"], len(values))
                + name_b + struct.pack(f">{len(values)}f", *values))
        return b"CcnK" + struct.pack(">i", len(body)) + body
    if kind == FPCH:
        name_b = p["name"].encode("latin-1", "replace")[:27].ljust(28, b"\0")
        body = (b"FPCh" + struct.pack(">iIii", 1, p["fx_id"], p["fx_version"], p["params"])
                + name_b + struct.pack(">i", len(chunk)) + chunk)
    else:
        body = (b"FBCh" + struct.pack(">iIii", 1, p["fx_id"], p["fx_version"], p["programs"])
                + b"\0" * 128 + struct.pack(">i", len(chunk)) + chunk)
    return b"CcnK" + struct.pack(">i", len(body)) + body


def preset_from_desc(desc_xml: str) -> tuple[str, bytes] | None:
    """The VST2 settings Live stored -> (".fxp" or ".fxb", standard preset file bytes).
    A bank holding a single program is written as an .fxp preset, which newer versions of a
    plugin most often import; otherwise as an .fxb bank."""
    p = _vst2_preset(desc_xml)
    if not p:
        return None
    if p["kind"] in PARAM_KINDS:
        return (".fxp", _ccnk(p, p["kind"])) if _param_program(p) else None
    if p["kind"] == FPCH or p["programs"] <= 1:
        return ".fxp", _ccnk(p, FPCH)
    return ".fxb", _ccnk(p, FBCH)


def vst3_migration_state(desc_xml: str) -> bytes | None:
    """VST2 settings wrapped the standard way a host hands them to the VST3 version of a plugin
    ('VstW' header + 'CcnK' block), as other DAWs do when they replace VST2 with VST3.
    Plugins that support VST2-to-VST3 migration load the original sound; others ignore it."""
    p = _vst2_preset(desc_xml)
    if not p or (p["kind"] in PARAM_KINDS and not _param_program(p)):
        return None
    return b"VstW" + struct.pack(">iii", 8, 1, 0) + _ccnk(p, p["kind"])


def _looks_like_a_name(s: str, plugin: str) -> bool:
    s = s.strip()
    letters = sum(c.isalpha() for c in s)
    return (6 <= len(s) <= 60 and " " in s and letters >= 4
            and letters >= 0.6 * len(s.replace(" ", ""))
            and not re.search(r"[=;<>@{}\[\]|/\\]|\.[A-Za-z]{2,5}$|serialization|^macro", s, re.I)
            and not s.lower().startswith(("modwheel", "velocity"))
            and len(re.findall(r"(?:^|\s)\d+(?=\s|$)", s)) <= 2  # not a run of stored numbers
            and all(len(w) <= 20 for w in s.split())  # not a run of internal setting names
            and plugin_key(s) != plugin_key(plugin))


def preset_name(desc_xml: str, plugin: str = "") -> str:
    """Best guess at the name of the sound that was loaded, read from the saved settings."""
    p = _vst2_preset(desc_xml)
    if not p:
        return ""
    prog = _param_program(p)
    if prog:  # plain parameters: the program name is all there is
        name = prog[0].split(b"\0")[0].decode("latin-1").strip()
        return "" if name.lower() in ("", "default", "default setting", "init", "initial") else name
    data = p["chunk"]
    if data[:1] == b"x":  # zlib-compressed (e.g. Serum)
        try:
            data = zlib.decompress(data)
        except zlib.error:
            pass
    text = data.decode("latin-1")
    m = re.search(r"#pgm=([^\r\n\x00]{2,60})", text)  # u-he (Diva, Hive, Repro, Zebra...)
    if m:
        return m.group(1).strip()
    m = re.search(r'(?:presetName|PresetName|preset_name|programName|PRESET_NAME)="([^"]{1,60})"', text)
    if m:  # plugins that save their settings as XML (Valhalla and others)
        return html.unescape(m.group(1)).strip()
    if p["name"] and _looks_like_a_name(p["name"] + " x", plugin):
        return p["name"]
    if text.lstrip("\x00 ").startswith("<"):
        return ""  # other XML: no name to be found reliably
    for cand in re.findall(r"[ -~]{6,60}", text):
        if _looks_like_a_name(cand, plugin):
            return cand.strip()
    return ""


def _vst3_state(desc_xml: str) -> bytes | None:
    m = re.search(r"<ProcessorState>(.*?)</ProcessorState>", desc_xml, re.S)
    h = "".join(m.group(1).split()) if m else ""
    return bytes.fromhex(h) if h else None


def raw_settings(desc_xml: str, fmt: str) -> tuple[int, bytes] | None:
    """(chunk type, bytes) of the settings a plugin saved, in either format."""
    if fmt == "VST2":
        p = _vst2_preset(desc_xml)
        return (p["kind"], p["chunk"]) if p else None
    state = _vst3_state(desc_xml)
    return (FBCH, state) if state else None


def unwrap_vstw(state: bytes) -> tuple[int, int, bytes, int] | None:
    """Many VST3 plugins save their state in the VST2-compatible form ('VstW' header around a
    standard 'CcnK' preset). Returns (chunk type, VST2 unique id, chunk, program count) so the
    VST2 version can be given exactly what it would have saved itself, or None."""
    if state[:4] != b"VstW" or len(state) < 16:
        return None
    hlen = struct.unpack(">i", state[4:8])[0]
    c = state[8 + hlen:]
    if c[:4] != b"CcnK" or len(c) < 28:
        return None
    magic, fx_id, n = c[8:12], struct.unpack(">I", c[16:20])[0], struct.unpack(">i", c[24:28])[0]
    if magic == b"FBCh":  # bank: 128 reserved bytes, then the chunk size
        off = 28 + 128
    elif magic == b"FPCh":  # program: 28-byte name, then the chunk size
        off = 28 + 28
    else:
        return None
    if len(c) < off + 4:
        return None
    size = struct.unpack(">i", c[off:off + 4])[0]
    chunk = c[off + 4:off + 4 + size]
    if len(chunk) != size:
        return None
    return (FBCH if magic == b"FBCh" else FPCH), fx_id, chunk, max(n, 1)


def _hex_lines(data: bytes) -> str:
    h = data.hex().upper()
    return "\n".join(h[i:i + 80] for i in range(0, len(h), 80))


# ---- VST2 -> VST2: point the existing entry at the new plugin, in any Live version ---------
INFO_FIELDS = ("PlugName", "UniqueId", "NumberOfParameters", "NumberOfPrograms", "Flags")
PRESET_FIELDS = ("UniqueId", "ParameterCount", "ProgramCount", "PluginVersion")


def _split_preset(desc: str) -> tuple[str, str, str]:
    m = re.search(r"<Preset>.*?</Preset>", desc, re.S)
    return (desc[:m.start()], m.group(0), desc[m.end():]) if m else (desc, "", "")


def _get(section: str, tag: str) -> str | None:
    m = re.search(rf'<{tag} Value="([^"]*)"', section)
    return m.group(1) if m else None


def _set(section: str, tag: str, value: str | None) -> str:
    if value is None:
        return section
    return re.sub(rf'(<{tag} Value=")[^"]*(")', lambda m: m.group(1) + value + m.group(2), section, count=1)


def _dll_path(desc: str) -> str:
    path = _get(desc, "Path")
    if path:
        return html.unescape(path).replace("\\", "/")
    data = re.search(r"<Dir>.*?<Data>(.*?)</Data>", desc, re.S)
    folder = ""
    if data:
        try:
            raw = bytes.fromhex("".join(data.group(1).split()))
            folder = raw.decode("utf-16-le").split("\x00")[0]
        except (ValueError, UnicodeDecodeError):
            folder = ""
    name = html.unescape(_get(desc, "FileName") or "")
    return (folder.rstrip("\\/") + "/" + name).replace("\\", "/") if folder else name


def retarget_vst2(old_desc: str, target_desc: str, keep_settings: bool) -> str:
    """Edit an existing VST2 entry so it loads a different VST2 plugin, keeping the layout of
    whatever Live version wrote the project. Only the plugin's identity changes."""
    t_before, t_preset, t_after = _split_preset(target_desc)
    t_outside = t_before + t_after
    before, preset, after = _split_preset(old_desc)
    dll = _dll_path(target_desc)
    win = dll.replace("/", "\\")

    def outside(section: str) -> str:
        for tag in INFO_FIELDS:
            section = _set(section, tag, _get(t_outside, tag))
        if _get(section, "Path") is not None:
            section = _set(section, "Path", html.escape(dll, quote=True))
        if _get(section, "FileName") is not None:
            section = _set(section, "FileName", html.escape(win.rsplit("\\", 1)[-1], quote=True))
        d = re.search(r"(<Dir>.*?<Data>)(.*?)(</Data>)", section, re.S)
        if d:  # Live 8-10: folder of the .dll as UTF-16 hex
            nl = "\r\n" if "\r\n" in section else "\n"
            ind = re.search(r"(?:\r?\n)([ \t]*)<Data>", section)
            ind = ind.group(1) if ind else ""
            h = ((win.rsplit("\\", 1)[0] + "\\").encode("utf-16-le") + b"\0\0").hex().upper()
            body = "".join(nl + ind + "\t" + h[i:i + 80] for i in range(0, len(h), 80)) + nl + ind
            section = section[:d.start(2)] + body + section[d.end(2):]
        return section

    if preset:
        for tag in PRESET_FIELDS:
            preset = _set(preset, tag, _get(t_preset, tag))
        if not keep_settings:
            preset = re.sub(r"<Buffer>.*?</Buffer>", "<Buffer />", preset, flags=re.S)
            preset = re.sub(r"<ParameterSettings>.*?</ParameterSettings>", "<ParameterSettings />", preset,
                            flags=re.S)
    return outside(before) + preset + outside(after)


# ---- the swap itself ---------------------------------------------------------------------
@dataclass
class SwapDone:
    track: str
    old: str
    new: str
    settings: str  # "kept" / "carried over if the plugin supports it…" / "reset…"
    preset: str = ""  # name of the sound that was loaded, when it could be read


@dataclass
class SwapResult:
    project: str
    output: str = ""
    swaps: list[SwapDone] = field(default_factory=list)
    automation_removed: int = 0  # automation lanes removed from reset plugins
    skipped: str = ""
    needs_resave: list[str] = field(default_factory=list)  # swaps that need the set saved in Live 10+


def output_path(als: Path) -> Path:
    from .layout import swapped_path
    return swapped_path(als)  # <original folder>\Swapped\<name> (swapped).als


def _track_names(text: str) -> list[tuple[int, str]]:
    """(position, name) of every track. Tracks never renamed in Live 8-10 get Live's default names."""
    out, number, returns = [], 0, 0
    default_kind = {"MidiTrack": "MIDI", "AudioTrack": "Audio", "GroupTrack": "Group"}
    for m in TRACK_RE.finditer(text):
        tag = m.group(1)
        head = text[m.start(): m.start() + 3000]
        user = re.search(r'<UserName Value="([^"]*)"', head)
        eff = re.search(r'<EffectiveName Value="([^"]*)"', head)
        if tag in default_kind:
            number += 1
            default = f"{number}-{default_kind[tag]}"
        elif tag == "ReturnTrack":
            default = f"{chr(ord('A') + returns)}-Return"
            returns += 1
        else:
            default = "Main"
        name = user.group(1) if user and user.group(1) else eff.group(1) if eff and eff.group(1) else default
        out.append((m.start(), html.unescape(name)))
    return out


def swap_project(als_path: str, rules: dict[tuple[str, str], Template], replace: bool = False,
                 dry_run: bool = False, preset_dir: str | None = None,
                 try_settings: bool = False, try_vst3: bool = False,
                 old_live_test: bool = False) -> SwapResult:
    als = Path(als_path)
    result = SwapResult(project=als.stem)
    out = output_path(als)
    if old_live_test:  # test copy with VST3 swaps in a Live 8-10 set, kept apart from the real copy
        out = out.with_name(out.name.replace(f"{SUFFIX}.als", " (old live test).als"))
    if als.stem.endswith(SUFFIX):
        result.skipped = "already a swapped copy"
        return result
    if out.exists() and not replace:
        result.skipped = f"{out.name} already exists (use --replace to overwrite it)"
        return result
    text = gzip.open(als, "rb").read().decode("utf-8")
    creator = re.search(r'Creator="([^"]*)"', text[:500])
    major = live_major(creator.group(1) if creator else "")
    needs_resave: list[str] = []

    tracks = _track_names(text)
    removed_targets: set[str] = set()
    swapped: set[tuple[str, str]] = set()
    presets: list[tuple[str, bytes]] = []

    def repl(m: re.Match) -> str:
        block = m.group(0)
        dm = DESC_RE.search(block)
        if not dm:
            return block
        src = describe(dm.group(0))
        tpl = rules.get(src) if src else None
        if not tpl:
            return block
        track = next((n for pos, n in reversed(tracks) if pos < m.start()), "?")
        if major < MIN_LIVE_MAJOR and "VST3" in (src[1], tpl.fmt) and not old_live_test:
            needs_resave.append(f"{src[0]} -> {tpl.name}")  # older Live stores VST3 differently
            return block
        new_desc = tpl.desc
        name = ""
        if src[1] == tpl.fmt == "VST2":
            old_state = raw_settings(dm.group(0), "VST2")
            translator = TRANSLATORS.get((plugin_key(src[0]), plugin_key(tpl.name)))
            translated = None
            if translator and old_state:
                tpl_state = raw_settings(tpl.raw_desc, "VST2") if tpl.raw_desc else None
                chunk = translator[0](old_state[1], tpl_state[1]) if tpl_state else None
                if chunk:
                    translated = (tpl_state[0], chunk, translator[1](old_state[1]))
            # Different FabFilter products share a format but not an order: never hand the
            # raw data across, it scrambles the settings.
            # Older Live versions saved them as host parameters instead, whose order also differs.
            raw_ok = try_settings and not ((is_fabfilter(src[0]) or (old_state and is_fabfilter_state(old_state[1])))
                                           and not keeps_settings(src, (tpl.name, tpl.fmt))) \
                and not rejects_settings(src, (tpl.name, tpl.fmt))
            if raw_ok and old_state and old_state[0] in PARAM_KINDS:
                # Plain parameter values only line up if the new version has the same parameters.
                old_n = re.search(r'<NumberOfParameters Value="(\d+)"', dm.group(0))
                new_n = re.search(r'<NumberOfParameters Value="(\d+)"', tpl.raw_desc or tpl.desc)
                raw_ok = bool(old_n and new_n and old_n.group(1) == new_n.group(1))
            keep = keeps_settings(src, (tpl.name, tpl.fmt)) or (raw_ok and not translated)
            name = "" if keeps_settings(src, (tpl.name, tpl.fmt)) else preset_name(dm.group(0), src[0])
            new_desc = retarget_vst2(dm.group(0), tpl.desc, keep)
            if translated:
                kind, chunk, summary = translated
                new_desc = new_desc.replace("<Buffer />", "<Buffer>\n" + _hex_lines(chunk) + "\n</Buffer>", 1)
                new_desc = re.sub(r'(<VstPreset\b.*?<Type Value=")-?\d+(")',
                                  lambda t: t.group(1) + str(kind) + t.group(2), new_desc, count=1, flags=re.S)
                settings = "translated" + (f" ({summary})" if summary else " (flat EQ)")
            elif tested_carry_over(src, (tpl.name, tpl.fmt)):
                settings = "kept (tested swap)"
            elif keeps_settings(src, (tpl.name, tpl.fmt)):
                settings = "kept"
            elif keep:
                settings = "tried to carry over (experimental)"
            else:
                settings = "reset"
            exported = None if settings.startswith("kept") else preset_from_desc(dm.group(0))
            if exported:
                ext, data = exported
                fname = re.sub(r'[<>:"/\\|?*]', "_", f"{track} - {src[0]}") + ext
                n = sum(1 for f, _ in presets if f.rsplit(".", 1)[0].startswith(fname.rsplit(".", 1)[0]))
                if n:
                    fname = fname.replace(ext, f" ({n + 1}){ext}")
                presets.append((fname, data))
                settings += f"; old settings also saved as {fname}"
            block = block[:dm.start()] + new_desc + block[dm.end():]
            if settings.startswith(("reset", "tried", "translated")):
                plist = re.search(r"<ParameterList>.*?</ParameterList>", block, re.S)
                ids = set(re.findall(r'<(?:AutomationTarget|ModulationTarget) Id="(\d+)"', plist.group(0))) if plist else set()
                removed_targets.update(ids)
                if plist:
                    block = block[:plist.start()] + "<ParameterList />" + block[plist.end():]
        elif keeps_settings(src, (tpl.name, tpl.fmt)):
            old_buf = re.search(r"<Buffer>.*?</Buffer>", dm.group(0), re.S)
            if old_buf:
                new_desc = new_desc.replace("<Buffer />", old_buf.group(0), 1)
            settings = "kept"
            block = block[:dm.start()] + new_desc + block[dm.end():]
        else:
            name = preset_name(dm.group(0), src[0]) if src[1] == "VST2" else ""
            exported = preset_from_desc(dm.group(0)) if src[1] == "VST2" else None
            # Handing VST2 settings to a VST3 is opt-in: a plugin that can't read them may show an
            # error or stop the set from opening (Serum 2 does).
            vst3_translated = None
            if (src[1], tpl.fmt) == ("VST2", "VST3"):
                from .translators import VST3_TRANSLATORS
                vt = VST3_TRANSLATORS.get((plugin_key(src[0]), plugin_key(tpl.name)))
                old_state = raw_settings(dm.group(0), "VST2")
                if vt and old_state:
                    tpl_state = _vst3_state(tpl.raw_desc) if tpl.raw_desc else None
                    state = vt[0](old_state[1], tpl_state)
                    if state:
                        vst3_translated = (state, vt[1](old_state[1]))
            migration = (vst3_migration_state(dm.group(0))
                         if (src[1], tpl.fmt) == ("VST2", "VST3") and not vst3_translated
                         and (try_vst3 or tested_vst3_migration(src, (tpl.name, tpl.fmt)))
                         and not rejects_settings(src, (tpl.name, tpl.fmt)) else None)
            if migration:
                new_desc = new_desc.replace("<ProcessorState />",
                                            "<ProcessorState>\n" + _hex_lines(migration) + "\n</ProcessorState>", 1)
            settings = ("carried over (tested)" if migration and tested_vst3_migration(src, (tpl.name, tpl.fmt))
                        else "carried over if the plugin supports it" if migration else "reset")
            if vst3_translated:
                state, summary = vst3_translated
                new_desc = new_desc.replace("<ProcessorState />",
                                            "<ProcessorState>\n" + _hex_lines(state) + "\n</ProcessorState>", 1)
                settings = "translated" + (f" ({summary})" if summary else "")
            if (not migration and src[1] == "VST3" and tpl.fmt == "VST2" and "<Buffer />" in new_desc):
                # Many VST3s save their settings in their VST2 form. When the saved data names
                # this very VST2 plugin, it is exactly what the VST2 would have saved: no guess.
                state = _vst3_state(dm.group(0))
                wrapped = unwrap_vstw(state) if state else None
                uid = re.search(r'<UniqueId Value="(-?\d+)"', new_desc)
                if wrapped and uid and int(uid.group(1)) & 0xFFFFFFFF == wrapped[1]:
                    kind, _, data, _ = wrapped
                    new_desc = new_desc.replace("<Buffer />", "<Buffer>\n" + _hex_lines(data) + "\n</Buffer>", 1)
                    new_desc = re.sub(r'(<VstPreset\b.*?<Type Value=")-?\d+(")',
                                      lambda t: t.group(1) + str(kind) + t.group(2), new_desc, count=1, flags=re.S)
                    settings = "carried over (the VST3 saved it in this plugin's VST2 format)"
            tested_down = tested_vst3_to_vst2(src, (tpl.name, tpl.fmt))
            if (try_settings or tested_down) and not migration and settings == "reset" \
                    and not rejects_settings(src, (tpl.name, tpl.fmt)):
                # Experimental: give the new plugin the old settings even though it is a different
                # version or format. Plugins that understand them keep the sound.
                old = raw_settings(dm.group(0), src[1])
                if old and old[0] in PARAM_KINDS:
                    old = None  # plain parameter values only mean something to the same plugin
                if old and tpl.fmt == "VST2" and "<Buffer />" in new_desc:
                    kind, data = old[0], old[1]
                    label = "carried over (tested)" if tested_down else "tried to carry over (experimental)"
                    wrapped = unwrap_vstw(data) if src[1] == "VST3" else None
                    if wrapped:
                        # The VST3 kept its settings in VST2 form: hand over the inner preset.
                        kind, fx_id, data, _ = wrapped
                        uid = re.search(r'<UniqueId Value="(-?\d+)"', new_desc)
                        if uid and int(uid.group(1)) & 0xFFFFFFFF == fx_id:
                            label = "carried over (the VST3 saved it in this plugin's VST2 format)"
                    new_desc = new_desc.replace("<Buffer />", "<Buffer>\n" + _hex_lines(data) + "\n</Buffer>", 1)
                    new_desc = re.sub(r'(<VstPreset\b.*?<Type Value=")-?\d+(")',
                                      lambda t: t.group(1) + str(kind) + t.group(2), new_desc, count=1, flags=re.S)
                    settings = label
                elif old and src[1] == "VST3" and tpl.fmt == "VST3" and "<ProcessorState />" in new_desc:
                    # Raw VST2 data is never handed to a VST3: it can't read it, and some show an
                    # error or stop the set from opening. VST2 -> VST3 only goes through --try-vst3.
                    new_desc = new_desc.replace("<ProcessorState />", "<ProcessorState>\n" + _hex_lines(old[1])
                                                + "\n</ProcessorState>", 1)
                    settings = "tried to carry over (experimental)"
            if exported:
                ext, data = exported
                fname = re.sub(r'[<>:"/\\|?*]', "_", f"{track} - {src[0]}") + ext
                n = sum(1 for f, _ in presets if f.rsplit(".", 1)[0].startswith(fname.rsplit(".", 1)[0]))
                if n:
                    fname = fname.replace(ext, f" ({n + 1}){ext}")
                presets.append((fname, data))
                settings += f"; old settings also saved as {fname}"
            block = block[:dm.start()] + new_desc + block[dm.end():]
            # The old knobs don't exist on the new plugin: drop the parameter list and its automation.
            plist = re.search(r"<ParameterList>.*?</ParameterList>", block, re.S)
            ids = set(re.findall(r'<(?:AutomationTarget|ModulationTarget) Id="(\d+)"', plist.group(0))) if plist else set()
            removed_targets.update(ids)
            if plist:
                block = block[:plist.start()] + "<ParameterList />" + block[plist.end():]
        # Live 12 also identifies the plugin by these two IDs; point them at the new plugin too,
        # otherwise Live keeps looking for the old one.
        if tpl.branch_id:
            block = re.sub(r'(<BranchDeviceId Value=")[^"]*(")',
                           lambda u: u.group(1) + tpl.branch_id + u.group(2), block, count=1)
        if tpl.browser_path:
            block = re.sub(r'(<BrowserContentPath Value=")[^"]*(")',
                           lambda u: u.group(1) + tpl.browser_path + u.group(2), block, count=1)
        was = f"{src[0]}: {name}" if (settings != "kept" and name) else src[0]
        label = html.escape(f"{tpl.name} (was {was})", quote=True)
        block = re.sub(r'(<UserName Value=")[^"]*(")', lambda u: u.group(1) + label + u.group(2), block, count=1)
        result.swaps.append(SwapDone(track, f"{src[0]} [{src[1]}]", f"{tpl.name} [{tpl.fmt}]", settings,
                                     name if settings != "kept" else ""))
        swapped.add(src)
        return block

    new_text = DEVICE_RE.sub(repl, text)
    result.needs_resave = sorted(set(needs_resave))
    if not result.swaps:
        result.skipped = ("made in Live 9 or older: open it in Live 12 and save it once, then run swap again "
                          f"({', '.join(result.needs_resave)})" if needs_resave else "no plugins to swap")
        return result

    # Remove automation lanes (arrangement and clip) that pointed at the reset plugins' knobs.
    if removed_targets:
        def drop(env: re.Match) -> str:
            pid = re.search(r'<PointeeId Value="(\d+)"', env.group(0))
            return "" if pid and pid.group(1) in removed_targets else env.group(0)
        before = new_text
        new_text = re.sub(r"<AutomationEnvelope Id=\"\d+\">.*?</AutomationEnvelope>", drop, new_text, flags=re.S)
        new_text = re.sub(r"<ClipEnvelope Id=\"\d+\">.*?</ClipEnvelope>", drop, new_text, flags=re.S)
        result.automation_removed = (len(re.findall(r"<AutomationEnvelope |<ClipEnvelope ", before))
                                     - len(re.findall(r"<AutomationEnvelope |<ClipEnvelope ", new_text)))

    # Safety checks before anything is written.
    try:
        ET.fromstring(new_text.encode("utf-8"))
    except ET.ParseError as e:
        result.skipped = f"internal check failed, nothing written ({e})"
        result.swaps = []
        return result
    if len(DEVICE_RE.findall(new_text)) != len(DEVICE_RE.findall(text)):
        result.skipped = "internal check failed (device count changed), nothing written"
        result.swaps = []
        return result

    result.output = str(out)
    if dry_run:
        return result
    from .layout import anchor_refs, settings_dir
    new_text, _ = anchor_refs(new_text, als.parent)  # the copy lives in Swapped\
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_name(out.name + ".tmp")
    tmp.write_bytes(gzip.compress(new_text.encode("utf-8")))
    try:
        ET.fromstring(new_text.encode("utf-8"))
        names = {(p.name, p.fmt) for p in read_als(tmp).plugins}
        if swapped & names:
            raise ValueError("a swapped plugin is still in the project")
    except Exception as e:
        tmp.unlink(missing_ok=True)
        result.output, result.swaps = "", []
        result.skipped = f"internal check failed, nothing written ({e})"
        return result
    from .safe_io import move_into_place
    err = move_into_place(tmp, out)
    if err:
        result.output, result.swaps = "", []
        result.skipped = err
        return result
    if presets:
        folder = Path(preset_dir) if preset_dir else settings_dir(als)
        folder.mkdir(parents=True, exist_ok=True)
        for fname, data in presets:
            (folder / fname).write_bytes(data)
    return result
