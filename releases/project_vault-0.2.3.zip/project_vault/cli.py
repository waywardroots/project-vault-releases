"""Project Vault command line.

    python -m project_vault scan "C:/Users/me/Desktop/project files"
    python -m project_vault where "kick_01"
    python -m project_vault missing [--summary]
    python -m project_vault relink "E:/Samples" "F:/Samples"
    python -m project_vault fix relink_report.csv [--project "Date Nite"] [--dry-run]
    python -m project_vault unused "E:/Samples"
    python -m project_vault plugins [name]
    python -m project_vault plugin-check [--vst2 "D:/VST"] [--vst3 "D:/VST3"]
    python -m project_vault project "Date Nite"
    python -m project_vault stats
    python -m project_vault resave
    python -m project_vault report [--plugin "Kickstart"] [--project "Date Nite"] [--note "..."]

Read-only: it never changes, moves or deletes your project or sample files.
"""
from __future__ import annotations

import argparse
import csv
import os
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

from .als_reader import read_als
from .database import VaultDB, norm
from .fix import fix_project, load_plan
from .plugin_check import DEFAULT_VST2, DEFAULT_VST3, check, find_installed
from .shopping import build_list, vendor_for, write_html
from .swap import find_template, swap_project
from .plugin_check import plugin_key
from .relink import (CONFIDENT, EDITED_LABEL, EXACT, REBUILD, RENAMED, best_match, build_index,
                     collect_missing, find_renamed, is_ableton_library, live_generated, old_location)

DEFAULT_DB = Path.home() / ".project_vault" / "vault.db"
AUDIO_EXTS = {".wav", ".aif", ".aiff", ".mp3", ".flac", ".ogg", ".m4a", ".rx2"}


VERSION_SUFFIXES = (" (swapped)", " (relinked)")  # newest first


def _base_and_rank(stem: str) -> tuple[str, int]:
    """'Song (relinked)' -> ('song', 1). Higher rank = newer copy made by Project Vault."""
    rank, base = 0, stem
    for i, suf in enumerate(VERSION_SUFFIXES):
        if base.endswith(suf):
            base, rank = base[: -len(suf)], max(rank, len(VERSION_SUFFIXES) - i)
    if base.endswith(" (relinked)"):  # "(relinked) (swapped)" style names
        base = base[: -len(" (relinked)")]
    return base.lower(), rank


def iter_als(root: Path, skipped: list | None = None, ignore_swapped: bool = False,
             originals_only: bool = False):
    """All .als files under root, skipping Ableton's Backup folders and Mac zip leftovers.
    Copies Project Vault keeps in Relinked\\ and Swapped\\ (or, from older versions, next to
    the original) count as versions of that project: only the newest one is used, so nothing
    is counted twice."""
    from .layout import COPY_DIRS
    for dirpath, dirnames, filenames in os.walk(root):
        skip = {"backup", "__macosx", "safe"} | {d.lower() for d in COPY_DIRS}
        dirnames[:] = [d for d in dirnames if d.lower() not in skip]
        files = [(Path(dirpath) / f) for f in filenames]
        for sub in COPY_DIRS:
            sd = Path(dirpath) / sub
            if sd.is_dir():
                files += [sd / f for f in os.listdir(sd)]
        als = [f for f in files if f.name.lower().endswith(".als") and not f.name.startswith("._")]
        if ignore_swapped or originals_only:
            als = [f for f in als if not f.stem.endswith(" (swapped)")]
        if originals_only:
            als = [f for f in als if not f.stem.endswith(" (relinked)")]
        best: dict[str, tuple[int, int]] = {}
        for f in als:
            base, rank = _base_and_rank(f.stem)
            key = (rank, f.parent.name in COPY_DIRS)  # prefer copies already in the folders
            best[base] = max(best.get(base, (-1, 0)), key)
        for f in als:
            base, rank = _base_and_rank(f.stem)
            if (rank, f.parent.name in COPY_DIRS) < best[base]:
                if skipped is not None:
                    skipped.append(f)
                continue
            yield f


def cmd_scan(db: VaultDB, args) -> None:
    root = Path(args.folder)
    if not root.is_dir():
        sys.exit(f"Folder not found: {root}")
    seen, scanned, skipped, errors, replaced = set(), 0, 0, [], []
    for als in iter_als(root, replaced, getattr(args, "ignore_swapped", False),
                        getattr(args, "originals", False)):
        seen.add(str(als))
        mtime = als.stat().st_mtime
        if not args.full and not db.needs_scan(str(als), mtime):
            skipped += 1
            continue
        try:
            db.save_project(read_als(als), mtime)
            scanned += 1
            print(f"  read  {als.relative_to(root)}")
        except Exception as e:  # keep going; report at the end
            errors.append((als, e))
    removed = db.remove_missing_projects(seen, str(root))
    print(f"\nScanned {scanned}, unchanged {skipped}, removed {removed}, errors {len(errors)}")
    if replaced:
        print(f"{len(replaced)} older versions left out because a newer '(relinked)' or '(swapped)' "
              "copy of the same project exists.")
    for als, e in errors:
        print(f"  ! {als}: {e}")


def cmd_where(db: VaultDB, args) -> None:
    rows = db.where_used(args.text)
    if not rows:
        print("No projects use a sample matching that name.")
        return
    by_sample = defaultdict(list)
    for r in rows:
        by_sample[r["path"]].append(r)
    for path, uses in by_sample.items():
        projects = sorted({u["project"] for u in uses})
        print(f"\n{uses[0]['file_name']}  —  used in {len(projects)} project(s)\n  {path}")
        for u in uses:
            times = f", {u['count']}x" if u["count"] > 1 else ""
            print(f"    • {u['project']}  /  track: {u['track_name']}  ({u['location']}{times})")


def cmd_missing(db: VaultDB, args) -> None:
    projects = collect_missing(db)
    if not projects:
        print("No missing samples. Every project's samples were found on disk.")
        return
    unique = {k[0] for p in projects for k in p.samples}
    print(f"{len(unique)} different samples are missing, across {len(projects)} project(s).\n")
    print("Where they used to be:")
    by_loc = defaultdict(int)
    for path in unique:
        by_loc["Ableton library (Live usually finds these)" if is_ableton_library(path) else old_location(path)] += 1
    for loc, n in sorted(by_loc.items(), key=lambda x: -x[1])[:15]:
        print(f"  {n:6d}  {loc}")
    if args.summary:
        return
    for p in projects:
        print(f"\n{p.name}  ({len(p.samples)} missing)\n  {p.path}")
        for (path, name, _, _), tracks in p.samples.items():
            print(f"    x {name}  (track: {', '.join(tracks)})\n      was at {path}")


def plan_crop_rebuilds(projects, results: dict[str, tuple[str, str]], index) -> None:
    """Lost crops whose original survives: find where in the original each crop was cut.
    Updates results in place with a "rebuilt from the original" plan, or a "check" note."""
    from .fingerprint import Target, clip_onsets, crop_source_name, locate_crops

    # Lost crop -> what Live recorded, and the projects (for the clips' transients).
    lost: dict[str, tuple[str, int, int | None, list[str]]] = {}
    for p in projects:
        for (path, name, size, crc) in p.samples:
            if live_generated(path) != "crop" or results[path][0] or not size:
                continue
            entry = lost.setdefault(path, (name, size, crc, []))
            entry[3].append(p.path)
    if not lost:
        return

    def originals(name: str) -> list[str]:
        found = []
        for n in {name.lower(), crop_source_name(name).lower()}:
            found += [c for c in index.get(n, []) if not live_generated(c) and c.lower().endswith(".wav")]
        # Identical copies of one original only need searching once.
        seen, out = set(), []
        for c in sorted(found):
            try:
                key = (os.path.basename(c).lower(), os.path.getsize(c))
            except OSError:
                continue
            if key not in seen:
                seen.add(key)
                out.append(c)
        return out

    jobs: dict[str, list] = defaultdict(list)  # original -> targets
    for path, (name, size, crc, als_files) in lost.items():
        if crc is None:
            continue  # without Live's fingerprint the cut can't be found safely
        onsets = sorted({t for a in als_files for t in clip_onsets(a, name)})
        for orig in originals(name):
            jobs[orig].append(Target(path, size, crc, onsets))
    if not jobs:
        return

    print(f"Looking for {len(lost)} lost crop(s) inside {len(jobs)} original file(s)"
          " (about 15 s per 30 MB) ...", file=sys.stderr, flush=True)
    done: set[str] = set()
    maybe: dict[str, str] = {}
    for orig, targets in jobs.items():
        targets = [t for t in targets if t.key not in done]
        if not targets:
            continue
        print(f"  {Path(orig).name}", file=sys.stderr, flush=True)
        for key, f in locate_crops(orig, targets).items():
            span = f"frames {f.start}-{f.start + f.frames}"
            if f.sure:
                done.add(key)
                results[key] = (orig, f"{REBUILD} at {_mmss(f.start / f.rate)} ({f.why}); {span}")
            elif f.candidates and key not in maybe:
                maybe[key] = orig
                results[key] = (orig, f"check: {REBUILD}? {f.why}; {span}")


def plan_reverse_rebuilds(projects, results: dict[str, tuple[str, str]], index) -> None:
    """Lost reversed files ('<name> R.wav') whose forward original survives. A reversed file
    is the original backwards, so it can be recreated exactly; only an original whose
    reversal matches Live's recorded size and fingerprint is used."""
    from .fingerprint import reverse_matches, reverse_source_name
    seen: set[str] = set()
    for p in projects:
        for (path, name, size, crc) in p.samples:
            if path in seen or live_generated(path) != "reverse" or results[path][0] or not size:
                continue
            seen.add(path)
            src = reverse_source_name(name)
            if not src or crc is None:
                continue
            for cand in sorted(index.get(src.lower(), [])):
                if cand.lower().endswith(".wav") and reverse_matches(cand, size, crc):
                    results[path] = (cand, f"{REBUILD}, reversed (Live's fingerprint matches)")
                    break


def _name_key(name: str) -> str:
    """'fiver 195 - Lead Drop .wav' -> 'fiver 195 lead drop'; 'pad (2).wav' -> 'pad'."""
    stem = os.path.splitext(os.path.basename(name.replace("\\", "/")))[0].lower()
    stem = re.sub(r"\s*\(\d+\)$", "", stem)
    return " ".join(re.findall(r"[a-z0-9#]+", stem))


def _names_agree(old: str, cand: str) -> bool:
    """Same name, or one is the other with words added in front (a song or pack prefix)."""
    a, b = _name_key(old), _name_key(cand)
    return bool(a and b) and (a == b or a.endswith(" " + b) or b.endswith(" " + a))


def confirm_renamed(old: str, cands: list[str], uses) -> tuple[str, str]:
    """Decide on copies found under other names by size + fingerprint. The fingerprint only
    covers the first 16 KB, so more is needed: the clip's saved transients must line up,
    the names must agree (e.g. 'fiver 195 - pad.wav' and 'pad.wav'), or the fingerprinted
    start must hold real (not silent) audio."""
    from .fingerprint import clip_onsets, same_content, starts_silent, transient_score
    named = [c for c in cands if _names_agree(old, c)]
    if named:
        # 'fiver 195 - long impact' agrees with both 'impact' and 'long impact': the longer,
        # more specific name wins.
        longest = max(len(_name_key(c)) for c in named)
        named = [c for c in named if len(_name_key(c)) == longest]
    if named and (len(named) == 1 or same_content(named)):
        return named[0], RENAMED
    onsets = sorted({t for als, name in uses for t in clip_onsets(als, name)})
    pool = named or cands
    if len(pool) > 1 and not same_content(pool):
        if onsets:
            scored = sorted(((transient_score(c, onsets) or 0.0, c) for c in pool), reverse=True)
            best, runner = scored[0][0], scored[1][0]
            if best >= 0.1 and best >= 2 * max(runner, 0.02):
                return scored[0][1], RENAMED
        return pool[0], f"check: {len(pool)} different files match Live's fingerprint"
    cand = pool[0]
    score = transient_score(cand, onsets) if onsets else None
    if score is not None:
        if score >= 0.1:
            return cand, RENAMED
        return cand, "check: renamed copy? fingerprint matches but transients don't line up"
    if starts_silent(cand):
        return cand, "check: renamed copy? starts silent, so the fingerprint can't confirm it"
    return cand, RENAMED


def _mmss(secs: float) -> str:
    return f"{int(secs // 60)}:{secs % 60:06.3f}"


def cmd_relink(db: VaultDB, args) -> None:
    for f in args.folders:
        if not Path(f).is_dir():
            sys.exit(f"Folder not found: {f}")
    projects = collect_missing(db)
    if not projects:
        print("No missing samples, nothing to relink.")
        return

    # Progress goes to the screen (stderr), so a report saved with > stays clean.
    print("Indexing audio files in " + ", ".join(args.folders) + " ...", file=sys.stderr, flush=True)
    index, total = build_index(
        args.folders, progress=lambda n: print(f"  {n:,} files so far", file=sys.stderr, flush=True))
    print(f"Searched {total:,} audio files in " + ", ".join(args.folders) + ".\n")

    results: dict[str, tuple[str, str]] = {}  # old path -> (new path or "", how)
    for p in projects:
        for (path, name, size, crc) in p.samples:
            if path in results:
                continue
            candidates = index.get(name.lower(), [])
            if is_ableton_library(path):
                results[path] = ("", "Ableton library")
            elif candidates or live_generated(path):
                results[path] = best_match(path, size, candidates, crc)
            else:
                results[path] = ("", "not found")

    if not args.no_rebuild:
        plan_reverse_rebuilds(projects, results, index)
        plan_crop_rebuilds(projects, results, index)

    # Still missing: look for the same audio saved under another name (size + fingerprint).
    wanted = {}
    for p in projects:
        for (path, name, size, crc) in p.samples:
            how = results[path][1]
            if (not results[path][0] or how.startswith("check")) and size and crc is not None \
                    and how not in ("Ableton library", "frozen track (Live rebuilds this)"):
                wanted[path] = (size, crc)
    if wanted:
        print(f"Looking for {len(wanted):,} missing sample(s) saved under other names ...",
              file=sys.stderr, flush=True)
        uses = defaultdict(set)  # old path -> (project file, sample name)
        for p in projects:
            for (path, name, _, _) in p.samples:
                if path in wanted:
                    uses[path].add((p.path, name))
        for old, cands in find_renamed(wanted, index).items():
            results[old] = confirm_renamed(old, sorted(set(cands)), uses[old])
    from . import lost as lost_list
    known_lost = lost_list.load(args.db)
    came_back = 0
    for old, (new, how) in list(results.items()):
        if lost_list.key(old) in known_lost:
            if new and not how.startswith("check"):
                came_back += 1
            elif not new:
                results[old] = ("", KNOWN_LOST)

    def group(how: str) -> str:
        if how == KNOWN_LOST:
            return "known lost"
        if how in CONFIDENT:
            return "confident"
        if how.startswith(REBUILD):
            return "rebuild"
        if how.startswith("check"):
            return "check"
        if how == "frozen track (Live rebuilds this)":
            return "frozen"
        if how in EDITED_LABEL.values():
            return "edited"
        return how  # "Ableton library" or "not found"

    tally, detail = defaultdict(int), defaultdict(int)
    for _, how in results.values():
        tally[group(how)] += 1
        detail[how] += 1

    print(f"Checked {len(results):,} missing samples used in {len(projects)} projects:\n")
    print(f"  {tally['confident']:6,d}  found, confident match")
    for how in (EXACT, RENAMED, "identical copies", "same folder names", "same file size", "only copy"):
        if detail[how]:
            print(f"            {detail[how]:6,d}  {how}")
    if tally["rebuild"]:
        print(f"  {tally['rebuild']:6,d}  cropped/reversed in Live: the edited file is gone, but its original"
              " was found (fix recreates the file)")
    print(f"  {tally['check']:6,d}  found, but worth a listen (different files share the name)")
    print(f"  {tally['Ableton library']:6,d}  Ableton library sounds (Live finds these if the pack is installed)")
    print(f"  {tally['frozen']:6,d}  frozen-track files (Live rebuilds these, nothing to do)")
    print(f"  {tally['edited']:6,d}  cropped/reversed/consolidated in Live, the edited file is gone")
    print(f"  {tally['not found']:6,d}  not found in the folders searched")
    if tally["known lost"]:
        print(f"  {tally['known lost']:6,d}  marked as lost (still searched for every run)")
    if came_back:
        print(f"\n  Good news: {came_back} sample(s) you marked as lost were found this time.")

    ok = {"confident", "rebuild", "Ableton library", "frozen", "known lost"}
    ready = sum(all(group(results[k[0]][1]) in ok for k in p.samples) for p in projects)
    print(f"\nProjects with nothing left to fix: {ready} of {len(projects)}"
          + (" (counting samples marked as lost)" if tally["known lost"] else ""))

    lost = defaultdict(int)
    for old, (_, how) in results.items():
        if how == "not found":
            lost[old_location(old)] += 1
    if lost:
        print("\nStill missing, by old location (these may be on another drive or backup):")
        for loc, n in sorted(lost.items(), key=lambda x: -x[1])[:10]:
            print(f"  {n:6d}  {loc}")

    out = Path(args.csv)
    with out.open("w", newline="", encoding="utf-8-sig") as f:  # -sig so Excel shows accents correctly
        w = csv.writer(f)
        w.writerow(["project", "project file", "tracks", "sample", "old location", "found at", "how it was matched"])
        for p in projects:
            for (path, name, _, _), tracks in p.samples.items():
                new, how = results[path]
                w.writerow([p.name, p.path, "; ".join(tracks), name, path, new, how])
    print(f"\nFull list: {out.resolve()}\nNothing was changed in your projects.")


KNOWN_LOST = "marked as lost"


def cmd_lost(db: VaultDB, args) -> None:
    """Mark samples that can't be found as lost for good, so reports focus on what's fixable."""
    from . import lost as lost_list
    marked = lost_list.load(args.db)
    if args.list or not args.report:
        if not args.report and not args.list and not args.clear:
            sys.exit("Give a relink report to mark from, or use --list / --clear.")
        if args.clear and not args.report:
            lost_list.save(args.db, set())
            print(f"Cleared all {len(marked):,} samples marked as lost.")
            return
        print(f"{len(marked):,} samples are marked as lost ({lost_list.lost_file(args.db)}).")
        return
    gone = set(EDITED_LABEL.values()) | {"not found", KNOWN_LOST}
    picked: set[str] = set()
    projects: set[str] = set()
    with open(args.report, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if args.project and args.project.lower() not in Path(row["project file"]).stem.lower():
                continue
            if row["found at"].strip() or row["how it was matched"] not in gone:
                continue
            picked.add(lost_list.key(row["old location"]))
            projects.add(row["project"])
    if args.clear:
        left = marked - picked
        lost_list.save(args.db, left)
        print(f"Unmarked {len(marked) - len(left):,} sample(s); {len(left):,} still marked as lost.")
        return
    new = picked - marked
    lost_list.save(args.db, marked | picked)
    print(f"Marked {len(new):,} sample(s) as lost, from {len(projects)} project(s)"
          f" ({len(marked | picked):,} in total).")
    print("relink still looks for them every run and tells you if any turn up.")
    print("Undo: python -m project_vault lost --clear" + (f' "{args.report}"' if args.report else "")
          + (f' --project "{args.project}"' if args.project else ""))


def cmd_fix(db: VaultDB, args) -> None:
    if not Path(args.report).is_file():
        sys.exit(f"Report not found: {args.report}  (run relink first)")
    plan = load_plan(args.report, args.include_check)
    if args.project:
        plan = {k: v for k, v in plan.items() if args.project.lower() in Path(k).stem.lower()}
    if not plan:
        sys.exit("Nothing to fix: no projects with confident matches"
                 + (f" matching '{args.project}'." if args.project else "."))

    verb = "Would write" if args.dry_run else "Wrote"
    written = samples = 0
    skipped = []
    for als_path, mapping in sorted(plan.items(), key=lambda kv: Path(kv[0]).stem.lower()):
        try:
            r = fix_project(als_path, mapping, replace=args.replace, dry_run=args.dry_run)
        except Exception as e:  # one bad project must not stop the rest
            from .fix import FixResult
            r = FixResult(Path(als_path).stem)
            r.skipped = f"unexpected error, skipped ({type(e).__name__}: {e})"
        if r.output:
            written += 1
            samples += r.samples
            print(f"  {verb} {Path(r.output).name}  ({r.samples} sample(s) relinked)")
            for f in r.rebuilt:
                print(f"      {'would recreate' if args.dry_run else 'recreated'} lost Live file: {f}")
            for n in r.notes:
                print(f"      {n}")
            for old in r.unchanged_refs[:3]:
                print(f"      could not update this older-format entry: {old}")
        else:
            skipped.append(r)

    print(f"\n{verb} {written} relinked project(s), {samples:,} sample(s) relinked.")
    if skipped:
        print(f"Skipped {len(skipped)}:")
        for r in skipped[:25]:
            print(f"  {r.project}: {r.skipped}")
        if len(skipped) > 25:
            print(f"  ... and {len(skipped) - 25} more")
    if not args.dry_run and written:
        print("\nOriginals were not changed. Each fixed copy is saved next to its original as"
              " '<name> (relinked).als'.\nOpen one in Live to check it plays before relying on it.")


def cmd_unused(db: VaultDB, args) -> None:
    root = Path(args.folder)
    used = db.used_norm_paths()
    unused, total_bytes = [], 0
    for dirpath, _, files in os.walk(root):
        for f in files:
            p = Path(dirpath) / f
            if p.suffix.lower() in AUDIO_EXTS and norm(str(p)) not in used:
                size = p.stat().st_size
                unused.append((p, size))
                total_bytes += size
    print(f"{len(unused)} audio file(s) in {root} are not used by any scanned project "
          f"({total_bytes / 1e9:.2f} GB).")
    print("Nothing was deleted. Only scanned projects are counted, so scan every project folder first.")
    if args.list:
        for p, size in sorted(unused, key=lambda x: -x[1]):
            print(f"  {size / 1e6:8.1f} MB  {p}")


def cmd_plugins(db: VaultDB, args) -> None:
    if args.name:
        rows = db.projects_with_plugin(args.name)
        if not rows:
            print("No scanned project uses that plugin.")
        for r in rows:
            print(f"  {r['name']}  /  track: {r['track_name']}  ({r['plugin']})")
        return
    for r in db.plugin_counts():
        print(f"  {r['projects']:4d} project(s)  {r['name']}  [{r['format']}]")


def cmd_plugin_check(db: VaultDB, args) -> None:
    usage = db.plugin_usage()
    if not usage:
        sys.exit("No plugins found. Run scan first.")
    # Also look in every folder projects loaded VST2 plugins from, if it exists on this PC.
    old_dirs = {os.path.dirname(f) for r in usage for f in (r["files"] or "").split(",") if f}
    vst2_dirs = list(dict.fromkeys(DEFAULT_VST2 + args.vst2 + sorted(d for d in old_dirs if os.path.isdir(d))))
    inst = find_installed(vst2_dirs, DEFAULT_VST3 + args.vst3)
    print(f"Plugins installed on this PC: {len(inst.vst3)} VST3, {len(inst.vst2)} VST2 (.dll files)")
    print("Looked in: " + ("; ".join(inst.searched) or "(none of the usual folders exist)") + "\n")

    results = check(usage, inst)
    groups = defaultdict(list)
    for r in results:
        groups[r.status].append(r)
    print(f"Your projects use {len(results)} different plugins:")
    for status in ("installed", "only VST3 installed", "only VST2 installed", "different version installed",
                   "missing", "not checked (AU)"):
        if groups[status]:
            print(f"  {len(groups[status]):4d}  {status}")

    missing_keys = {(r.name, r.fmt) for r in results if r.status != "installed"}
    per_project = defaultdict(set)
    for row in db.plugins_by_project():
        per_project[row["project_id"]].add((row["name"], row["format"]))
    total = db.stats()["projects"]
    ready = total - sum(1 for plugs in per_project.values() if plugs & missing_keys)
    print(f"\nProjects with every plugin installed: {ready} of {total}")

    # Biggest wins: projects where one plugin is the only thing missing.
    only_one = defaultdict(int)
    for plugs in per_project.values():
        lacking = plugs & missing_keys
        if len(lacking) == 1:
            only_one[next(iter(lacking))] += 1
    if only_one:
        print("\nBiggest wins: installing just this plugin makes these projects complete")
        for (name, fmt), n in sorted(only_one.items(), key=lambda x: -x[1])[:12]:
            print(f"  {n:4d} project(s)  {name}  [{fmt}]")

    def show(title, rows, limit=40):
        if not rows:
            return
        print(f"\n{title}")
        for r in rows[:limit]:
            print(f"  {r.projects:4d} project(s)  {r.name}  [{r.fmt}]"
                  + (f"\n                     installed as {r.found_at}" if r.found_at else ""))
        if len(rows) > limit:
            print(f"  ... and {len(rows) - limit} more (see the CSV)")

    show("Projects need the VST2 version, but only the VST3 is installed "
         "(re-run the installer with VST2 ticked, or swap it in Live):", groups["only VST3 installed"])
    show("Projects need the VST3 version, but only the VST2 is installed:", groups["only VST2 installed"])
    show("A different version is installed (older projects may not load it; check in Live):",
         groups["different version installed"])
    show("Missing completely:", groups["missing"])

    old, shown = defaultdict(int), {}
    for r in groups["missing"] + groups["only VST3 installed"]:
        for f in r.old_files:
            if "/" in f:
                folder = "/".join(f.split("/")[:3])  # e.g. C:/Program Files (x86)/Vst Plugins
                shown.setdefault(folder.lower(), folder)  # Windows folder names ignore case
                old[folder.lower()] += 1
    if old:
        print("\nWhere your projects expected the missing VST2 plugins (old install folders):")
        for d, n in sorted(old.items(), key=lambda x: -x[1])[:8]:
            print(f"  {n:4d}  {shown[d]}")
        print("If your VST2 plugins are in a different folder, point Live at it in Settings > Plug-ins,"
              "\nand add it here with --vst2 \"FOLDER\" so this check sees them.")

    out = Path(args.csv)
    with out.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["plugin", "format", "company", "status", "projects", "only thing missing in",
                    "installed at", "old location", "project names"])
        for r in sorted(results, key=lambda r: (r.status == "installed", -r.projects)):
            vendor, sure = vendor_for(r.name, r.old_files)
            w.writerow([r.name, r.fmt, vendor if sure else "", r.status, r.projects,
                        only_one.get((r.name, r.fmt), 0), r.found_at, "; ".join(r.old_files[:3]),
                        "; ".join(r.project_names)])
    print(f"\nFull list: {out.resolve()}")

    page = Path(args.html)
    write_html(build_list(results, only_one), str(page), total, ready)
    print(f"Shopping list (open in your browser): {page.resolve()}")


def _swap_rules(db: VaultDB, args):
    """Work out which missing plugin becomes which installed one."""
    usage = db.plugin_usage()
    old_dirs = {os.path.dirname(f) for r in usage for f in (r["files"] or "").split(",") if f}
    vst2_dirs = list(dict.fromkeys(DEFAULT_VST2 + args.vst2 + sorted(d for d in old_dirs if os.path.isdir(d))))
    results = check(usage, find_installed(vst2_dirs, DEFAULT_VST3 + args.vst3))
    by_key = {}
    for r in results:
        if r.status == "installed":
            by_key.setdefault((plugin_key(r.name), r.fmt), (r.name, r.fmt))

    pairs: dict[tuple[str, str], tuple[str, str] | None] = {}
    for r in results:
        if r.status in ("different version installed", "only VST2 installed", "only VST3 installed"):
            fmt = "VST3" if r.found_at.lower().endswith(".vst3") else "VST2"
            stem = r.found_at.replace("\\", "/").rsplit("/", 1)[-1]
            pairs[(r.name, r.fmt)] = by_key.get((plugin_key(stem), fmt))  # None: no project uses it yet
    for rule in args.map:
        if "=" not in rule:
            sys.exit(f'--map needs "OLD=NEW", got: {rule}')
        old, new = (x.strip().lower() for x in rule.split("=", 1))
        sources = [(r.name, r.fmt) for r in results if r.name.lower() == old and r.status != "installed"]
        targets = [v for v in by_key.values() if v[0].lower() == new]
        if not sources:
            sys.exit(f"No missing plugin called '{old}' in your projects.")
        if not targets:
            sys.exit(f"'{new}' isn't a plugin used in any of your projects on this PC, so its details "
                     "aren't known yet. Load it once in any project, save, scan, then try again.")
        for src in sources:
            pairs[src] = targets[0]
    if args.only:
        wanted = {x.lower() for x in args.only}
        pairs = {k: v for k, v in pairs.items() if k[0].lower() in wanted}
    skips = [x.lower() for x in getattr(args, "skip", [])]
    if skips:  # e.g. a free Kontakt Player is installed but the libraries need the full Kontakt
        pairs = {k: v for k, v in pairs.items() if not any(x in k[0].lower() for x in skips)}
    counts = {(r.name, r.fmt): r.projects for r in results}
    return pairs, counts


def cmd_swap(db: VaultDB, args) -> None:
    pairs, counts = _swap_rules(db, args)
    if not pairs:
        sys.exit("Nothing to swap: no missing plugin has an installed replacement. Add your own with "
                 '--map "OLD=NEW".')
    rules, no_template = {}, []
    for src, dst in sorted(pairs.items(), key=lambda kv: -counts.get(kv[0], 0)):
        tpl = find_template([(r["path"], r["live_version"]) for r in db.projects_using(*dst)], *dst) if dst else None
        if tpl:
            rules[src] = tpl
        else:
            no_template.append((src, dst))

    print("Swaps:")
    for src, tpl in rules.items():
        from .swap import keeps_settings
        from .swap import rejects_settings, tested_carry_over, tested_vst3_migration, tested_vst3_to_vst2
        from .translators import TRANSLATORS, is_fabfilter
        from .translators import VST3_TRANSLATORS
        how = ("translates settings" if (plugin_key(src[0]), plugin_key(tpl.name)) in TRANSLATORS
               else "translates settings (tested)"
               if (plugin_key(src[0]), plugin_key(tpl.name)) in VST3_TRANSLATORS
               else "keeps settings (tested)" if tested_carry_over(src, (tpl.name, tpl.fmt))
               or tested_vst3_migration(src, (tpl.name, tpl.fmt)) or tested_vst3_to_vst2(src, (tpl.name, tpl.fmt))
               else "keeps settings" if keeps_settings(src, (tpl.name, tpl.fmt))
               else "starts from default sound (it can't read the old settings; preset name kept)"
               if rejects_settings(src, (tpl.name, tpl.fmt))
               else "starts from default sound (FabFilter versions store settings differently; old settings saved)"
               if is_fabfilter(src[0]) and src[1] == tpl.fmt == "VST2"
               else "VST3 -> VST2: carries settings when the VST3 saved them in VST2 form, else experimental"
               if args.try_settings and (src[1], tpl.fmt) == ("VST3", "VST2")
               else "tries to carry settings over (experimental)"
               if (args.try_vst3 if (src[1], tpl.fmt) == ("VST2", "VST3") else args.try_settings)
               else "starts from default sound (add --try-vst3 to try keeping it)"
               if (src[1], tpl.fmt) == ("VST2", "VST3")
               else "starts from default sound (add --try-settings to try keeping it)")
        print(f"  {counts.get(src, 0):4d} project(s)  {src[0]} [{src[1]}]  ->  {tpl.name} [{tpl.fmt}]   ({how})")
    for src, dst in no_template:
        print(f"  can't yet: {src[0]} [{src[1]}] -> {dst[0] if dst else 'its installed version'}: load it once in "
              "any Live 11/12 project, save, run scan, then swap again")
    from .plugin_check import free_older_version
    tips = {free_older_version(src[0]) for src in rules} - {""}
    for tip in sorted(tips):
        print(f"\n  Tip: {tip}\n  (Add --skip with that plugin's name to leave it out of the swap.)")
    if args.list or not rules:
        return

    targets = {}
    for src in rules:
        for r in db.projects_using(*src):
            targets[r["path"]] = r["live_version"]
    if args.project:
        targets = {k: v for k, v in targets.items() if args.project.lower() in Path(k).stem.lower()}
    verb = "Would write" if args.dry_run else "Wrote"
    written, skipped, rows = 0, [], []
    for path in sorted(targets, key=lambda p: Path(p).stem.lower()):
        try:
            r = swap_project(path, rules, replace=args.replace, dry_run=args.dry_run,
                             try_settings=args.try_settings, try_vst3=args.try_vst3,
                             old_live_test=args.old_live_test)
        except Exception as e:  # one bad project must not stop the rest
            from .swap import SwapResult
            r = SwapResult(Path(path).stem, skipped=f"unexpected error, skipped ({type(e).__name__}: {e})")
        if r.output:
            written += 1
            lanes = f", {r.automation_removed} automation lane(s) removed" if r.automation_removed else ""
            later = f"; {len(r.needs_resave)} more after saving it in Live 12" if r.needs_resave else ""
            print(f"  {verb} {Path(r.output).name}  ({len(r.swaps)} plugin(s) swapped{lanes}{later})")
            for s in r.swaps:
                rows.append([r.project, path, r.output, s.track, s.old, s.preset, s.new, s.settings])
        else:
            skipped.append(r)
    print(f"\n{verb} {written} swapped project(s).")
    old_live = [r for r in skipped if "open it in Live 12" in r.skipped]
    exists = [r for r in skipped if "already exists" in r.skipped]
    other = [r for r in skipped if r not in old_live and r not in exists]
    if exists:
        print(f"{len(exists)} project(s) already have a swapped copy and were left alone. "
              "To rebuild them with this version, run the same command with --replace.")
    if old_live:
        print(f"{len(old_live)} project(s) were made in Live 9 or older and only need swaps to or from "
              "VST3. Open each in Live 12 and save it once, then run swap again.")
    for r in other[:15]:
        print(f"  {r.project}: {r.skipped}")
    if rows and not args.dry_run:
        out = Path(args.csv)
        with out.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["project", "original file", "swapped file", "track", "old plugin", "old sound (preset)",
                        "new plugin", "settings"])
            w.writerows(rows)
        print(f"\nDetails: {out.resolve()}")
        print("Originals were not changed. Open one swapped project in Live to check it before relying on it.")


def _resave_todo(db: VaultDB, args) -> tuple[list[str], int]:
    """The Project Vault copies that need one save in Live 12 before swap can finish them.
    An original without a copy gets one in Relinked\\ first, so no original is ever opened."""
    import gzip
    from .layout import COPY_DIRS, anchor_refs, relinked_path
    args.map, args.only, args.skip = [], [], []
    pairs, _ = _swap_rules(db, args)
    rules = {}
    for src, dst in pairs.items():
        tpl = find_template([(r["path"], r["live_version"]) for r in db.projects_using(*dst)], *dst) if dst else None
        if tpl:
            rules[src] = tpl
    paths = sorted({r["path"] for src in rules for r in db.projects_using(*src)})
    todo, made = [], 0
    for path in paths:
        r = swap_project(path, rules, dry_run=True, replace=True)
        if not (r.needs_resave or "open it in Live 12" in r.skipped):
            continue
        p = Path(path)
        if p.parent.name not in COPY_DIRS:  # an original: never opened, work on a copy instead
            target = relinked_path(p)
            if not target.exists():
                text, _ = anchor_refs(gzip.open(p, "rb").read().decode("utf-8"), p.parent)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(gzip.compress(text.encode("utf-8")))
                made += 1
            p = target
        todo.append(str(p))
    return todo, made


def cmd_resave_list(db: VaultDB, args) -> None:
    """List the projects that need one save in Live 12 before swap can finish them."""
    todo, made = _resave_todo(db, args)
    out = Path(args.out)
    out.write_text("\n".join(todo) + "\n", encoding="utf-8")
    print(f"{len(todo)} project(s) need one save in Live 12. List: {out.resolve()}")
    if made:
        print(f"Made {made} copy(ies) in Relinked\\ first, so no original is opened.")
    if todo:
        print("To be walked through them one by one: python -m project_vault resave")


def cmd_resave(db: VaultDB, args) -> None:
    """Open each copy that needs a Live 12 save, wait for the save, go on to the next."""
    from .resave import run
    if args.list:
        todo = [l.strip() for l in Path(args.list).read_text(encoding="utf-8").splitlines() if l.strip()]
    else:
        print("Finding the projects that need one save in Live 12...")
        todo, made = _resave_todo(db, args)
        if made:
            print(f"Made {made} copy(ies) in Relinked\\ first, so no original is opened.")
    try:
        folder = os.path.commonpath([r[0] for r in db.conn.execute("SELECT path FROM projects")])
    except ValueError:
        folder = "<your projects folder>"
    run(todo, folder)


def cmd_repair(db: VaultDB, args) -> None:
    from .layout import repair
    root = Path(args.folder)
    if not root.is_dir():
        sys.exit(f"Folder not found: {root}")
    st = repair(root, dry_run=args.dry_run)
    verb = "Would repair" if args.dry_run else "Repaired"
    print(f"Checked {st['checked']} copies in Relinked\\ and Swapped\\. {verb} {st['repaired']}"
          + (f", {st['failed']} could not be repaired" if st["failed"] else "") + ".")
    if not args.dry_run and st["repaired"]:
        print("Originals were not touched. Run scan again so the reports pick up the repaired copies.")


def cmd_tidy(db: VaultDB, args) -> None:
    from .layout import tidy
    root = Path(args.folder)
    if not root.is_dir():
        sys.exit(f"Folder not found: {root}")
    stats = tidy(root, dry_run=args.dry_run)
    verb = "Would move" if args.dry_run else "Moved"
    print(f"\n{verb} {stats['moved']} copies into Relinked\\ and Swapped\\ folders"
          f" ({stats['skipped']} skipped), and {stats['settings']} saved plugin-settings folder(s)"
          " into Swapped\\Plugin settings\\.")
    if not args.dry_run and stats["moved"]:
        print("Originals were not touched. Run scan again so the reports use the moved copies.")


def cmd_project(db: VaultDB, args) -> None:
    matches = db.find_projects(args.name)
    if not matches:
        sys.exit("No project matches that name.")
    for p in matches:
        tracks, samples, plugins = db.project_detail(p["id"])
        tempo = f"{p['tempo']:g} BPM" if p["tempo"] else "unknown tempo"
        print(f"\n{p['name']}  —  {tempo}, {p['live_version']}\n  {p['path']}")
        print(f"  {len(tracks)} tracks, {len(samples)} samples, {len(plugins)} plugin instances")
        for t in tracks:
            print(f"    [{t['kind']}] {t['name']}: {t['devices'] or '(no devices)'}")


def cmd_crash_doctor(db: VaultDB, args) -> None:
    from .crash_doctor import default_locations, diagnose, plugins_in, report, safe_copy
    usage, crash = default_locations()
    usage = [Path(p) for p in args.usage] or usage
    crash = [Path(p) for p in args.crash] or crash
    result = diagnose(usage, crash, args.last) if usage else None
    if not args.safe:
        if not usage:
            sys.exit("Couldn't find Live's logs (Live Reports\\Usage). Point to them with --usage.")
        report(result)
        return
    als = Path(args.safe)
    if not als.is_file():
        sys.exit(f"Set not found: {als}")
    in_set = plugins_in(str(als))
    names = {plugin_key(n) for n, _ in in_set}
    if args.remove:
        plans = [(args.remove, "")]
    else:  # --each (the default): one copy per suspect that is in this set
        ranked = [k for k in (result["ranking"] if result else []) if plugin_key(k[0]) in names]
        if not ranked:
            print("No crash in Live's logs involves this set's plugins. Its plugins:")
            for n, f in in_set:
                print(f"  {n} [{f}]")
            print('Leave one out with --remove "NAME".')
            return
        plans = [([n], f" - no {n}") for n, _ in ranked]
    for remove, tag in plans:
        missing = [r for r in remove if plugin_key(r) not in names]
        if missing:
            print(f"  not in this set: {', '.join(missing)}")
        r = safe_copy(str(als), remove, dry_run=args.dry_run, tag=tag)
        if not r["output"]:
            continue
        verb = "Would write" if args.dry_run else "Wrote"
        gone = ", ".join(f"{p} on '{t}'" for t, p, _ in r["removed"])
        lanes = f", {r['lanes']} automation lane(s) for it removed" if r["lanes"] else ""
        print(f"{verb} {r['output']}\n    without {gone}{lanes}")
        if r["presets"]:
            print(f"    its settings saved in {Path(r['output']).parent / 'Plugin settings'}")
    if not args.dry_run and len(plans) > 1:
        print("\nOpen each copy in Live and close it again. The one that closes without crashing "
              "is missing the plugin that causes the crash.")
    print("The original set is unchanged.")


def cmd_report(db: VaultDB, args) -> None:
    from .report import build_report, describe_contents
    out = Path(args.out or f"ProjectVault-report-{time.strftime('%Y%m%d-%H%M')}.zip")
    print("Making a support report. Nothing is sent anywhere.")
    contents = build_report(db, args.db, out, Path.cwd(), plugin=args.plugin, project=args.project,
                            note=args.note, with_crashes=not args.no_crashes,
                            with_installed=not args.no_installed)
    print(f"\nWrote {out.resolve()}\n\nWhat's inside (text only, no audio or project files):")
    for name, size in contents:
        print(f"  {name}  ({size/1024:.1f} KB)\n      {describe_contents(name)}")
    print("\nYour Windows user name and home folder are replaced with <user> and ~."
          "\nOpen the zip to look at it, then attach it to your message to us.")
    if args.show:
        import zipfile
        with zipfile.ZipFile(out) as z:
            print("\n" + z.read("report.txt").decode("utf-8"))


def cmd_update(db: VaultDB, args) -> None:
    from . import __version__
    from . import updater
    if args.rollback:
        try:
            prev = updater.rollback()
        except updater.UpdateError as e:
            print(f"Couldn't go back: {e}")
            return
        print(f"Went back to the version saved in {prev.name}. Your projects and database weren't touched.")
        return
    print(f"You have Project Vault {__version__}. Checking for updates...")
    try:
        rel = updater.fetch_release()
    except updater.UpdateError as e:
        print(f"Couldn't check: {e}.")
        return
    if not updater.is_newer(rel):
        print(f"You're up to date (newest is {rel.version}).")
        return
    print(f"\nProject Vault {rel.version} is available"
          + (f" ({rel.published})" if rel.published else "") + ".")
    if rel.notes:
        print("What's new:\n  " + rel.notes.replace("\n", "\n  "))
    if args.check:
        print("\nTo install it: python -m project_vault update")
        return
    if not args.yes:
        if input("\nInstall it now? [y/N] ").strip().lower() not in ("y", "yes"):
            print("Not installed.")
            return
    print("Downloading and checking it...")
    try:
        backup = updater.install(rel)
    except updater.UpdateError as e:
        print(f"Not installed: {e}")
        return
    print(f"\nInstalled Project Vault {rel.version}. The old version is kept in {backup}."
          "\nIf anything seems wrong: python -m project_vault update --rollback")


def cmd_stats(db: VaultDB, args) -> None:
    for k, v in db.stats().items():
        print(f"  {k:15s} {v}")


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="project_vault", description="Index and search your Ableton projects.")
    from . import __version__
    ap.add_argument("--version", action="version", version=f"Project Vault {__version__}")
    ap.add_argument("--db", default=str(DEFAULT_DB), help="database file (default: %(default)s)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("scan", help="read every .als under a folder")
    s.add_argument("folder")
    s.add_argument("--full", action="store_true", help="re-read projects even if unchanged")
    s.add_argument("--originals", action="store_true",
                   help="only your original projects, e.g. before redoing relink from scratch")
    s.add_argument("--ignore-swapped", action="store_true",
                   help="leave out (swapped) copies, e.g. before redoing the swap from the relinked copies")
    s = sub.add_parser("where", help="which projects use a sample")
    s.add_argument("text", help="part of the sample's file name or path")
    s = sub.add_parser("missing", help="samples that projects use but can't be found")
    s.add_argument("--summary", action="store_true", help="totals only, no per-project list")
    s = sub.add_parser("relink", help="search folders for missing samples (report only)")
    s.add_argument("folders", nargs="+", help="sample folders to search, e.g. E:/Samples F:/Samples")
    s.add_argument("--csv", default="relink_report.csv", help="where to save the full list")
    s.add_argument("--no-rebuild", action="store_true",
                   help="don't search originals for lost Live crops (faster)")
    s = sub.add_parser("fix", help="write relinked copies of projects from a relink report")
    s.add_argument("report", help="relink_report.csv from the relink command")
    s.add_argument("--project", help="only projects whose name contains this text")
    s.add_argument("--include-check", action="store_true",
                   help="also apply 'check' matches (different files share the name)")
    s.add_argument("--replace", action="store_true", help="overwrite existing (relinked) copies")
    s.add_argument("--dry-run", action="store_true", help="show what would be written, write nothing")
    s = sub.add_parser("lost", help="mark samples that can't be found as lost for good")
    s.add_argument("report", nargs="?", help="relink_report.csv: marks every sample it couldn't find")
    s.add_argument("--project", help="only projects whose name contains this text")
    s.add_argument("--list", action="store_true", help="how many samples are marked as lost")
    s.add_argument("--clear", action="store_true",
                   help="unmark them (all, or those in the report / --project you give)")
    s = sub.add_parser("unused", help="audio files no project uses (report only)")
    s.add_argument("folder")
    s.add_argument("--list", action="store_true", help="list each file, largest first")
    s = sub.add_parser("plugins", help="plugin usage, or projects using one plugin")
    s.add_argument("name", nargs="?")
    s = sub.add_parser("plugin-check", help="which plugins your projects need that aren't installed")
    s.add_argument("--vst2", action="append", default=[], help="extra VST2 folder to search (repeatable)")
    s.add_argument("--vst3", action="append", default=[], help="extra VST3 folder to search (repeatable)")
    s.add_argument("--csv", default="plugin_report.csv", help="where to save the full list")
    s.add_argument("--html", default="plugin_shopping_list.html", help="where to save the shopping list")
    s = sub.add_parser("swap", help="replace missing plugins with versions you have (writes copies)")
    s.add_argument("--map", action="append", default=[], metavar='"OLD=NEW"',
                   help='your own swap, e.g. --map "Massive=Serum 2" (repeatable)')
    s.add_argument("--only", action="append", default=[], metavar="PLUGIN",
                   help="only swap this missing plugin (repeatable)")
    s.add_argument("--skip", action="append", default=[], metavar="PLUGIN",
                   help='never swap plugins whose name contains this, e.g. --skip Kontakt (repeatable)')
    s.add_argument("--project", help="only projects whose name contains this text")
    s.add_argument("--list", action="store_true", help="show the planned swaps, change nothing")
    s.add_argument("--dry-run", action="store_true", help="show what would be written, write nothing")
    s.add_argument("--replace", action="store_true", help="overwrite existing (swapped) copies")
    s.add_argument("--try-settings", action="store_true",
                   help="experimental: also give different versions the old settings (test on one project first)")
    s.add_argument("--try-vst3", action="store_true",
                   help="experimental: hand VST2 settings to the VST3 version (test on one project first)")
    s.add_argument("--vst2", action="append", default=[], help="extra VST2 folder (repeatable)")
    s.add_argument("--vst3", action="append", default=[], help="extra VST3 folder (repeatable)")
    s.add_argument("--csv", default="swap_report.csv", help="where to save the details")
    s.add_argument("--old-live-test", action="store_true", help=argparse.SUPPRESS)
    s = sub.add_parser("resave-list", help="list the projects that need one save in Live 12 before swap")
    s.add_argument("--out", default="resave_list.txt")
    s.add_argument("--vst2", action="append", default=[])
    s.add_argument("--vst3", action="append", default=[])
    s = sub.add_parser("resave", help="open each project that needs a Live 12 save, one at a time")
    s.add_argument("--list", help="use this list (from resave-list) instead of working it out")
    s.add_argument("--vst2", action="append", default=[])
    s.add_argument("--vst3", action="append", default=[])
    s = sub.add_parser("repair", help="fix copies Live calls corrupt (missing list Ids)")
    s.add_argument("folder")
    s.add_argument("--dry-run", action="store_true")
    s = sub.add_parser("tidy", help="move (relinked)/(swapped) copies into Relinked\\ and Swapped\\ folders")
    s.add_argument("folder")
    s.add_argument("--dry-run", action="store_true", help="show what would move, change nothing")
    s = sub.add_parser("project", help="summary of one project")
    s.add_argument("name")
    sub.add_parser("stats", help="totals")
    s = sub.add_parser("report", help="make a support report (a zip you look at and send yourself)")
    s.add_argument("--plugin", metavar="NAME", help="include this plugin's stored settings from your projects")
    s.add_argument("--project", metavar="NAME", help="include details of projects whose name contains this")
    s.add_argument("--note", help='what went wrong, in your words, e.g. --note "Kickstart sounds different"')
    s.add_argument("--out", help="zip file to write (default: ProjectVault-report-DATE.zip here)")
    s.add_argument("--show", action="store_true", help="also print report.txt here")
    s.add_argument("--no-crashes", action="store_true", help="leave out Live's crash history")
    s.add_argument("--no-installed", action="store_true", help="leave out the list of installed plugins")
    s = sub.add_parser("update", help="install the newest version (checked and signed by us)")
    s.add_argument("--check", action="store_true", help="only say whether there's a newer version")
    s.add_argument("--yes", action="store_true", help="install without asking")
    s.add_argument("--rollback", action="store_true", help="go back to the version before the last update")
    s = sub.add_parser("crash-doctor", help="find the plugin that crashes Live; write a copy of a set without it")
    s.add_argument("--safe", metavar="SET.als", help="write test copies of this set without the suspects")
    s.add_argument("--remove", action="append", default=[], metavar="PLUGIN",
                   help="with --safe: leave out exactly this plugin (repeatable) instead of one copy per suspect")
    s.add_argument("--each", action="store_true", help="with --safe: one copy per suspect (the default)")
    s.add_argument("--last", type=int, default=10, help="look at this many recent crashes (default 10)")
    s.add_argument("--usage", action="append", default=[], help="Live Reports\\Usage folder, if not found")
    s.add_argument("--crash", action="append", default=[], help="Live's Preferences\\Crash folder, if not found")
    s.add_argument("--dry-run", action="store_true", help="show what would be written")

    # Windows consoles may not support every character; never crash on output.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    args = ap.parse_args(argv)
    Path(args.db).parent.mkdir(parents=True, exist_ok=True)
    db = VaultDB(args.db)
    if db.upgraded:
        print("Project Vault's database was upgraded. Run scan again to rebuild it.")
        if args.cmd != "scan":
            db.close()
            return
    from .report import log_command, log_error
    argv_shown = list(argv if argv is not None else sys.argv[1:])
    try:
        globals()[f"cmd_{args.cmd.replace('-', '_')}"](db, args)
    except KeyboardInterrupt:
        log_command(args.db, argv_shown, "stop")
        raise
    except Exception as e:
        log_command(args.db, argv_shown, "ERROR")
        saved = log_error(args.db, argv_shown, e)
        import traceback
        traceback.print_exc()
        print("\nProject Vault hit an error." + (f" The details were saved in {saved}." if saved else ""))
        print("To send them to us: python -m project_vault report")
        sys.exit(1)
    else:
        log_command(args.db, argv_shown, "ok")
        if args.cmd != "update":
            try:
                from .updater import daily_notice
                notice = daily_notice(Path(args.db).parent)
                if notice:
                    print("\n" + notice)
            except Exception:
                pass  # an update check must never spoil a command that worked
    finally:
        db.close()


if __name__ == "__main__":
    main()
